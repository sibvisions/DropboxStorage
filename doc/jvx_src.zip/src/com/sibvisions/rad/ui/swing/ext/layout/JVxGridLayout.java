/*
 * Copyright 2014 SIB Visions GmbH
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 * 
 * 
 * History
 *
 * 06.03.2014 - [LT] - erstellt
 */
package com.sibvisions.rad.ui.swing.ext.layout;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager2;
import java.awt.Rectangle;
import java.util.HashMap;
import java.util.Map;

/**
 * The GridLayout class is a layout manager that lays out a container's
 * components in a rectangular grid.
 * 
 * @author Thomas Lehner
 */
public class JVxGridLayout implements LayoutManager2
{
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Class members
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
	/** Stores all constraints. */
	private final Map<Component, CellConstraints>	constraintMap;
	
	/** the layout margins. */
	private Insets									margins	= new Insets(0, 0, 0, 0);		
	
	/** The number of rows. */
	private int										rows		= 1;

	/** The number of columns. */
	private int										columns		= 1;

	/** the horizontal gap between components. */
	private int										horizontalGap;

	/** the vertical gap between components. */
	private int										verticalGap;

	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Initialization
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
	/**
	 * Constructs a new GridLayout.
	 * 
	 * @param pColumns the column count
	 * @param pRows the row count
	 */
	public JVxGridLayout(int pColumns, int pRows)
	{
		if (pColumns < 1)
		{
			throw new IllegalArgumentException("There must be at least 1 column.");
		}
		
		if (pRows < 1)
		{
			throw new IllegalArgumentException("There must be at least 1 row.");
		}
		
		setRows(pRows);
		setColumns(pColumns);
		
		int initialCapacity = rows * columns / 2;
		
		constraintMap = new HashMap<Component, CellConstraints>(initialCapacity);
	}
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Interface implementation
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	/**
	 * {@inheritDoc}
	 */
	public void addLayoutComponent(String pName, Component c)
	{
		throw new UnsupportedOperationException("Use #addLayoutComponent(Component, Object) instead.");
	}

	/**
	 * {@inheritDoc}
	 */
	public void removeLayoutComponent(Component pComp)
	{
		constraintMap.remove(pComp);
	}

	/**
	 * {@inheritDoc}
	 */
	public Dimension preferredLayoutSize(Container pParent)
	{
		Dimension preferred = new Dimension(0, 0);

		int maxHeight = 0;
		int maxWidth = 0;

		Insets insets = pParent.getInsets();
		for (Map.Entry<Component, CellConstraints> entry : constraintMap.entrySet())
		{
			Component component = entry.getKey();
			Dimension prefComp = component.getPreferredSize();
			if (prefComp.height > maxHeight)
			{
				maxHeight = prefComp.height;
			}
			if (prefComp.width > maxWidth)
			{
				maxWidth = prefComp.width;
			}
		}
		preferred.height = maxHeight * rows + insets.bottom + insets.top 
						   + margins.top + margins.bottom + verticalGap * rows - 1;
		preferred.width = maxWidth * columns + insets.left + insets.right 
						  + margins.left + margins.right + horizontalGap * columns - 1;
		
		return preferred;
	}

	/**
	 * {@inheritDoc}
	 */
	public Dimension minimumLayoutSize(Container parent)
	{
		return new Dimension(0, 0);
	}

	/**
	 * {@inheritDoc}
	 */
	public void layoutContainer(Container pParent)
	{
		synchronized (pParent.getTreeLock())
		{
			Dimension size = pParent.getSize();

			Insets insets = pParent.getInsets();
			
			int totalGapsWidth = (columns - 1) * horizontalGap;
			int totalGapsHeight = (rows - 1) * verticalGap;
			int totalWidth = size.width - insets.left - insets.right - margins.right - margins.left - totalGapsWidth;
			int totalHeight = size.height - insets.top - insets.bottom - margins.top - margins.bottom - totalGapsHeight;

			int columnSize = totalWidth / columns;
			int rowSize = totalHeight / rows;

			for (Map.Entry<Component, CellConstraints> entry : constraintMap.entrySet())
			{
				Component component = entry.getKey();
				CellConstraints constraints = entry.getValue();
				Rectangle cellBounds = new Rectangle();
				
				Insets concreteInsets = constraints.insets != null ? constraints.insets : CellConstraints.EMPTY_INSETS;
				cellBounds.x = constraints.gridX * totalWidth / columns + concreteInsets.left  + margins.left + horizontalGap * constraints.gridX;
				
				cellBounds.y = constraints.gridY * totalHeight / rows + concreteInsets.top  + margins.top + verticalGap * constraints.gridY;				
				
				cellBounds.width = (constraints.gridX +  constraints.gridWidth - 1) * totalWidth / columns - constraints.gridX * totalWidth / columns +
						columnSize - concreteInsets.right - concreteInsets.left + horizontalGap * (constraints.gridWidth - 1);
				
				cellBounds.height = (constraints.gridY +  constraints.gridHeight - 1) * totalHeight / rows - constraints.gridY * totalHeight / rows +
						rowSize - concreteInsets.bottom - concreteInsets.top + verticalGap * (constraints.gridHeight - 1);
				
				component.setBounds(cellBounds);
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void addLayoutComponent(Component pComp, Object pConstraints)
	{
		checkNotNull(pConstraints, "The constraints must not be null.");
		
		if (pConstraints instanceof CellConstraints)
		{
			setConstraints(pComp, (CellConstraints)pConstraints);
		}
		else
		{
			throw new IllegalArgumentException("Illegal constraint type " + pConstraints.getClass());
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public Dimension maximumLayoutSize(Container pTarget)
	{
		return new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE);
	}

	/**
	 * {@inheritDoc}
	 */
	public float getLayoutAlignmentX(Container pTarget)
	{
		return 0.5f;
	}

	/**
	 * {@inheritDoc}
	 */
	public float getLayoutAlignmentY(Container pTarget)
	{
		return 0.5f;
	}

	/**
	 * {@inheritDoc}
	 */
	public void invalidateLayout(Container pTarget)
	{
	}
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// User-defined methods
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
	/**
	 * Returns the number of columns.
	 * 
	 * @return the number of columns
	 */
	public int getColumns()
	{
		return columns;
	}
	
	/**
	 * Sets the column count.
	 * 
	 * @param pColumns the column count
	 */
	public void setColumns(int pColumns)
	{
		columns = pColumns;
	}

	/**
	 * Returns the number of rows.
	 * 
	 * @return the number of rows
	 */
	public int getRows()
	{
		return rows;
	}
	
	/**
	 * Sets the row count.
	 * 
	 * @param pRows the row count
	 */
	public void setRows(int pRows)
	{
		rows = pRows;
	}
	
	/**
	 * Gets the constraints for the specified <code>IComponent</code>.
	 *
	 * @param pComp the <code>IComponent</code> to be queried
	 * @return the constraint for the specified <code>IComponent</code>,
	 *         or null if component is null or is not present
	 *         in this layout
	 */
	public CellConstraints getConstraints(Component pComp)
	{
		return constraintMap.get(pComp);
	}
	
	/**
	 * Creates a constraint with the specified number of rows and columns.
	 * 
	 * @param pColumns the number of columns
	 * @param pRows the number of rows
	 * @return the constraint
	 */
	public CellConstraints getConstraints(int pColumns, int pRows)
	{
		return new CellConstraints(pColumns, pRows, 1, 1);
	}

	/**
	 * Creates a constraint with the specified number of rows and columns with
	 * the determined dimensions.
	 * 
	 * @param pColumns the number of columns
	 * @param pRows the number of rows 
	 * @param pWidth width of the content
	 * @param pHeight height of the content
	 * @return the constraint
	 */
	public CellConstraints getConstraints(int pColumns, int pRows, int pWidth, int pHeight)
	{
		return new CellConstraints(pColumns, pRows, pWidth, pHeight);
	}

	/**
	 * Creates a constraint with the specified number of rows and columns with
	 * the determined dimensions and insets.
	 * 
	 * @param pColumns the number of columns
	 * @param pRows the number of rows
	 * @param pWidth width of the content
	 * @param pHeight height of the content
	 * @param pInsets the determined insets
	 * @return the constraint
	 */
	public CellConstraints getConstraints(int pColumns, int pRows, int pWidth, int pHeight, Insets pInsets)
	{
		return new CellConstraints(pColumns, pRows, pWidth, pHeight, pInsets);
	}
	
	/**
	 * Puts the component and its constraints into the constraint Map.
	 * 
	 * @param pComponent the component
	 * @param pConstraints the components constraints
	 */
	public void setConstraints(Component pComponent, CellConstraints pConstraints)
	{
		checkNotNull(pComponent, "The component must not be null.");
		checkNotNull(pConstraints, "The constraints must not be null.");
		
		constraintMap.put(pComponent, (CellConstraints)pConstraints.clone());
	}
	
	/**
	 * Gets the margins.
	 * 
	 * @return the margins.
	 */
	public Insets getMargins()
	{
		return margins;
	}

	/**
	 * Sets the margins.
	 * 
	 * @param pMargins the margins
	 */
	public void setMargins(Insets pMargins)
	{
		if (pMargins == null)
		{
			margins = new Insets(0, 0, 0, 0);
		}
		else
		{
			margins = pMargins;
		}
	}

	/**
	 * Gets the horizontal gap.
	 * 
	 * @return the horizontal gap
	 */
	public int getHorizontalGap()
	{
		return horizontalGap;
	}

	/**
	 * Sets the horizontal gap.
	 * 
	 * @param pHorizontalGap the horizontal gap
	 */
	public void setHorizontalGap(int pHorizontalGap)
	{
		horizontalGap = pHorizontalGap;
	}

	/**
	 * Gets the vertical gap.
	 * 
	 * @return the vertical gap
	 */
	public int getVerticalGap()
	{
		return verticalGap;
	}

	/**
	 * Sets the vertical gap.
	 * 
	 * @param pVerticalGap the vertical gap
	 */
	public void setVerticalGap(int pVerticalGap)
	{
		verticalGap = pVerticalGap;
	}
	
	/**
	 * Throws a NullPointerException with the specified message if the given
	 * Object references null.
	 * 
	 * @param pReference the Object which shall be checked
	 * @param pMessage the specified message
	 */
	public static void checkNotNull(Object pReference, String pMessage)
	{
		if (pReference == null)
		{
			throw new NullPointerException(pMessage);
		}
	}
	
	//****************************************************************
	// Subclass definition
	//****************************************************************

	/**
	 * The <code>CellConstraint</code> class stores the X and Y position, the Width and Height and
	 * the insets of the component.
	 * 
	 * @author Thomas Lehner
	 */
	public static class CellConstraints implements Cloneable
	{
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		// Class members
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		
		/** Constant for empty insets. */
		private static final Insets	EMPTY_INSETS	= new Insets(0, 0, 0, 0);
		
		
		/** The position on the x-axis. */
		private int					gridX;

		/** The position on the y-axis. */
		private int					gridY;

		/** The width of the component in grids. */
		private int					gridWidth;

		/** The height of the component in grids. */
		private int					gridHeight;

		/** The specified insets of the component. */
		private Insets				insets;

		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		// Initialization
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		
		/**
		 * Constructs a new CellConstraint.
		 */
		public CellConstraints()
		{
			this(0, 0);
		}

		/**
		 * Constructs a new CellConstraint with the given parameters.
		 * 
		 * @param pGridX the position on the x-axis
		 * @param pGridY the position on the y-axis
		 */
		public CellConstraints(int pGridX, int pGridY)
		{
			this(pGridX, pGridY, 1, 1, EMPTY_INSETS);
		}
		
		/**
		 * Constructs a new CellConstraint with the given parameters.
		 * 
		 * @param pGridX the position on the x-axis
		 * @param pGridY the position on the y-axis
		 * @param pWidth the width of the component
		 * @param pHeight the height of the component
		 */
		public CellConstraints(int pGridX, int pGridY, int pWidth, int pHeight)
		{
			this(pGridX, pGridY, pWidth, pHeight, EMPTY_INSETS);
		}

		/**
		 * Constructs a new CellConstraint with the given parameters.
		 * 
		 * @param pGridX the position on the x-axis
		 * @param pGridY the position on the y-axis
		 * @param pGridWidth the width of the component
		 * @param pGridHeight the height of the component
		 * @param pInsets the specified insets
		 */
		public CellConstraints(int pGridX, int pGridY, int pGridWidth, int pGridHeight, Insets pInsets)
		{
            if (pGridX < 0)
            {
                throw new IndexOutOfBoundsException("The grid x must be a positive number.");
            }
            
            if (pGridY < 0)
            {
                throw new IndexOutOfBoundsException("The grid y must be a positive number.");
            }
            
            if (pGridWidth <= 0)
            {
                throw new IndexOutOfBoundsException("The grid width must be a positive number.");
            }

            if (pGridHeight <= 0)
            {
                throw new IndexOutOfBoundsException("The grid height must be a positive number.");
            }

			gridX = pGridX;
			gridY = pGridY;
			gridWidth = pGridWidth;
			gridHeight = pGridHeight;
			insets = pInsets;
		}

		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		// User-defined methods
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		
		/**
		 * Returns the x-position on the grid.
		 *
		 * @return the x-position
		 */
		public int getGridX()
		{
			return gridX;
		}

		/**
		 * Returns the y-position on the GridLayout.
		 *
		 * @return the y-position
		 */
		public int getGridY()
		{
			return gridY;
		}

		/**
		 * Returns the width on the GridLayout.
		 *
		 * @return the width
		 */
		public int getGridWidth()
		{
			return gridWidth;
		}

		/**
		 * Returns the height on the GridLayout.
		 *
		 * @return the height
		 */
		public int getGridHeight()
		{
			return gridHeight;
		}

		/**
		 * Returns the insets on the GridLayout.
		 *
		 * @return the insets
		 */
		public Insets getInsets()
		{
			return insets;
		}
		
		/**
		 * Sets the x-position on the GridLayout.
		 *
		 * @param pGridX the x-position to set
		 */
		public void setGridX(int pGridX)
		{
			gridX = pGridX;
		}

		/**
		 * Sets the y-position on the GridLayout.
		 *
		 * @param pGridY the x-position to set
		 */
		public void setGridY(int pGridY)
		{
			gridY = pGridY;
		}

		/**
		 * Sets the height on the GridLayout.
		 *
		 * @param pGridHeight the height to set
		 */
		public void setGridHeight(int pGridHeight)
		{
			gridHeight = pGridHeight;
		}

		/**
		 * Sets the width on the GridLayout.
		 *
		 * @param pGridWidth the height to set
		 */
		public void setGridWidth(int pGridWidth)
		{
			gridWidth = pGridWidth;	
		}

		/**
		 * Sets the width on the GridLayout.
		 *
		 * @param pInsets the insets to set
		 */
		public void setInsets(Insets pInsets)
		{
			insets = pInsets;
		}

		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	    // Overwritten methods
	    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

		@Override
		public Object clone()
		{
			try
			{
				CellConstraints c = (CellConstraints)super.clone();
				c.insets = (Insets)insets.clone();
				
				return c;
			}
			catch (CloneNotSupportedException e)
			{
				// This shouldn't happen, since we are Cloneable.
				throw new InternalError();
			}
		}
		
	}	//CellConstraints
	
}	//JVxGridLayout
