/*
 * Copyright 2009 SIB Visions GmbH
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 *
 *
 * History
 * 
 * 12.10.2008 - [JR] - creation
 * 30.10.2008 - [JR] - used ImageObserver for drawImage
 */
package com.sibvisions.rad.ui.swing.ext;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Insets;
import java.awt.RenderingHints;

import javax.swing.JComponent;

/**
 * The <code>JVxIcon</code> is a simple component with an image. The
 * image can be aligned or stretched.
 *  
 * @author Ren� Jahn
 */
public class JVxIcon extends JComponent 
                     implements JVxConstants
{
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Class members
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
	/** the image of the icon. */
	private Image image;
	
	/** the icon width. */
	private int iImageWidth = 0;
	
	/** the icon height. */
	private int iImageHeight = 0;
	
	/** the horizontal alignment of the image (default: {@link #CENTER}). */
	private int iHorizontalAlign = JVxConstants.CENTER;

	/** the vertical alignment of the background image (default: {@link #CENTER}). */
	private int iVerticalAlign = JVxConstants.CENTER;
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Initialization
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	/**
	 * Creates a new instance of <code>JVxIcon</code> without an image.
	 */
	public JVxIcon()
	{
		this(null);
	}
	
	/**
	 * Creates a new instance of <code>JVxIcon</code> based on an {@link Image}.
	 * 
	 * @param pImage the image
	 */
	public JVxIcon(Image pImage)
	{
		setImage(pImage);
	}
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Overwritten methods
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void paintComponent(Graphics pGraphics)
	{
		Insets ins = getInsets();
		Dimension size = getSize();

		if (isBackgroundSet())
		{
			pGraphics.setColor(getBackground());
			pGraphics.fillRect(0, 0, size.width, size.height);
		}
		
		if (image != null)
		{
			size.width -= ins.left + ins.right;
			size.height -= ins.top + ins.bottom;
			
			int iX;
			int iY;
			int iWidth;
			int iHeight;
			
			switch (iHorizontalAlign)
			{
				case LEFT:
					iX = ins.left;
					iWidth = iImageWidth;
					break;
				case CENTER:
					iX = ins.left + (size.width - iImageWidth) / 2;
					iWidth = iImageWidth;
					break;
				case RIGHT:
					iX = ins.left + size.width - iImageWidth;
					iWidth = iImageWidth;
					break;
				default:
					iX = ins.left;
					iWidth = size.width;
			}
			
			switch (iVerticalAlign)
			{
				case TOP:
					iY = ins.top;
					iHeight = iImageHeight;
					break;
				case CENTER:
					iY = ins.top + (size.height - iImageHeight) / 2;
					iHeight = iImageHeight;
					break;
				case BOTTOM:
					iY = ins.top + size.height - iImageHeight;
					iHeight = iImageHeight;
					break;
				default:
					iY = ins.top;
					iHeight = size.height;
			}
			
			((Graphics2D)pGraphics).setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);

			pGraphics.drawImage(image, iX, iY, iWidth, iHeight, this);
		}
	}

	/**
	 * Gets the preferred size of the icon dependent of the configured
	 * alignments. If an alignment is {@link #STRETCH} then the
	 * size of the component will be used. Otherwise the size
	 * of the image will be used.
	 * 
	 * @return the preferred size of the image
	 */
	@Override
	public Dimension getPreferredSize()
	{
		if (isPreferredSizeSet())
		{
			return super.getPreferredSize();
		}
		else
		{
			Insets ins = getInsets(); 
			return new Dimension(iImageWidth + ins.left + ins.right, iImageHeight + ins.top + ins.bottom);
		}
	}
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// User-defined methods
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	/**
	 * Sets the image for the icon.
	 * 
	 * @param pImage the image
	 */
	public void setImage(Image pImage)
	{
		image = pImage;
		
		int oldHeight = iImageHeight;
		int oldWidth = iImageWidth;
		if (image == null)
		{
			iImageHeight = 0;
			iImageWidth  = 0;
		}
		else
		{
			iImageHeight = pImage.getHeight(this);
			iImageWidth  = pImage.getWidth(this);
		}
		
		invalidate();
		if ((oldHeight != iImageHeight || oldWidth != iImageWidth) && !isPreferredSizeSet())
		{
			JVxUtil.revalidateAllDelayed(this);
		}
		
		repaint();
	}	
	
	/**
	 * Sets the horizontal alignment of the icon.
	 * 
	 * @param pAlignment the alignment
	 * @see JVxConstants
	 */
	public void setHorizontalAlignment(int pAlignment)
	{
		if (pAlignment == LEFT || pAlignment == CENTER || pAlignment == RIGHT || pAlignment == STRETCH)
		{
			if (pAlignment != iHorizontalAlign)
			{
				iHorizontalAlign = pAlignment;
				invalidate();
				repaint();
			}
		}
		else
		{
			throw new IllegalArgumentException("horizontalAlignment");
		}
	}
	
	/**
	 * Gets the horizontal alignment of the icon.
	 * 
	 * @return the alignment
	 * @see JVxConstants
	 */
	public int getHorizontalAlignment()
	{
		return iHorizontalAlign;
	}

	/**
	 * Sets the vertical alignment of the icon.
	 * 
	 * @param pAlignment the alignment
	 * @see JVxConstants
	 */
	public void setVerticalAlignment(int pAlignment)
	{
		if (pAlignment == TOP || pAlignment == CENTER || pAlignment == BOTTOM || pAlignment == STRETCH)
		{
			if (pAlignment != iVerticalAlign)
			{
				iVerticalAlign = pAlignment;
				invalidate();
				repaint();
			}
		}
		else
		{
			throw new IllegalArgumentException("verticalAlignment");
		}
	}

	/**
	 * Gets the vertical alignment of the icon.
	 * 
	 * @return the alignment
	 * @see JVxConstants
	 */
	public int getVerticalAlignment()
	{
		return iVerticalAlign;
	}
	
}	// JVxIcon
