/*
 * Copyright 2014 SIB Visions GmbH
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 *
 *
 * History
 * 
 * 22.11.2014 - [JR] - creation
 */
package com.sibvisions.rad.server;

import java.io.File;

import javax.rad.remote.IConnectionConstants;
import javax.rad.server.IServer;
import javax.rad.server.ISession;
import javax.rad.server.ServerContext;
import javax.servlet.http.HttpServletRequest;

import com.sibvisions.rad.server.http.HttpContext;
import com.sibvisions.util.type.StringUtil;

/**
 * The <code>ServerContextImpl</code> is an internal {@link javax.rad.server.ServerContext} implementation.
 * 
 * @author Ren� Jahn
 */
public class ServerContextImpl extends ServerContext
{
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    // Class members
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    /** the server. */
    private IServer server;
    
    /** the session. */
    private WrappedSession session;
    
    /** the system identifier. */
    private String sIdentifier;
    
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    // Initialization
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    /**
     * Creates a new instance of <code>ServerContextImpl</code>.
     * 
     * @param pServer the server
     */
    ServerContextImpl(Server pServer)
    {
        server = pServer;
        
        sIdentifier = createSystemIdentifier();
        
        setInstance(this);
    }
    
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    // Abstract methods implementation
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**
     * {@inheritDoc}
     */
    @Override
    protected void destroy()
    {
        setInstance(null);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public ISession getSession()
    {
        return session;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public String getSystemIdentifier()
    {
        return sIdentifier;
    }
    
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    // User-defined methods
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**
     * Sets the session.
     * 
     * @param pSession the session
     */
    void setSession(ISession pSession)
    {
        if (pSession == null)
        {
            session = null;
        }
        else
        {
            if (pSession instanceof WrappedSession)
            {
                session = (WrappedSession)pSession;
            }
            else
            {
                session = new WrappedSession((AbstractSession)pSession);
            }
            
            if (StringUtil.isEmpty(sIdentifier))
            {
                //don't use getProperty, because it changes the last access time and this means that it won't timeout
                Object obj = session.getProperties().get(IConnectionConstants.PREFIX_SERVER + IConnectionConstants.PREFIX_REQUEST + "systemIdentifier");
                
                if (obj != null)
                {
                    sIdentifier = obj.toString();
                }
            }
        }
    }
    
    /**
     * Gets the server.
     * 
     * @return the server
     */
    public IServer getServer()
    {
        return server;
    }

    /**
     * Creates the system identifier.
     * 
     * @return the identifier
     */
    private String createSystemIdentifier()
    {
        String sIdent = "";
        
        HttpContext ctxt = HttpContext.getCurrentInstance();
        
        if (ctxt != null)
        {
            Object oRequest = ctxt.getRequest();
            
            if (oRequest instanceof HttpServletRequest)
            {
                String sURI = ((HttpServletRequest)oRequest).getRequestURL().toString();
                
                sIdent = sURI;
            }
            else
            {
                //e.g. PortletRequest 
            }
        }
        else
        {
            //no http context available -> check working directory
            
            File fiDir = new File("");
            
            sIdent = fiDir.getAbsolutePath();
        }
        
        return sIdent;
    }
    
}   // ServerContextImpl
