/*
 * Copyright 2009 SIB Visions GmbH
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 *
 *
 * History
 *
 * 12.05.2009 - [RH] - creation.
 * 23.11.2009 - [RH] - ColumnMetaData && PrimaryKey Column is replaced with MetaData class
 * 02.03.2010 - [RH] - reorganized MetaData -> ServerMetaData, ColumnMetaData -> ServerColumnMetaData
 * 10.03.2010 - [JR] - set NLS_COMP='BINARY'
 * 27.03.2010 - [JR] - #92: default value support    
 * 28.03.2010 - [JR] - #47: getAllowedValues implemented
 * 06.04.2010 - [JR] - #115: getUKs: prepared statement closed  
 * 06.05.2010 - [JR] - open: close statement(s)     
 * 09.10.2010 - [JR] - #114: used CheckConstraintSupport to detect allowed values       
 * 19.11.2010 - [RH] - getUKs, getPKs return Type changed to a <code>Key</code> based result.         
 * 29.11.2010 - [RH] - getUKs Oracle select statement fixed, that it only returns UKs - no PKs. 
 * 01.12.2010 - [RH] - getFKs Oracle select statement fixed, that also returns FKs over UKs.        
 * 14.12.2010 - [RH] - getUKS is solved in DBAccess.
 * 23.12.2010 - [RH] - #227: getFKs returned PK <-> FK columns wrong related, wrong sort fixed!
 * 28.12.2010 - [RH] - #230: quoting of all DB objects like columns, tables, views. 
 * 03.01.2011 - [RH] - schema detecting made better in getColumnMetaData()
 * 06.01.2011 - [JR] - #234: used ColumnMetaDataInfo
 * 24.02.2011 - [RH] - #295: just return the PK, UKs and FKs for the table && schema.
 * 11.03.2011 - [RH] - #308: DB specific automatic quoting implemented          
 * 19.07.2011 - [RH] - #432: OracleDBAccess return list of UKs wrong.   
 * 21.07.2011 - [RH] - #436: OracleDBAccess and PostgresDBAccess should translate JVx quotes in specific insert                      
 * 18.11.2011 - [RH] - #510: All XXDBAccess should provide a SQLException format method 
 * 18.03.2013 - [RH] - #632: DBStorage: Update on Synonym (Oracle) doesn't work - Synonym Support implemented
 * 15.10.2013 - [RH] - #837: DBOracleAccess MetaData determining is very slow in 11g
 * 15.05.2014 - [JR] - #1038: CommonUtil.close used                            
 */
package com.sibvisions.rad.persist.jdbc;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.rad.model.condition.ICondition;
import javax.rad.model.datatype.BigDecimalDataType;
import javax.rad.model.datatype.IDataType;
import javax.rad.model.datatype.TimestampDataType;
import javax.rad.persist.ColumnMetaData;
import javax.rad.persist.DataSourceException;

import oracle.sql.Datum;

import com.sibvisions.util.ArrayUtil;
import com.sibvisions.util.log.ILogger.LogLevel;
import com.sibvisions.util.type.CommonUtil;
import com.sibvisions.util.type.StringUtil;

/**
 * The <code>OracleDBAccess</code> is the implementation for Oracle databases.<br>
 *  
 * @see com.sibvisions.rad.persist.jdbc.DBAccess
 * 
 * @author Roland H�rmann
 */
public class OracleDBAccess extends DBAccess
{
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Constants
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	// The ultimate Oracle Meta Data Optimization!
	
	/** The select statement to get the Unique keys in Oracle. */
	private static String sUKSelect = "SELECT cons.constraint_name " +
									      "FROM all_constraints cons " +
									      "WHERE cons.table_name = ? " + 
	                                      "AND cons.constraint_type = 'U' " +
	                                      "AND cons.owner = ? ";
			
	/** The select statement to get the columns from an constraint in Oracle. */
	private static String sConstraintColumnsSelect = "SELECT cols.column_name " +
	                                                       ",cols.table_name " +
										    "FROM all_cons_columns cols " +
										    "WHERE cols.owner = ? " +
										    "AND cols.constraint_name = ? " +
										    "ORDER BY POSITION"; 
	
	/** The select statement to get the Primary key in Oracle. */
	private static String sPKSelect = "SELECT cons.constraint_name " +
									    "FROM all_constraints cons " +
									    "WHERE cons.constraint_type = 'P' " +
									    "AND cons.table_name = ? " +
										"AND cons.owner = ?"; 
	
	/** The select statement to get the Foreign keys in Oracle. */
	private static String sFKSelect =    "SELECT  c.constraint_name   fk_name " +
	                                           " ,r_owner             pktable_schem " + 
											   " ,c.r_constraint_name pk_name " +
			                                "FROM all_constraints c " +
			                               "WHERE c.table_name = ? " +
			                                 "AND c.constraint_type = 'R' " +
			                                 "AND c.owner = ? " +
			                                 "ORDER BY c.owner, c.table_name, c.constraint_name";
    
	/** the select statement to get the Check constraints in Oracle. */
	private static String sCheckSelect = "select /*+ rule */ search_condition " +
	                                       "from user_constraints " +
	                                      "where constraint_type = 'C' " +
	                                        "and generated = 'USER NAME' " +
	                                        "and status = 'ENABLED' " +
	                                        "and table_name = ?";
	
	/** The select statement to get the Synonyms. */
	private static String sSynonymSelect = "select s.table_owner, s.table_name, s.db_link " +
										   "FROM user_synonyms s " +
										   "WHERE s.synonym_name = ?";			 
    
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Initialization
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	/**
	 * Constructs a new OracleDBAccess Object.
	 */
	public OracleDBAccess()
	{
		super();		
		
		setDriver("oracle.jdbc.OracleDriver");	
	}
		
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Overwritten methods
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			
	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getDatabaseSpecificLockStatement(String pWritebackTable, ServerMetaData pServerMetaData, ICondition pPKFilter) throws DataSourceException
	{
		return super.getDatabaseSpecificLockStatement(pWritebackTable, pServerMetaData, pPKFilter) + " NOWAIT";											
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object[] insertDatabaseSpecific(String pWriteBackTable, String pInsertStatement, ServerMetaData pServerMetaData, 
                                           Object[] pNewDataRow, String pDummyColumn)  throws DataSourceException
    {
		return insertOracle(pWriteBackTable, pInsertStatement, pServerMetaData, pNewDataRow, pDummyColumn);
    }
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void open() throws DataSourceException
	{
		super.open();

		Statement stmt = null;
		
		try
		{
			stmt = getConnection().createStatement();
			
			stmt.executeUpdate("ALTER SESSION SET NLS_COMP='BINARY'");			
			stmt.executeUpdate("ALTER SESSION SET NLS_SORT='BINARY'");
		}
		catch (SQLException ex)
		{
			// Try silent to change nls_sort, nls_comp
		}
		finally
		{
		    CommonUtil.close(stmt);
		}
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected List<Key> getUniqueKeysIntern(String pCatalog, 
					  			 String pSchema, 
					  			 String pTable) throws DataSourceException
	{
		ResultSet 		  rsResultSet = null;
		PreparedStatement psResult = null;
		ResultSet 		  rsResultSetColumns = null;
		PreparedStatement psResultColumns = null;

		try
		{	
			ArrayUtil<Key>  auResult           = new ArrayUtil<Key>();
			ArrayUtil<Name> auUniqueKeyColumns = new ArrayUtil<Name>();
			
			long lMillis = System.currentTimeMillis();
			
			psResult = getPreparedStatement(sUKSelect, false);
			psResultColumns = getPreparedStatement(sConstraintColumnsSelect, false);

			psResult.setString(1, removeQuotes(pTable));
			psResult.setString(2, removeQuotes(pSchema));
			
			rsResultSet = psResult.executeQuery();

			while (rsResultSet.next())
			{
				String sUKName = rsResultSet.getString("CONSTRAINT_NAME");
				
				psResultColumns.setString(1, removeQuotes(pSchema));
				psResultColumns.setString(2, sUKName);
				
				rsResultSetColumns = psResultColumns.executeQuery();
					
				while (rsResultSetColumns.next())
				{
					auUniqueKeyColumns.add(new Name(rsResultSetColumns.getString("COLUMN_NAME"), 
							                        quote(rsResultSetColumns.getString("COLUMN_NAME"))));
				}
				
				CommonUtil.close(rsResultSetColumns);

				Key uk = new Key(sUKName, auUniqueKeyColumns.toArray(new Name[auUniqueKeyColumns.size()]));
				auResult.add(uk);
				auUniqueKeyColumns.clear();
			}
			
            if (isLogEnabled(LogLevel.DEBUG))
            {
                debug("getUKs(", pTable, ") in ", Long.valueOf((System.currentTimeMillis() - lMillis)), "ms");
            }
			
			return auResult;
		}
		catch (SQLException sqlException)
		{
			throw new DataSourceException("Unique Keys couldn't determined from database! - " + pTable, formatSQLException(sqlException));
		}		
		finally
		{
		    CommonUtil.close(rsResultSet, psResult, rsResultSetColumns, psResultColumns);
		}			
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Key getPrimaryKeyIntern(String pCatalog, String pSchema, String pTable) throws DataSourceException
	{
		ResultSet rsResultSet = null;
		PreparedStatement psResult = null;
		try
		{	
			Key result = null;
			ArrayUtil<Name> auPrimaryKeyColumns = new ArrayUtil<Name>();
			
			long lMillis  = System.currentTimeMillis();
			psResult = getPreparedStatement(sPKSelect, false);
			psResult.setString(1, removeQuotes(pTable));
			psResult.setString(2, removeQuotes(pSchema));
			rsResultSet = psResult.executeQuery();
			
			if (rsResultSet.next())
			{
				String sPKName = rsResultSet.getString("CONSTRAINT_NAME");
				
				CommonUtil.close(rsResultSet, psResult);
				
				psResult = getPreparedStatement(sConstraintColumnsSelect, false);
				psResult.setString(1, removeQuotes(pSchema));
				psResult.setString(2, sPKName);
				rsResultSet = psResult.executeQuery();
				
				if (rsResultSet.next())
				{				
					do
					{
						auPrimaryKeyColumns.add(new Name(rsResultSet.getString("COLUMN_NAME"), quote(rsResultSet.getString("COLUMN_NAME"))));
					}
					while (rsResultSet.next());
	
					if (auPrimaryKeyColumns.size() > 0)
					{
						result = new Key(sPKName, auPrimaryKeyColumns.toArray(new Name[auPrimaryKeyColumns.size()]));
					}
				}
			}
			
            if (isLogEnabled(LogLevel.DEBUG))
            {
                debug("getPK(", pTable, ") in ", Long.valueOf((System.currentTimeMillis() - lMillis)), "ms");
            }
			
			return result;
		}
		catch (SQLException sqlException)
		{
			throw new DataSourceException("Primary Key couldn't determined from database! - " + pTable, formatSQLException(sqlException));
		}		
		finally
		{
		    CommonUtil.close(rsResultSet, psResult);
		}			
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected List<ForeignKey> getForeignKeysIntern(String pCatalog, String pSchema, String pTable) throws DataSourceException
	{
		PreparedStatement psFKs = null;
		ResultSet         rsFKs = null;
		ResultSet 		  rsResultSetColumns = null;
		PreparedStatement psResultColumns = null;
		try
		{
			ArrayUtil<ForeignKey> auForeignKeys = new ArrayUtil<ForeignKey>();

			long lMillis = System.currentTimeMillis();

			String sCatalog = getConnection().getCatalog();
			
			psFKs = getPreparedStatement(sFKSelect, false);
			psResultColumns = getPreparedStatement(sConstraintColumnsSelect, false);
			
			psFKs.setString(1, removeQuotes(pTable));
			psFKs.setString(2, removeQuotes(pSchema));

			rsFKs = psFKs.executeQuery();			
			while (rsFKs.next())
			{
				String sFKName  = rsFKs.getString("FK_NAME");
				String sPKName  = rsFKs.getString("PK_NAME");
				String sPKTableSchema = rsFKs.getString("PKTABLE_SCHEM");
				
				String sPKTable = null;
				
				ArrayUtil<Name> auPKColumns = new ArrayUtil<Name>();
				ArrayUtil<Name> auFKColumns = new ArrayUtil<Name>();

				psResultColumns.setString(1, removeQuotes(pSchema));
				psResultColumns.setString(2, sFKName);
				rsResultSetColumns = psResultColumns.executeQuery();
				
				while (rsResultSetColumns.next())
				{
					auFKColumns.add(new Name(rsResultSetColumns.getString("COLUMN_NAME"), 
							                 quote(rsResultSetColumns.getString("COLUMN_NAME"))));
				}
				
				CommonUtil.close(rsResultSetColumns);
				
				psResultColumns.setString(1, sPKTableSchema);
				psResultColumns.setString(2, sPKName);				
				rsResultSetColumns = psResultColumns.executeQuery();
				
				while (rsResultSetColumns.next())
				{
					if (sPKTable ==  null)
					{
						sPKTable = rsResultSetColumns.getString("TABLE_NAME");
					}
					auPKColumns.add(new Name(rsResultSetColumns.getString("COLUMN_NAME"), 
							                 quote(rsResultSetColumns.getString("COLUMN_NAME"))));
				}
				
				CommonUtil.close(rsResultSetColumns);

				ForeignKey fkForeignKey = new ForeignKey(
						new Name(sPKTable, quote(sPKTable)), 
						new Name(sCatalog, quote(sCatalog)), 
						new Name(sPKTableSchema, quote(sPKTableSchema)));

				fkForeignKey.setFKName(sFKName);
				fkForeignKey.setFKColumns(auFKColumns.toArray(new Name[auFKColumns.size()]));
				fkForeignKey.setPKColumns(auPKColumns.toArray(new Name[auPKColumns.size()]));
				auForeignKeys.add(fkForeignKey);

				auPKColumns.clear();
				auFKColumns.clear();				
			}

            if (isLogEnabled(LogLevel.DEBUG))
            {
                debug("getFKs(", pTable, ") in ", Long.valueOf(System.currentTimeMillis() - lMillis), "ms");
            }

			return auForeignKeys;
		}
		catch (SQLException sqlException)
		{
			throw new DataSourceException("Foreign Keys couldn't determined from database! - " + pTable, formatSQLException(sqlException));
		}
		finally
		{
		    CommonUtil.close(rsFKs, psFKs, rsResultSetColumns, psResultColumns);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected String getTableForSynonymIntern(String pSynomyn) throws DataSourceException
	{
		PreparedStatement psResult = null;
		ResultSet rsResultSet = null;
		try
		{	
			long lMillis = System.currentTimeMillis();
			
			psResult = getPreparedStatement(sSynonymSelect, false);
			
			psResult.setString(1, removeQuotes(pSynomyn));
			rsResultSet = psResult.executeQuery();
			if (!rsResultSet.next())
			{
				return pSynomyn;
			}
			
			// Create schema.table@db_link
			String sSchema = rsResultSet.getString("TABLE_OWNER");
			String sTable  = rsResultSet.getString("TABLE_NAME");
			String sDBLink = rsResultSet.getString("DB_LINK");

			StringBuilder sRealTable = new StringBuilder();
			
			if (sSchema != null)
			{
				sRealTable.append(sSchema);					
				sRealTable.append('.');					
			}

			sRealTable.append(sTable);					

			if (sDBLink != null)
			{
				sRealTable.append('@');					
				sRealTable.append(sDBLink);					
			}
			
            if (isLogEnabled(LogLevel.DEBUG))
            {
                debug("getTableForSynonym(", pSynomyn, ") in ", Long.valueOf((System.currentTimeMillis() - lMillis)), "ms");
            }
			
			return sRealTable.toString();
		}
		catch (SQLException sqlException)
		{
			throw new DataSourceException("Synonyms couldn't determined from database! - " + pSynomyn, formatSQLException(sqlException));
		}		
		finally
		{
		    CommonUtil.close(rsResultSet, psResult);
		}			
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Map<String, Object> getDefaultValuesIntern(String pCatalog, String pSchema, String pTable) throws DataSourceException
	{
		return super.getDefaultValuesIntern(pCatalog, pSchema, pTable.toUpperCase());
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Object translateDefaultValue(String pColumnName, int pDataType, String pDefaultValue) throws Exception
	{
		//Oracle JDBC returns 'value'\n
		return super.translateDefaultValue(pColumnName, pDataType, StringUtil.removeQuotes(pDefaultValue, "'"));
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected Map<String, Object[]> getAllowedValuesIntern(String pCatalog, String pSchema, String pTable) throws DataSourceException
	{
		PreparedStatement psCheck = null;
		
		ResultSet resCheck = null;
		
		Hashtable<String, Object[]> htAllowed;
		
		Hashtable<String, List<String>> htFoundValues = null;
		
		
		try
		{
			psCheck = getPreparedStatement(sCheckSelect, false);
			psCheck.setString(1, pTable);
			
			resCheck = psCheck.executeQuery();
			
			//detect all possible values
			
			while (resCheck.next())
			{
				htFoundValues = CheckConstraintSupport.parseCondition(resCheck.getString(1), htFoundValues, true);
			}			
			
			//interpret values
			
			htAllowed = CheckConstraintSupport.translateValues(this, pCatalog, pSchema, pTable, htFoundValues);
		}
		catch (SQLException sqle)
		{
			throw new DataSourceException("Can't access check constraints for: '" + pTable + "'", formatSQLException(sqle));
		}
		finally
		{
		    CommonUtil.close(resCheck, psCheck);
		}
		
		return htAllowed;
	}
  
	/**
	 * {@inheritDoc} 
	 */
	@Override
	protected Object convertDatabaseSpecificObjectToValue(ServerColumnMetaData pColumnMetaData, Object pValue) throws SQLException
	{
		if (pValue instanceof Datum)
		{
			return ((Datum)pValue).timestampValue();
		}
		
		return pValue;
	}
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// User-defined methods
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
	/**
	 * Returns the newly inserted row from an Oracle Database. <br>
	 * It uses RETURNING .. INTO to get the primary key values back from the database. 
	 * 
	 * @param pTablename		the table to use for the insert
	 * @param pInsertStatement	the SQL Statement to use for the insert
	 * @param pServerMetaData	the meta data to use.
	 * @param pNewDataRow		the new IDataRow with the values to insert
	 * @param pDummyColumn		true, if all writeable columns are null, but for a correct INSERT it have
	 *                          to be minimum one column to use in the syntax.
	 * @return the newly inserted row from an Oracle Database.
	 * @throws DataSourceException
	 *             if an <code>Exception</code> occur during insert the <code>IDataRow</code> 
	 *             to the storage
	 */	
	private Object[] insertOracle(String pTablename, String pInsertStatement, ServerMetaData pServerMetaData, 
			                      Object[] pNewDataRow, String pDummyColumn)  throws DataSourceException
	{
		StringBuffer sInsertStatement = new StringBuffer("BEGIN " + pInsertStatement);
		
		// use RETURNING to get all PK column values filled in in from the trigger
		sInsertStatement.append(" RETURNING ");
		
		int[] pPKColumnIndices = pServerMetaData.getPrimaryKeyColumnIndices();
		for (int i = 0; pPKColumnIndices != null && i < pPKColumnIndices.length; i++)
		{
			if (i > 0)
			{
				sInsertStatement.append(", ");
			}
			
			sInsertStatement.append(pServerMetaData.getServerColumnMetaData(pPKColumnIndices[i]).getColumnName().getQuotedName());
		}
		sInsertStatement.append(" INTO ");
		
		for (int i = 0; pPKColumnIndices != null && i < pPKColumnIndices.length; i++)
		{
			if (i > 0)
			{
				sInsertStatement.append(", ");
			}
			sInsertStatement.append("?");
		}
	
		sInsertStatement.append("; END;");

		CallableStatement csInsert = null;
		try
		{
			// #436 - OracleDBAccess and PostgresDBAccess should translate JVx quotes in specific insert
			String sSQL = translateQuotes(sInsertStatement.toString());
			debug("executeSQL->", sSQL);
			csInsert = getConnection().prepareCall(sSQL);
		
			ServerColumnMetaData[] cmdServerColumnMetaData = pServerMetaData.getServerColumnMetaData();
			int[] iaWriteables = pServerMetaData.getWritableColumnIndices();
			
			int iLastIndex = 0;
			if (pDummyColumn == null)
			{
				iLastIndex = setColumnsToStore(csInsert, cmdServerColumnMetaData, iaWriteables, pNewDataRow, null);
			}
			else
			{
				for (int i = 0; i < cmdServerColumnMetaData.length; i++)
				{
					if (cmdServerColumnMetaData[i].getColumnName().getQuotedName().equals(pDummyColumn))
					{
						csInsert.setObject(1, null, cmdServerColumnMetaData[i].getSQLType());
						break;
					}
				}					
				iLastIndex = 1;
			}
			
			for (int i = 0; pPKColumnIndices != null && i < pPKColumnIndices.length; i++)
			{
				int iSQLType;

				IDataType dtDataType = ColumnMetaData.createDataType(cmdServerColumnMetaData[pPKColumnIndices[i]].getColumnMetaData());
				if (dtDataType instanceof BigDecimalDataType)
				{
					iSQLType = java.sql.Types.NUMERIC;
				}
				else if (dtDataType instanceof TimestampDataType)
				{
					iSQLType = java.sql.Types.TIMESTAMP;
				}
				else
				{
					iSQLType = java.sql.Types.CHAR;
				}
									
				csInsert.registerOutParameter(iLastIndex + i + 1, iSQLType);
			}
		
			if (executeUpdate(csInsert) == 1)
			{
				// use RETURNING to get the PK column values filled in by the trigger
				// get the out parameters, and set the PK columns
				
				for (int i = 0; pPKColumnIndices != null && i < pPKColumnIndices.length; i++)
				{
					pNewDataRow[pPKColumnIndices[i]] = csInsert.getObject(iLastIndex + i + 1);
				}
				return pNewDataRow;
			}
			throw new DataSourceException("Insert failed ! - Result row count != 1 ! - " +  sInsertStatement);
		}
		catch (SQLException sqlException)
		{			
			throw new DataSourceException("Insert failed! - " + sInsertStatement, formatSQLException(sqlException));
		}
		finally
		{
		    CommonUtil.close(csInsert);
		}
	}
	
	/** 
	 * {@inheritDoc}
	 */
	@Override
	protected TableInfo getTableInfoIntern(String pWriteBackTable) throws DataSourceException
	{	
		TableInfo tableInfo = super.getTableInfoIntern(pWriteBackTable);

		String schema = tableInfo.getSchema();
		if (schema == null)
		{
			schema = getUsername().toUpperCase();
		}
		String table = tableInfo.getTable();
		if (table != null && !table.startsWith(QUOTE) && !table.endsWith(QUOTE))
		{
			table = table.toUpperCase();
		}
		
		return new TableInfo(tableInfo.getCatalog(), schema, table);
	}
	
} 	// OracleDBAccess
