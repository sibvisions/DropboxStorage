/*
 * Copyright 2009 SIB Visions GmbH
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 *
 *
 * History
 *
 * 01.10.2008 - [RH] - creation.
 * 02.11.2008 - [RH] - extends now MemDataSource 
 * 12.11.2008 - [RH] - getPrimaryKey bug with Oracle fixed. (Databases without Catalogs)
 * 17.11.2008 - [RH] - setFilterParameters changes to allow null Parameters
 * 19.11.2008 - [RH] - filter redesign
 * 23.11.2008 - [RH] - Statement cache disabled, Oracle Insert with RETURNING added
 * 26.11.2008 - [RH] - lockAndRefetch added()
 * 27.11.2008 - [RH] - throw Exceptions optimized
 * 30.01.2009 - [RH] - fetch bug with SelectColumns fixed
 * 13.05.2009 - [RH] - reviewed, separated into one DBAccess for each different Database
 * 12.06.2009 - [JR] - toString: used StringBuilder [PERFORMANCE]
 * 14.07.2009 - [JR] - getSelectStatement: missing from clause exception throwed
 *                     insert, update, delete: missing writebackTable exception throwed
 *                     getDatabaseSpecificLockStatement: missing writebackTable exception throwed
 * 06.10.2009 - [RH] - supportsGetGeneratedKeys add, used in DerbyDBAccess to set it to true, because of the derby bug
 * 14.10.2009 - [RH] - sql to java type conversion added (->serializeable!)
 *                     bug fix CLOB, -> CLOB is interpreted as a StringType instead of BinaryTyp.
 *                     CLOB, BLOB size is default Integer.MAX_VALUE
 * 15.10.2009 - [JR] - fetch: pMinimumRowCount < 0                     
 * 23.10.2009 - [HM] - Properties changes to get/set username, url, driver, password                      
 * 23.10.2009 - [HM] - static getDBAccess added
 *            - [JR] - getDBAccess: checked null  
 * 27.10.2009 - [RH] - setNull, for empty insert/update [BUGFIX]
 * 23.11.2009 - [RH] - use of MetaData instead of MetaDataColumn[] and PK column String[].
 *                     code optimization      
 * 04.12.2009 - [RH] - QueryColumns with alias bug fixed            
 *                     getUKs, getPK return null if none is found. Exceptions will be logged!
 * 09.12.2009 - [JR] - set/getDBProperty implemented
 *                   - open, toString: hide username password form the property output
 * 02.03.2010 - [RH] - reorganized MetaData -> ServerMetaData, ColumnMetaData -> ServerColumnMetaData
 * 08.03.2010 - [RH] - if in update() is determined, that no values are changed, then it returns instead of null, 
 *                     the old value.
 * 10.03.2010 - [RH] - Exception didn't thrown with duplicate column names in getColumnMetaData()
 *                     Ticket #81 fixed
 * 13.03.2010 - [JR] - #90: fetch: handled different Number instances as BigDecimal          
 * 19.03.2010 - [RH] - if in update() no rows changed, then try to find that row, if that doesn't exist, then insert it.
 * 25.03.2010 - [JR] - #92: getDefaultValues, translateDefaultValue implemented            
 * 28.03.2010 - [JR] - #47: getAllowedValues implemented  
 * 30.03.2010 - [RH] - updateAnsiSQL() + updateDatabaseSpecific add for DB specific support.
 * 06.04.2010 - [JR] - #115: closed all ResultSets
 * 21.04.2010 - [JR] - createDataType replaced with (ServerColumnMetaData).getDataType()   
 * 18.06.2010 - [JR] - fetch: optimized type detection and reduced method calls in for loop        
 * 11.10.2010 - [RH] - #91: the automatic link column name is now build independent (foregnkey column name) and with an optional TranslationMap.
 * 20.10.2010 - [JR] - #188: UK detection returns an empty row if no UK was found     
 * 25.10.2010 - [JR] - #196: setConnection implemented and used in open/close
 *                   - #195: getDBAccess(java.sql.Connection) implemented
 * 19.11.2010 - [RH] - getUKs, getPKs return Type changed to a <code>Key</code> based result.     
 * 22.11.2010 - [RH] - executeSQL added.          
 * 23.11.2010 - [RH] - setSQLTypeName on ServerColumnMetaData used.   
 * 01.12.2010 - [RH] - getPKs set PKName corrected.
 * 14.12.2010 - [RH] - #222: getUKs return no PK anymore, just UKs
 * 15.12.2010 - [RH] - better logging in executeXXX methods.
 * 23.12.2010 - [RH] - #224: wrong AutomaticLinkColumnName fixed (if PK with one column, and FK with more the one column used, + all _ID are remove)
 *                                                                 duplicate use of ForeignKeys over partly the same columns fixed.   
 * 28.12.2010 - [RH] - #230: quoting of all DB objects like columns, tables, views. 
 * 03.01.2011 - [RH] - Schema detecting made better in getColumnMetaData()
 *                   - #232: get/setQuoting() on/off , 
 *                   - #136: Mysql PK refetch not working -> extract the plan table without schema.
 * 06.01.2011 - [JR] - #234: introduced ColumnMetaDataInfo 
 * 29.01.2011 - [JR] - #211: getDefaultAllowedValues implemented
 *                   - translateValue: check null explicitly
 * 16.02.2011 - [JR] - getQueryColumns: code review      
 * 11.03.2011 - [RH] - #308: DB specific automatic quoting implemented       
 * 25.03.2011 - [RH] - removeDBSpecificquotes added.   
 * 28.04.2011 - [RH] - #341:  LikeReverse Condition, LikeReverseIgnoreCase Condition   
 *                     createReplace for DB added. Standard implementation is ANSI SQL.
 * 06.06.2011 - [JR] - #381: fixed column name usage      
 * 12.07.2011 - [RH] - #420: DBStorage creates too long alias names for oracle: ORA-00972: Bezeichner ist zu lang      
 * 22.07.2011 - [RH] - #440: DBAccess.insert return null if no auto increment column in table
 * 31.07.2011 - [RH] - #447: if getMaxColumnNameLength() return 0, we should interprete it as unlimmited
 * 14.09.2011 - [JR] - #470: splitSchemaTable, set/getDefaultSchema implemented
 * 18.11.2011 - [RH] - #510: All XXDBAccess should provide a SQLException format method 
 * 22.11.2011 - [JR] - #515: open now checks the transaction isolation level
 * 14.12.2011 - [JR] - insert/update logging
 * 17.12.2011 - [JR] - #528: createStorage implemented
 * 30.01.2012 - [RH] - #544: In databases with default lower case column names, the default labels in the RowDefinition are wrong  -> setLabel removed!
 * 05.03.2012 - [HM] - #552:  Reverted createStorage, added functionality in DBAccess
 * 13.03.2012 - [RH] - #562: DBAccess getColumnMetaData() should determine writeable columns case insensitive
 * 08.05.2012 - [JR] - #575: convert value(s) to database specific value(s) 
 * 20.11.2012 - [JR] - #589: use JNDI for connection/dbaccess detection
 *                   - open now checks isOpen
 * 09.03.2012 - [JR] - getSQL: beautifying spaces                   
 * 18.03.2013 - [RH] - #632: DBStorage: Update on Synonym (Oracle) doesn't work - Synonym Support implemented
 * 11.07.2013 - [JR] - #727: insert checks PrimaryKeyType
 * 19.07.2013 - [RH] - #733: AfterWhereClause in DBStorage makes SQL Exception
 * 08.09.2013 - [JR] - #789: set url and username
 * 18.10.2013 - [RH] - #843: Not all FKs creates Auto Link CellEditors
 * 27.03.2014 - [JR] - set auto commit to true
 * 31.03.2014 - [JR] - #996: simple modification state
 * 06.05.2014 - [RZ] - #1029: added overload for fetch() which also accepts an ORDER BY string.
 * 15.05.2014 - [JR] - #1038: CommonUtil.close used   
 * 16.10.2014 - [JR] - #1141: setAutoCommit added       
 *                   - #1142: close now calls commit or rollback   
 * 13.12.2014 - [JR] - refactored JNDI handling a little bit (especiall DBCredentials support)                                  
 */
package com.sibvisions.rad.persist.jdbc;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.rad.io.IFileHandle;
import javax.rad.io.RemoteFileHandle;
import javax.rad.model.MetaDataCacheOption;
import javax.rad.model.ModelException;
import javax.rad.model.SortDefinition;
import javax.rad.model.condition.And;
import javax.rad.model.condition.CompareCondition;
import javax.rad.model.condition.Equals;
import javax.rad.model.condition.Greater;
import javax.rad.model.condition.GreaterEquals;
import javax.rad.model.condition.ICondition;
import javax.rad.model.condition.Less;
import javax.rad.model.condition.LessEquals;
import javax.rad.model.condition.Like;
import javax.rad.model.condition.LikeIgnoreCase;
import javax.rad.model.condition.LikeReverse;
import javax.rad.model.condition.LikeReverseIgnoreCase;
import javax.rad.model.condition.Not;
import javax.rad.model.condition.OperatorCondition;
import javax.rad.model.condition.Or;
import javax.rad.model.datatype.BigDecimalDataType;
import javax.rad.model.datatype.BinaryDataType;
import javax.rad.model.datatype.BooleanDataType;
import javax.rad.model.datatype.IDataType;
import javax.rad.model.datatype.StringDataType;
import javax.rad.model.datatype.TimestampDataType;
import javax.rad.persist.DataSourceException;
import javax.rad.remote.IConnectionConstants;
import javax.rad.server.ISession;
import javax.rad.server.SessionContext;
import javax.rad.util.TranslationMap;
import javax.sql.DataSource;

import com.sibvisions.rad.model.Filter;
import com.sibvisions.rad.persist.AbstractCachedStorage;
import com.sibvisions.rad.persist.jdbc.ServerMetaData.PrimaryKeyType;
import com.sibvisions.rad.persist.jdbc.param.AbstractParam;
import com.sibvisions.rad.persist.jdbc.param.AbstractParam.ParameterType;
import com.sibvisions.rad.server.protocol.ProtocolFactory;
import com.sibvisions.rad.server.protocol.Record;
import com.sibvisions.util.ArrayUtil;
import com.sibvisions.util.GroupHashtable;
import com.sibvisions.util.ICloseable;
import com.sibvisions.util.IValidatable;
import com.sibvisions.util.KeyValueList;
import com.sibvisions.util.ObjectCache;
import com.sibvisions.util.log.ILogger;
import com.sibvisions.util.log.ILogger.LogLevel;
import com.sibvisions.util.log.LoggerFactory;
import com.sibvisions.util.type.CommonUtil;
import com.sibvisions.util.type.DateUtil;
import com.sibvisions.util.type.StringUtil;
import com.sibvisions.util.type.StringUtil.CaseSensitiveType;

/**
 * The <code>DBAccess</code> is the implementation for most used SQL databases.<br>
 * Standard ANSI SQL Databases are anyways supported.<br>
 * Its used to read/write data between the storage and the <code>DataBook/DataPage</code>.
 * It has database type specific implementations.<br>
 * 
 * <br><br>Example:
 * <pre>
 * <code>
 * DBAccess dba = new DBAccess();
 * 
 * // set connect properties
 * dba.setDriver("org.hsqldb.jdbcDriver");
 * dba.setUrl("jdbc:hsqldb:file:testdbs/test/testdb");
 * dba.setUsername("sa");
 * dba.setPassword("");
 * 
 * Properties pDBProperties = new Properties();
 * pDBProperties.put("shutdown", true);
 * dba.setDBProperties(pDBProperties);
 * 
 * // open
 * dba.open();
 * 
 * To get Database independent DBAccess, it is better to use:
 * 
 * DBAccess dba = DBAccess.getDBAccess("jdbc:hsqldb:file:testdbs/test/testdb");
 * 
 * // insert data into test table
 * PreparedStatement psPreparedStatement = dba.getPreparedStatement(
 * 	             "insert into test (id, name) values(?,?)", false);
 * psPreparedStatement.setInt(1, 1);
 * psPreparedStatement.setString(2, "projectX");
 * dba.executeUpdate(psPreparedStatement);
 * 
 * // select data from test table
 * psPreparedStatement = dba.getPreparedStatement("select * from test", false);
 * ResultSet rs = dba.executeQuery(psPreparedStatement);
 * 
 * while (rs.next())
 * {
 *    System.out.println(rs.getInt("id") + "," + rs.getString("name"));
 * }
 * </code>
 * </pre>
 *  
 * @see com.sibvisions.rad.persist.jdbc.IDBAccess
 * @see com.sibvisions.rad.model.remote.RemoteDataBook
 * 
 * @author Roland H�rmann
 */
public class DBAccess implements IDBAccess,
                                 ICloseable
{
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Constants
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
	// jdk 1.6 jdbc types
    /** A jdbc VARCHAR DB column data type constant. */
    public static final int NCHAR 			= -15;
    
    /** A jdbc VARCHAR DB column data type constant. */
    public static final int NVARCHAR 		= -9;
        
    /** A jdbc VARCHAR DB column data type constant. */
    public static final int LONGNVARCHAR 	= -16;
    
    /** A jdbc XML DB column data type constant. */
    public static final int SQLXML 			= 2009;

    /** A jdbc BLOB DB column data type constant. */ 
    public static final int NCLOB 			= 2011;
    
	/** JVx generell DB quote character. will be translated in the DB specific. */
    public static final String QUOTE = "`";
    
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// static 
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /** The Default translation Map for the automatic link column name for the specified ForeignKey and FK Column in the master table.*/
    private static TranslationMap tmpAutoLinkColumnNames  = new TranslationMap(); 
    
	/** Stores suitable DBAccess classes for jdbc urls. */
    private static Hashtable<String, Class<? extends DBAccess>> dbAccessClasses = new Hashtable<String, Class<? extends DBAccess>>();
    
	/** the mapping between cache groups and the application. */ 
	private static KeyValueList<String, String> kvlApplicationGroups = new KeyValueList<String, String>(); 
	
	/** The default limit for what is considered a "large object". */
	private static long lDefaultLargeObjectLimit = 8192L;
	
	/** Cache of <code>ForeignKey</code>'s to improve performance. */
	private static GroupHashtable<String, String, List<ForeignKey>>	ghtFKsCache = new GroupHashtable<String, String, List<ForeignKey>>();
	/** Cache of <code>PrimaryKey</code>'s to improve performance. */
	private static GroupHashtable<String, String, Key>	ghtPKCache = new GroupHashtable<String, String, Key>();
	/** Cache of <code>UniqueKey</code>'s to improve performance. */
	private static GroupHashtable<String, String, List<Key>>	ghtUKsCache = new GroupHashtable<String, String, List<Key>>();
	/** Cache of <code>AllowedValues</code>'s to improve performance. */
	private static GroupHashtable<String, String, Map<String, Object[]>>	ghtAllowedValuesCache = new GroupHashtable<String, String, Map<String, Object[]>>();
	/** Cache of <code>DefaultValues</code>'s to improve performance. */
	private static GroupHashtable<String, String, Map<String, Object>>	ghtDefaultValuesCache = new GroupHashtable<String, String, Map<String, Object>>();
	/** Cache of <code>ColumnMetaData</code>'s to improve performance. */
	private static GroupHashtable<String, String, ServerColumnMetaData[]>	ghtColumnMetaDataCache = new GroupHashtable<String, String, ServerColumnMetaData[]>();
	/** Cache of <code>TableInfo</code>'s to improve performance. */
	private static GroupHashtable<String, String, TableInfo>	ghtTableInfoCache = new GroupHashtable<String, String, TableInfo>();
	/** Cache of <code>TableInfo</code>'s to improve performance. */
	private static GroupHashtable<String, String, String>	ghtTableNameCache = new GroupHashtable<String, String, String>();
	
	/** Constant for FKS are null. */
	private static final List<ForeignKey> FKS_NULL = new ArrayUtil<ForeignKey>(); 
	/** Constant for PKS are null. */
	private static final Key PKS_NULL = new Key(null, null); 
	/** Constant for UKS are null. */
	private static final List<Key> UKS_NULL = new ArrayUtil<Key>(); 
	/** Constant for Allowed Values are null. */
	private static final Map<String, Object[]> ALLOWED_VALUES_NULL = new Hashtable<String, Object[]>(); 
	/** Constant for Default Values are null. */
	private static final Map<String, Object> DEFAULT_VALUES_NULL = new Hashtable<String, Object>(); 
	/** Constant for column meta data are null. */
	private static final ServerColumnMetaData[] COLUMNMETADATA_NULL = new ServerColumnMetaData[0];
	/** Constant for column meta data are null. */
	private static final TableInfo TABLEINFO_NULL = new TableInfo(null, null, null);
	/** Constant for column meta data are null. */
	private static final String TABLENAME_NULL = new String("TABLENAME_NULL"); // new String for unique reference
	
	/** the metadata cache option for this instance (default: Default). */
	private MetaDataCacheOption mdcCacheOption = MetaDataCacheOption.Default;

	/** The logger for protocol the performance. */
	private static ILogger logger = null;

	/** Last queried state whether the metadata cache is global (not update everytime). */
	private static boolean lastGlobalMetaDataCache = false;
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Class members
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	/** The maximum time in milliseconds to use, to try to fetch all rows. reduce open cursors, and increase performance. */
	private int 							iMaxTime = 100;
	
	/** The jdbc connection to the database. */
	private Connection						cConnection;
	
	/** The jdbc connection string. */
	private String							sUrl;

	/** Name of the jdbc driver <code>Class</code>. */
	private String							sDriver;

	/** User name to connect to the database. */
	private String							sUsername;

	/** Password to connect to the database. */
	private String							sPassword;

    /** The open quote character for database operations. */
    private String 							sOpenQuote;

    /** The close quote character for database operations. */
    private String 							sCloseQuote;
    
    /** Sets the default schema for the case that schema is not automatically detected. */
    private String							sDefaultSchema;

    /** The current application name. */
    private String							sApplicationName = "";
    
    /** Database specific properties. */
	private Properties						properties = new Properties();

	/** Cache of <code>ResultSet</code>'s to reuse in the next fetch. */
	private Hashtable<Select, ResultSet>	htFetchResultSetCache = new Hashtable<Select, ResultSet>();
	
	/** the date util for string to date conversion. */
	private DateUtil 						dateUtil = new DateUtil(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
	
    /** stores the identifier for this DBAccess configuration. */
    private String                          sIdentifier = null;

    /** Query time out, which is used as limit for fetching data. */
    private int                             iQueryTimeOut = 0;

    /** stores the max. column length in this database. */
	private int 							iMaxColumnLength;

	/** The limit which is used to determine if something is a "large object". */
	private long							lLargeObjectLimit = lDefaultLargeObjectLimit;
	
    /** whether the connection should be automatically closed. */
    private boolean                         bAutoClose = true;
    
    /** whether the connection is an external connection. */
    private boolean                         bExternalConnection = false;

    /** whether the database access was modified. */
    private boolean                         bModified;
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Initialization
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	static
	{
		registerDBAccessClass("jdbc:oracle:", OracleDBAccess.class);
		registerDBAccessClass("jdbc:db2:", DB2DBAccess.class);
		registerDBAccessClass("jdbc:derby:", DerbyDBAccess.class);
		registerDBAccessClass("jdbc:jtds:sqlserver:", MSSQLDBAccess.class);
		registerDBAccessClass("jdbc:mysql:", MySQLDBAccess.class);
		registerDBAccessClass("jdbc:postgresql:", PostgreSQLDBAccess.class);
		registerDBAccessClass("jdbc:hsqldb:", HSQLDBAccess.class);
		registerDBAccessClass("jdbc:sap:", HanaDBAccess.class);
		
		tmpAutoLinkColumnNames.put("*_id*", "*0*1");
		tmpAutoLinkColumnNames.put("*_ID*", "*0*1");
	}
	
	/**
	 * Constructs a new DBAccess Object.
	 */
	public DBAccess()
	{
		super();
		
		setQuoteCharacters("\"", "\"");
	}
	
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Interface implementation
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**
     * Gets the suitable DBAcces for the given JdbcUrl.
     *  
     * @param pJdbcUrl the JdbcUrl.
     * @return the suitable DBAccess.
     * @throws DataSourceException if the instance name is unknown or the DBAccess object cannot be created.
     */
    public static DBAccess getDBAccess(String pJdbcUrl) throws DataSourceException
    {
        return getDBAccess(pJdbcUrl, null, null);
    }	
	
	/**
	 * Gets the suitable DBAcces for the given JdbcUrl.
	 *  
	 * @param pJdbcUrl the JdbcUrl.
	 * @param pOptionalUserName optional username for the connection
	 * @param pOptionalPassword optional password for the connection
	 * @return the suitable DBAccess.
	 * @throws DataSourceException if the instance name is unknown or the DBAccess object cannot be created.
	 */
	public static DBAccess getDBAccess(String pJdbcUrl, String pOptionalUserName, String pOptionalPassword) throws DataSourceException
	{
		if (pJdbcUrl == null)
		{
			return null;
		}
		
		//#589 check JNDI if the URL is not a jdbc url
		if (!isJdbc(pJdbcUrl))
		{
			try
			{
				InitialContext ctxt = new InitialContext();
				
			    try
			    {
					Object objInstance = ctxt.lookup(pJdbcUrl);
					
					if (objInstance instanceof DBAccess)
					{
						return (DBAccess)objInstance;
					}
					else if (objInstance instanceof Connection)
					{
					    DBAccess dba = DBAccess.getDBAccess((Connection)objInstance, true);
					    dba.setUrl(pJdbcUrl);
					    
					    return dba;
					}
					else if (objInstance instanceof DataSource)
					{
					    DBAccess dba;
					    
                        if (!StringUtil.isEmpty(pOptionalUserName) && !StringUtil.isEmpty(pOptionalPassword))
                        {
                            dba = DBAccess.getDBAccess(((DataSource)objInstance).getConnection(pOptionalUserName, pOptionalPassword), true);
                        }
                        else
                        {
                            dba = DBAccess.getDBAccess(((DataSource)objInstance).getConnection(), true);
                        }
                        
					    dba.setUrl(pJdbcUrl);
					    
					    return dba;
					}
			    }
			    finally
			    {
			        ctxt.close();
			    }
			}
			catch (Exception ex)
			{
				throw new DataSourceException("JNDI URL used, but resource was not found!", ex);
			}
		}
		
		Class<? extends DBAccess> clazz = getDBAccessClass(pJdbcUrl);
		
		try
		{
			DBAccess dbAccess = clazz.newInstance();
			dbAccess.setUrl(pJdbcUrl);
			dbAccess.setUsername(pOptionalUserName);
			dbAccess.setPassword(pOptionalPassword);
			
			return dbAccess;
		}
		catch (Exception e)
		{
			throw new DataSourceException("Instantion of '" + clazz + "' failed!", e);
		}
	}
	
	/**
	 * Gets the suitable DBAccess for the given {@link DBCredentials}.
	 * 
	 * @param pCredentials the database credentials.
	 * @return the suitable DBAccess.
	 * @throws DataSourceException if the instance name is unknown or the DBAccess object cannot be created.
	 */
	public static DBAccess getDBAccess(DBCredentials pCredentials) throws DataSourceException
	{
		if (pCredentials == null)
		{
			return null;
		}
		
		DBAccess dbAccess = getDBAccess(pCredentials.getUrl(), pCredentials.getUserName(), pCredentials.getPassword());

		if (dbAccess == null)
		{
		    return null;
		}
		
		String sCustomDriver = pCredentials.getDriver();
		
		//allow driver overriding
		if (!StringUtil.isEmpty(sCustomDriver))
        {
		    dbAccess.setDriver(sCustomDriver);
        }
		
		return dbAccess;
	}
	
	/**
	 * Gets the default value for the limit for what is considered a "large object".
	 * <p/>
	 * This limit is used for columns which have the {@code fetchLargObjectsLazy}
	 * option set to determine if the current object should be lazily fetched or not.
	 * <p/>
	 * "Lazy" means that the object is only send to the client if the value
	 * is actually requested. It is still fetched from the datasource and
	 * cached on the server side.
	 * <p/>
	 * Note that the default limit is only applied to new instances of {@link DBAccess}.
	 * 
	 * @return the default limit for what is considered a "large object".
	 */
	public static long getDefaultLargeObjectLimit()
	{
		return lDefaultLargeObjectLimit;
	}
	
	/**
     * Gets the suitable DBAccess for the given external connection. The external won't be closed automatically. 
     * 
     * @param pConnection the database connection.
     * @return the suitable DBAccess.
     * @throws DataSourceException if the instance name is unknown or the DBAccess object cannot be created.
     */
    public static DBAccess getDBAccess(Connection pConnection) throws DataSourceException
    {
        return getDBAccess(pConnection, false);
    }	
	
	/**
	 * Gets the suitable DBAccess for the given connection.
	 * 
	 * @param pConnection the database connection.
     * @param pAutoCloseConnection <code>true</code> whether the connection should be colsed via {@link #close()}
	 * @return the suitable DBAccess.
	 * @throws DataSourceException if the instance name is unknown or the DBAccess object cannot be created.
	 */
	private static DBAccess getDBAccess(Connection pConnection, boolean pAutoCloseConnection) throws DataSourceException
	{
		if (pConnection == null)
		{
			throw new DataSourceException("Connection is null");
		}
		
		try
		{
			DatabaseMetaData dbmd = pConnection.getMetaData();
			
			String sConURL = dbmd.getURL();
			
			Class<? extends DBAccess> clazz = getDBAccessClass(sConURL);
			
			DBAccess dbAccess = clazz.newInstance();
			dbAccess.setUrl(sConURL);
			dbAccess.setUsername(dbmd.getUserName());
			dbAccess.setConnection(pConnection);
			dbAccess.bAutoClose = pAutoCloseConnection;
			dbAccess.bExternalConnection = true;
			
			return dbAccess;
		}
		catch (Exception e)
		{
			throw new DataSourceException("Database detection for '" + pConnection.getClass().getName() + "' failed!", e);
		}
	}
	
	/**
	 * Gets the suitable DBAccess class for the jdbc url.
	 * 
	 * @param pJdbcUrl the jdbc url.
	 * @return the suitable DBAccess class.
	 */
	private static Class<? extends DBAccess> getDBAccessClass(String pJdbcUrl)
	{
		for (String key : dbAccessClasses.keySet())
		{
			if (pJdbcUrl.startsWith(key))
			{
				return dbAccessClasses.get(key);
			}
		}
		return DBAccess.class;
	}
	
	/**
	 * Registers the Class for the jdbc url prefix.
	 * 
	 * @param pJdbcUrlPrefix the jdbc url prefix.
	 * @param pClass the Class.
	 */
	public static void registerDBAccessClass(String pJdbcUrlPrefix, Class<? extends DBAccess> pClass)
	{
		dbAccessClasses.put(pJdbcUrlPrefix, pClass);
	}
	
	/**
	 * Sets the TranslationMap for the automatic link column name custom Translation. its used in the 
	 * getAutomaticLinkColName(ForeignKey pForeignKey) to change the column, thats determined. Default is *_ID to *, and *_id to *.
	 * 
	 * @param pTranslationMap	the TranslationMap to use.
	 */
	public static void setAutomaticLinkColumnNameTranslation(TranslationMap pTranslationMap)
	{
		tmpAutoLinkColumnNames = pTranslationMap;
	}

	/**
	 * Returns the TranslationMap for the automatic link column name custom Translation. its used in the 
	 * getAutomaticLinkColName(ForeignKey pForeignKey) to change the column, thats determined. Default is *_ID to *, and *_id to *.
	 * 
	 * @return the TranslationMap for the automatic link column name custom Translation.
	 */
	public static TranslationMap getAutomaticLinkColumnNameTranslation()
	{
		return tmpAutoLinkColumnNames;
	}
	
	/**
	 * Sets the default value for the limit for what is considered a "large object".
	 * <p/>
	 * This limit is used for columns which have the {@code fetchLargObjectsLazy}
	 * option set to determine if the current object should be lazily fetched or not.
	 * <p/>
	 * "Lazy" means that the object is only send to the client if the value
	 * is actually requested. It is still fetched from the datasource and
	 * cached on the server side.
	 * <p/>
	 * Note that the default limit is only applied to new instances of {@link DBAccess}.
	 * 
	 * @param pDefaultLargeObjectLimit the new default limit.
	 */
	public static void setDefaultLargeObjectLimit(long pDefaultLargeObjectLimit)
	{
		lDefaultLargeObjectLimit = pDefaultLargeObjectLimit;
	}
	
	/**
	 * It gets all columns for each Unique Key and return it.
	 * 
	 * @param pCatalog				the catalog to use
	 * @param pSchema				the schema to use
	 * @param pTable				the table to use
	 * @return all columns for each Unique Key. 
	 * @throws DataSourceException	if an error occur during UK search process.
	 */
	protected List<Key> getUniqueKeysIntern(String pCatalog, String pSchema, String pTable) throws DataSourceException
	{
		ResultSet rsResultSet = null;
		try
		{
			ArrayUtil<Key>  auResult           = new ArrayUtil<Key>();
			ArrayUtil<Name> auUniqueKeyColumns = new ArrayUtil<Name>();
			
			long lMillis = System.currentTimeMillis();
			DatabaseMetaData dbMetaData = cConnection.getMetaData();
			
			rsResultSet = dbMetaData.getIndexInfo(removeQuotes(pCatalog), removeQuotes(pSchema), removeQuotes(pTable), true, false);
			
			if (!rsResultSet.next())
			{
				CommonUtil.close(rsResultSet);
				
				return auResult;
			}
			
			String sUKName = null;
			do
			{
				if (rsResultSet.getString("COLUMN_NAME") != null)
				{
					if (sUKName != null && !rsResultSet.getString("INDEX_NAME").equals(sUKName))
					{
						Key uk = new Key(sUKName, auUniqueKeyColumns.toArray(new Name[auUniqueKeyColumns.size()]));
						auResult.add(uk);
						auUniqueKeyColumns.clear();
					}
					sUKName = rsResultSet.getString("INDEX_NAME");
					
					// Bug in Postgres, Unique Keys are delivered with quotes.
					String ukColumn = removeDBSpecificQuotes(rsResultSet.getString("COLUMN_NAME")); 
					
					auUniqueKeyColumns.add(new Name(ukColumn, quote(ukColumn)));
				}
			}
			while (rsResultSet.next());
			
			//[JR] #188
			if (auUniqueKeyColumns.size() > 0)
			{
				Key uk = new Key(sUKName, auUniqueKeyColumns.toArray(new Name[auUniqueKeyColumns.size()]));
				
				auResult.add(uk);
			}
			
			if (auResult.size() > 0)
			{
				// remove PKs, because a PK is also a index, but we don't wanna return them too.
				Key pk = getPrimaryKey(pCatalog, pSchema, pTable);
				if (pk != null)
				{
					for (int i = auResult.size() - 1; i >= 0; i--)
					{
						Name[] ukCols = auResult.get(i).getColumns();
						if (ArrayUtil.containsAll(ukCols, pk.getColumns()) && ukCols.length == pk.getColumns().length)
						{
							auResult.remove(i);
						}
					}
				}
			}
			
            if (isLogEnabled(LogLevel.DEBUG))
            {
                debug("getUKs(", pTable, ") in ", Long.valueOf(System.currentTimeMillis() - lMillis), "ms");
            }

			return auResult;
		}
		catch (SQLException sqlException)
		{
  			error("Unique Keys couldn't determined from database! - ", pTable, sqlException);
  			
  			return null;
		}
		finally
		{
		    CommonUtil.close(rsResultSet);
		}
	}
	
	/**
	 * Gets the value for the limit for what is considered a "large object".
	 * <p/>
	 * This limit is used for columns which have the
	 * {@code fetchLargObjectsLazy} option set to determine
	 * if the current object should be lazily fetched or not.
	 * <p/>
	 * "Lazy" means that the object is only send to the client if the value is
	 * actually requested. It is still fetched from the datasource and cached on
	 * the server side.
	 * 
	 * @return the current limit.
	 */
	public long getLargeObjectLimit()
	{
		return lLargeObjectLimit;
	}

	/**
	 * It's gets all Primary Key columns and return it as String[].
	 * Gets all Primary Key columns and return it as list of Strings.
	 * 
	 * @param pCatalog				the catalog to use
	 * @param pSchema				the schema to use
	 * @param pTable				the table to use
	 * @return all Primary Key columns and return it as String[].
	 * @throws DataSourceException	if an error occur during PK search process.
	 */
	protected Key getPrimaryKeyIntern(String pCatalog, String pSchema, String pTable) throws DataSourceException
	{
		ResultSet rsResultSet = null;
		try
		{
			long lMillis = System.currentTimeMillis();

			ArrayUtil<Name> auPrimaryKeyColumns = new ArrayUtil<Name>();
			String          sPKName             = null;
			
	        DatabaseMetaData dbMetaData = cConnection.getMetaData();
			rsResultSet = dbMetaData.getPrimaryKeys(removeQuotes(pCatalog), removeQuotes(pSchema), removeQuotes(pTable));
			
			if (!rsResultSet.next())
			{
				return null;
			}
		
			do
			{
				if (sPKName == null)
				{
					sPKName = rsResultSet.getString("PK_NAME");
				}
				
				auPrimaryKeyColumns.add(new Name(rsResultSet.getString("COLUMN_NAME"), quote(rsResultSet.getString("COLUMN_NAME"))));
			}
			while (rsResultSet.next());
			
            if (isLogEnabled(LogLevel.DEBUG))
            {
                debug("getPK(", pTable, ") in ", Long.valueOf(System.currentTimeMillis() - lMillis), "ms");
            }

			Key pk = new Key(sPKName, auPrimaryKeyColumns.toArray(new Name[auPrimaryKeyColumns.size()]));

			return pk;
		}
  		catch (SQLException sqlException)
  		{
  			error("PrimaryKey couldn't determined from database! - ", pTable, sqlException);	
  			
  			return null;
  		}
  		finally
  		{
  		    CommonUtil.close(rsResultSet);
  		}
	}
		
	/**
	 * Returns all Foreign Keys for the specified table.
	 *  
	 * @param pCatalog				the catalog to use
	 * @param pSchema				the schema to use
	 * @param pTable the table to use as base table.
	 * @return all Foreign Keys for the specified table.
	 * @throws DataSourceException	if an error occur in determining the ForeignKeys.
	 */
	protected List<ForeignKey> getForeignKeysIntern(String pCatalog, String pSchema, String pTable) throws DataSourceException
	{
		ResultSet rsResultSetMetaData = null;

		try
		{
			ArrayUtil<ForeignKey> auForeignKeys = new ArrayUtil<ForeignKey>();

			long lMillis = System.currentTimeMillis();
	        DatabaseMetaData dbMetaData = cConnection.getMetaData();
			
			rsResultSetMetaData = dbMetaData.getImportedKeys(removeQuotes(pCatalog), removeQuotes(pSchema), removeQuotes(pTable));
			if (!rsResultSetMetaData.next())
			{
				// find no FKs -> From Clause can't determined
				return auForeignKeys;
			}
									
			String sTempKeyName = null;
			String sKeyName = null;
			ArrayUtil<Name> auPKColumns = new ArrayUtil<Name>();
			ArrayUtil<Name> auFKColumns = new ArrayUtil<Name>();

			ForeignKey fkForeignKey = new ForeignKey(
					new Name(rsResultSetMetaData.getString("PKTABLE_NAME"), quote(rsResultSetMetaData.getString("PKTABLE_NAME"))), 
					new Name(rsResultSetMetaData.getString("PKTABLE_CAT"), quote(rsResultSetMetaData.getString("PKTABLE_CAT"))), 
					new Name(rsResultSetMetaData.getString("PKTABLE_SCHEM"), quote(rsResultSetMetaData.getString("PKTABLE_SCHEM"))));
			
			do
			{
				sTempKeyName = rsResultSetMetaData.getString("FK_NAME");
				if (sTempKeyName == null || sTempKeyName.length() == 0)
				{
					sTempKeyName = rsResultSetMetaData.getString("PK_NAME");
					if (sTempKeyName == null || sTempKeyName.length() == 0)
					{
						throw new DataSourceException("Database/jdbc driver didn't support FK, PK names!");
					}
				}
				if (sKeyName != null && !sKeyName.equals(sTempKeyName))
				{
					fkForeignKey.setFKColumns(auFKColumns.toArray(new Name[auFKColumns.size()]));
					fkForeignKey.setPKColumns(auPKColumns.toArray(new Name[auPKColumns.size()]));
					auForeignKeys.add(fkForeignKey);
					
					auPKColumns.clear();			
					auFKColumns.clear();	
					
					fkForeignKey = new ForeignKey(
							new Name(rsResultSetMetaData.getString("PKTABLE_NAME"), quote(rsResultSetMetaData.getString("PKTABLE_NAME"))), 
							new Name(rsResultSetMetaData.getString("PKTABLE_CAT"), quote(rsResultSetMetaData.getString("PKTABLE_CAT"))), 
							new Name(rsResultSetMetaData.getString("PKTABLE_SCHEM"), quote(rsResultSetMetaData.getString("PKTABLE_SCHEM"))));
				}
				sKeyName = sTempKeyName;
				
				auPKColumns.add(new Name(rsResultSetMetaData.getString("PKCOLUMN_NAME"), quote(rsResultSetMetaData.getString("PKCOLUMN_NAME"))));
				auFKColumns.add(new Name(rsResultSetMetaData.getString("FKCOLUMN_NAME"), quote(rsResultSetMetaData.getString("FKCOLUMN_NAME"))));
				
				fkForeignKey.setFKName(rsResultSetMetaData.getString("FK_NAME"));
			}
			while (rsResultSetMetaData.next());

			fkForeignKey.setFKColumns(auFKColumns.toArray(new Name[auFKColumns.size()]));
			fkForeignKey.setPKColumns(auPKColumns.toArray(new Name[auPKColumns.size()]));
			auForeignKeys.add(fkForeignKey);
			
            if (isLogEnabled(LogLevel.DEBUG))
            {
                debug("getFKs(", pTable, ") in ", Long.valueOf(System.currentTimeMillis() - lMillis), "ms");
            }
			
			return auForeignKeys;
		}
		catch (SQLException sqlException)
		{
			throw new DataSourceException("Foreign Keys couldn't determined from database! - " + pTable, formatSQLException(sqlException));
		}
		finally
		{
		    CommonUtil.close(rsResultSetMetaData);
		}
	}
	
	/**
	 * It gets all columns for each Unique Key and return it.
	 * 
	 * @param pCatalog				the catalog to use
	 * @param pSchema				the schema to use
	 * @param pTable				the table to use
	 * @return all columns for each Unique Key. 
	 * @throws DataSourceException	if an error occur during UK search process.
	 */
	public final List<Key> getUniqueKeys(String pCatalog, String pSchema, String pTable) throws DataSourceException
	{
		if (isMetaDataCacheEnabled())
		{
			String dbAccessIdentifier = getIdentifier();
			String tableIdentifier = createIdentifier(pCatalog, pSchema, pTable);
			
			List<Key> uks = ghtUKsCache.get(dbAccessIdentifier, tableIdentifier);
			if (uks == null)
			{
				uks = getUniqueKeysIntern(pCatalog, pSchema, pTable);
				
				if (uks == null)
				{
					uks = UKS_NULL;
				}
				
				ghtUKsCache.put(dbAccessIdentifier, tableIdentifier, uks);
			}
			
			if (uks == UKS_NULL)
			{
				return null;
			}
			else
			{
				return uks;
			}
		}
		else
		{
			return getUniqueKeysIntern(pCatalog, pSchema, pTable);
		}
	}
	
	/**
	 * It's gets all Primary Key columns and return it as String[].
	 * 
	 * @param pCatalog				the catalog to use
	 * @param pSchema				the schema to use
	 * @param pTable				the table to use
	 * @return all Primary Key columns and return it as String[].
	 * @throws DataSourceException	if an error occur during PK search process.
	 */
	public final Key getPrimaryKey(String pCatalog, String pSchema, String pTable) throws DataSourceException
	{
		if (isMetaDataCacheEnabled())
		{
			String dbAccessIdentifier = getIdentifier();
			String tableIdentifier = createIdentifier(pCatalog, pSchema, pTable);
			
			Key pk = ghtPKCache.get(dbAccessIdentifier, tableIdentifier);
			if (pk == null)
			{
				pk = getPrimaryKeyIntern(pCatalog, pSchema, pTable);
	
				if (pk == null)
				{
					pk = PKS_NULL;
				}
				
				ghtPKCache.put(dbAccessIdentifier, tableIdentifier, pk);
			}

			if (pk == PKS_NULL)
			{
				return null;
			}
			else
			{
				return pk;
			}
		}
		else
		{
			return getPrimaryKeyIntern(pCatalog, pSchema, pTable);
		}
	}

	/**
	 * Returns all Foreign Keys for the specified table.
	 *  
	 * @param pCatalog				the catalog to use
	 * @param pSchema				the schema to use
	 * @param pTable the table to use as base table.
	 * @return all Foreign Keys for the specified table.
	 * @throws DataSourceException	if an error occur in determining the ForeignKeys.
	 */
	public final List<ForeignKey> getForeignKeys(String pCatalog, String pSchema, String pTable) throws DataSourceException
	{
		if (isMetaDataCacheEnabled())
		{
			String dbAccessIdentifier = getIdentifier();
			String tableIdentifier = createIdentifier(pCatalog, pSchema, pTable);
			
			List<ForeignKey> fks = ghtFKsCache.get(dbAccessIdentifier, tableIdentifier);
			if (fks == null)
			{
				fks = getForeignKeysIntern(pCatalog, pSchema, pTable);
				
				if (fks == null)
				{
					fks = FKS_NULL;
				}
				
				ghtFKsCache.put(dbAccessIdentifier, tableIdentifier, fks);
			}
			
			if (fks == FKS_NULL)
			{
				return null;
			}
			else
			{
				return fks;
			}
		}
		else
		{
			return getForeignKeysIntern(pCatalog, pSchema, pTable);
		}
	}
	
	/**
	 * Returns the full qualified table name incl. schema/catalog/db link for the given synonym.
	 * If pSynomyn is no synonym, then the pSynomyn string is returned.
	 *   
	 * @param pSynomyn	the synonym to use.
	 * @return the full qualified table name incl. schema/catalog/db link for the given synonym.
	 * @throws DataSourceException	if an error occur in determining the synonyms.
	 */
	public final String getTableForSynonym(String pSynomyn) throws DataSourceException
	{
		if (isMetaDataCacheEnabled())
		{
			String dbAccessIdentifier = getIdentifier();
			String tableIdentifier = createIdentifier(pSynomyn);
			
			String tableName = ghtTableNameCache.get(dbAccessIdentifier, tableIdentifier);
			if (tableName == null)
			{
				tableName = getTableForSynonymIntern(pSynomyn);
				
				if (tableName == null)
				{
					tableName = TABLENAME_NULL;
				}
				
				ghtTableNameCache.put(dbAccessIdentifier, tableIdentifier, tableName);
			}
			
			if (tableName == TABLENAME_NULL)
			{
				return null;
			}
			else
			{
				return tableName;
			}
		}
		else
		{
			return getTableForSynonymIntern(pSynomyn);
		}
	}

	/**
	 * Returns the full qualified table name incl. schema/catalog/db link for the given synonym.
	 * If pSynomyn is no synonym, then the pSynomyn string is returned.
	 *   
	 * @param pSynomyn	the synonym to use.
	 * @return the full qualified table name incl. schema/catalog/db link for the given synonym.
	 * @throws DataSourceException	if an error occur in determining the synonyms.
	 */
	protected String getTableForSynonymIntern(String pSynomyn) throws DataSourceException
	{
		// String pCatalog, String pSchema, String pTable
		
		return pSynomyn;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<Object[]> fetch(ServerMetaData pServerMetaData, String pBeforeQueryColumns, String[] pQueryColumns, String pFromClause,
								ICondition pFilter, String pWhereCondition, String pAfterWhereClause, 
								SortDefinition pSort, int pFromRow, int pMinimumRowCount,
								boolean pAllowLazyFetch) throws DataSourceException
	{
		return fetch(pServerMetaData, pBeforeQueryColumns, pQueryColumns, pFromClause,
				pFilter, pWhereCondition, pAfterWhereClause,
				pSort, null, pFromRow, pMinimumRowCount,
				pAllowLazyFetch);
	}

	/**
	 * Returns the List of fetched rows (as List of Object[]) for the specified query tables and 
	 * parameters. It fetch's the the rows from pFromRow row index a minimum amount of 
	 * pMinimumRowCount rows.  Implementations should fetch as much rows as possible in a 
	 * proper amount of time, to get less requests from the client model to the server 
	 * IDBAccess. Implementation can cache the select cursor and reuse it for the next fetch
	 * operation, but they should take care, that's a state less call and in a fall over case
	 * it maybe loose on the fail over system the cursor. 
	 * 
	 * @param pBeforeQueryColumns	the before query columns
	 * @param pQueryColumns			the query columns	
	 * @param pFromClause			the from clause with query tables and join definitions
	 * @param pFilter	            the filter to use
	 * @param pWhereCondition		the last where condition in query
	 * @param pAfterWhereClause		the after where clause in query
	 * @param pSort		            the sort order to use
	 * @param pFromRow				the row index from to fetch
	 * @param pMinimumRowCount		the minimum count row to fetch
	 * @param pServerMetaData		the MetaDataColumn array to use.
	 * @return the List of fetched rows (as List of Object[]) for the specified query tables and 
	 * 		   parameters.
	 * @throws DataSourceException	if the fetch fails.
	 */
	public List<Object[]> fetch(ServerMetaData pServerMetaData, String pBeforeQueryColumns, String[] pQueryColumns, String pFromClause,
								ICondition pFilter, String pWhereCondition, String pAfterWhereClause, 
								SortDefinition pSort, int pFromRow, int pMinimumRowCount) throws DataSourceException
	{
		return fetch(pServerMetaData, pBeforeQueryColumns, pQueryColumns, pFromClause,
				pFilter, pWhereCondition, pAfterWhereClause,
				pSort, null, pFromRow, pMinimumRowCount,
				false);
	}
	
	/**
	 * Mostly same as {@link DBAccess#fetch(ServerMetaData, String, String[], String, ICondition, String, String, SortDefinition, int, int)}.
	 * 
	 * This fetch does accept an additional order by clause which will be used
	 * if the given default sort is null.
	 * 
	 * @param pBeforeQueryColumns	the before query columns
	 * @param pQueryColumns			the query columns	
	 * @param pFromClause			the from clause with query tables and join definitions
	 * @param pFilter	            the filter to use
	 * @param pWhereCondition	the last where condition in query
	 * @param pAfterWhereClause		the after where clause in query
	 * @param pOrderByClause		the order by clause
	 * @param pSort		            the sort order to use
	 * @param pFromRow				the row index from to fetch
	 * @param pMinimumRowCount		the minimum count row to fetch
	 * @param pServerMetaData		the MetaDataColumn array to use.
	 * @return the List of fetched rows (as List of Object[]) for the specified query tables and 
	 * 		   parameters.
	 * @throws DataSourceException	if the fetch fails.
	 */
	public List<Object[]> fetch(ServerMetaData pServerMetaData, String pBeforeQueryColumns, String[] pQueryColumns, String pFromClause,
								ICondition pFilter, String pWhereCondition, String pAfterWhereClause,
								SortDefinition pSort, String pOrderByClause, int pFromRow, int pMinimumRowCount) throws DataSourceException
	{
		return fetch(pServerMetaData, pBeforeQueryColumns, pQueryColumns, pFromClause,
				pFilter, pWhereCondition, pAfterWhereClause,
				pSort, pOrderByClause, pFromRow, pMinimumRowCount,
				false);
	}
	
	/**
	 * Mostly same as {@link DBAccess#fetch(ServerMetaData, String, String[], String, ICondition, String, String, SortDefinition, int, int)}.
	 * 
	 * This fetch does accept an additional order by clause which will be used
	 * if the given default sort is null.
	 * 
	 * @param pBeforeQueryColumns	the before query columns
	 * @param pQueryColumns			the query columns	
	 * @param pFromClause			the from clause with query tables and join definitions
	 * @param pFilter	            the filter to use
	 * @param pWhereCondition	the last where condition in query
	 * @param pAfterWhereClause		the after where clause in query
	 * @param pOrderByClause		the order by clause
	 * @param pSort		            the sort order to use
	 * @param pFromRow				the row index from to fetch
	 * @param pMinimumRowCount		the minimum count row to fetch
	 * @param pServerMetaData		the MetaDataColumn array to use.
	 * @param pAllowLazyFetch		if lazy fetch should be allowed.
	 * @return the List of fetched rows (as List of Object[]) for the specified query tables and 
	 * 		   parameters.
	 * @throws DataSourceException	if the fetch fails.
	 */
	public List<Object[]> fetch(ServerMetaData pServerMetaData, String pBeforeQueryColumns, String[] pQueryColumns, String pFromClause,
								ICondition pFilter, String pWhereCondition, String pAfterWhereClause,
								SortDefinition pSort, String pOrderByClause, int pFromRow, int pMinimumRowCount,
								boolean pAllowLazyFetch) throws DataSourceException
	{
        Record record = ProtocolFactory.openRecord("FETCH");
        
        try
        {
    		if (!isOpen())
    		{
    			throw new DataSourceException("DBAccess is not open!");
    		}

    		long lMillis = System.currentTimeMillis();
    		
    		String sSelectStatement = getSelectStatement(pServerMetaData, 
    						pBeforeQueryColumns, pQueryColumns, pFromClause, pFilter, pWhereCondition, pAfterWhereClause, pSort, pOrderByClause);
    								
    		Object[] oaParameter = getParameter(pFilter);
    		
    		if (record != null)
    		{
    		    if (oaParameter != null && oaParameter.length > 0)
    		    {
        		    record.setParameter(sSelectStatement, oaParameter);
    		    }
    		    else
    		    {
    		        record.setParameter(sSelectStatement);
    		    }
    		}
    		
    		ServerColumnMetaData[] scmd = pServerMetaData.getServerColumnMetaData();
    
    		PreparedStatement psSelect = null;
    		ResultSet rsResultSet = null;
    		try 
    		{
    			Select currentSelect = new Select(sSelectStatement, oaParameter, pFromRow);
    			rsResultSet = htFetchResultSetCache.remove(currentSelect);
    			
    			List<Object[]> auResult = new ArrayUtil<Object[]>();
    
    			if (rsResultSet == null)
    			{
    				psSelect = getPreparedStatement(sSelectStatement, false);
    
    				if (iQueryTimeOut > 0)
    				{
    					psSelect.setQueryTimeout(iQueryTimeOut);
    				}
    	
    				// set Filter Parameter Values
    				if (pFilter != null)
    				{
    					setFilterParameter(1, psSelect, oaParameter);
    				}		
                    rsResultSet = psSelect.executeQuery();
    
    				for (int j = 0; j < pFromRow; j++)
    				{
    					if (!rsResultSet.next())
    					{
    						auResult.add(null);	
    						
    						CommonUtil.close(rsResultSet, psSelect);
    
    		                if (record != null)
    		                {
    		                    record.setCount(auResult.size());
    		                }
    						
    						return auResult;
    					}
    				}
    				
    				if (isLogEnabled(LogLevel.DEBUG))
    				{
    					debug("select(", sSelectStatement, ", ", getParameter(pFilter), 
    						  ", from Row ", Integer.valueOf(pFromRow), ", MinimumCount ", Integer.valueOf(pMinimumRowCount), ") in ",
    						  Long.valueOf(System.currentTimeMillis() - lMillis), "ms");
    				}
    			}
    			else
    			{
    				psSelect = (PreparedStatement)rsResultSet.getStatement();
    			}
    			ResultSetMetaData rmSelectMetaData = rsResultSet.getMetaData();
    
    			// try to fetch all rows in iMaxTime millis
    			lMillis = System.currentTimeMillis();
    			int  iTimeLeft = iMaxTime;
    
    			int columnCount = pServerMetaData.getMetaData().getColumnMetaDataCount();
    			int resultSetColumnCount = rmSelectMetaData.getColumnCount();
    			int[] columnIndexes = null;
    			boolean[] lazyIndexes = null;
    			
    			String cacheKeyStart = null;
    			
    			int i = 0;
    			for (; pMinimumRowCount < 0 || i < pMinimumRowCount || iTimeLeft >= 0; i++)				
    			{
    				Object[] oRow = null;
    				
    				if (rsResultSet.next())
    				{
    					oRow = new Object[columnCount];
    					
    					if (columnIndexes == null)
    					{
    						columnIndexes = new int[resultSetColumnCount];
    						lazyIndexes = new boolean[resultSetColumnCount];
    						for (int j = 0; j < resultSetColumnCount; j++)
    						{
    							int columnIndex = pServerMetaData.getServerColumnMetaDataIndex(getColumnName(rmSelectMetaData, j + 1).toUpperCase());
    							
    							if (columnIndex >= 0)
    							{
    								columnIndexes[j] = columnIndex;
    								lazyIndexes[j] = pServerMetaData.getServerColumnMetaData(columnIndex).getColumnMetaData().isFetchLargeObjectsLazy();
    							}
    							else
    							{
    								// Could happen for columns which are not in the metadata, like COUNT(*).
    								columnIndexes[j] = j;
    							}
    						}
    					}
    					
    					String cacheKeyWithPrimaryKeys = null;
    					
    					for (int j = 0; j < resultSetColumnCount; j++)
    					{
    						Object oValue = rsResultSet.getObject(j + 1);
    						int columnIndex = columnIndexes[j];
    						
    						// convert to Java types
    						if (oValue instanceof Number
    								 && !(oValue instanceof BigDecimal))
    						{
    							oValue = rsResultSet.getBigDecimal(j + 1);
    						}
    						else if (oValue instanceof java.util.Date 
    							&& !(oValue instanceof Timestamp))
    						{
    							oValue = rsResultSet.getTimestamp(j + 1);
    						} 
    						else if (oValue instanceof java.sql.Clob)
    						{
    							Clob cValue = (Clob)oValue;
    							oValue = cValue.getSubString(1, (int)cValue.length());
    						}  
    						else if (oValue instanceof java.sql.Blob)
    						{
    							Blob bValue = (Blob)oValue;
        						
        						if (pAllowLazyFetch && lazyIndexes[columnIndex]
        								&& bValue != null && bValue.length() >= lLargeObjectLimit)
        						{
        							// Build the start of the cache key for this query.
        							if (cacheKeyStart == null)
        							{
        								cacheKeyStart = createIdentifier(getConnection(), pFromClause);
        							}
        							
        							// Append the PK columns to the cache key start.
        							if (cacheKeyWithPrimaryKeys == null)
        							{
        								int[] primaryKeyIndices = pServerMetaData.getPrimaryKeyColumnIndices();
        								List<Object> primaryKeys = new ArrayList<Object>();
        								
        								for (int idx = 0; idx < columnIndexes.length; idx++)
        								{
        									if (ArrayUtil.contains(primaryKeyIndices, columnIndexes[idx]))
        									{
        										primaryKeys.add(rsResultSet.getObject(idx + 1));
        									}
        								}
        								
        								cacheKeyWithPrimaryKeys = cacheKeyStart + createIdentifier(primaryKeys.toArray(new Object[primaryKeys.size()]));
        							}
        							
        							String columnName = scmd[columnIndex].getName();
        							
        							// Finally add the current column name to the cache key.
        							String cacheKey = cacheKeyWithPrimaryKeys + "/" + columnName;
        							
        							BlobFileHandle handle = new BlobFileHandle(columnName, bValue);
        							
        							ObjectCache.put(cacheKey, handle);
        							
        							oValue = new RemoteFileHandle(columnName, cacheKey);
        						}
        						else
        						{
        							oValue = bValue.getBytes(1, (int)bValue.length());
        						}
    						}
    						
    						oRow[columnIndex] = convertDatabaseSpecificObjectToValue(scmd[columnIndex], oValue);
    					}
    					auResult.add(oRow);
    					iTimeLeft = iMaxTime - (int)(System.currentTimeMillis() - lMillis);
    				}
    				else
    				{
    					auResult.add(null);	
    					
    					CommonUtil.close(rsResultSet, psSelect);

    	                if (record != null)
    	                {
    	                    record.setCount(auResult.size());
    	                }
    					
    					return auResult;
    				}				
    			}
    			
    			if (auResult.size() == 0)
    			{
    				auResult.add(null);
    				
                    CommonUtil.close(rsResultSet, psSelect);
    			}
    			else
    			{
    				// save current ResultSetCursor and use the next time!!!
    				htFetchResultSetCache.put(new Select(sSelectStatement, oaParameter, pFromRow + i), rsResultSet);
    			}
    			
    			if (record != null)
    			{
    			    record.setCount(auResult.size());
    			}
    			
    			return auResult;
    		}
    		catch (Exception ex)
    		{
    		    CommonUtil.close(rsResultSet, psSelect);
    			
    			throw new DataSourceException("fetch statement failed! - " + sSelectStatement, (ex instanceof SQLException ? formatSQLException((SQLException)ex) : ex));
    		}
		}
		finally
		{
		    CommonUtil.close(record);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void lockRow(String pWriteBackTable, ServerMetaData pServerMetaData, ICondition pPKFilter) throws DataSourceException
	{	
		if (!isOpen())
		{
			throw new DataSourceException("DBAccess is not open!");
		}
		
		if (pWriteBackTable == null)
		{
			throw new DataSourceException("Missing WriteBackTable!");
		}

		try
		{
			if (!cConnection.getAutoCommit() && cConnection.getMetaData().supportsSelectForUpdate())
			{
				lockRowInternal(pWriteBackTable, pServerMetaData, pPKFilter);
			}
		}
		catch (SQLException se)
		{
			throw new DataSourceException("Execute locking failed!", formatSQLException(se));
		}
	}
	
	/**
	 * It locks the current row and return how many rows are affected.
	 * 
	 * @param pWriteBackTable the storage unit to use
	 * @param pPKFilter 	  the PrimaryKey in as an <code>ICondition</code> to identify the row to lock   
	 * @param pServerMetaData the MetaDataColumn array to use.
	 * @return the counts of affected rows
	 * @throws DataSourceException if an <code>Exception</code> occur during interacting with the storage 
	 */
	protected int lockRowInternal(String pWriteBackTable, ServerMetaData pServerMetaData, ICondition pPKFilter) throws DataSourceException
	{
		return getRowCount(getDatabaseSpecificLockStatement(pWriteBackTable, pServerMetaData, pPKFilter), pPKFilter, 1);
	}
	
    /**
	 * {@inheritDoc}
	 */
	public Object[] insert(String pWriteBackTable, ServerMetaData pServerMetaData, Object[] pNewDataRow) throws DataSourceException
	{
	    Record record = ProtocolFactory.openRecord("INSERT", pWriteBackTable);
	    
	    try
	    {
    		if (!isOpen())
    		{
    			throw new DataSourceException("DBAccess is not open!");
    		}
    
    		if (pWriteBackTable == null)
    		{
    			throw new DataSourceException("Missing WriteBackTable!");
    		}
    		
    		StringBuilder sInsertStatement = new StringBuilder("INSERT INTO ");
    		sInsertStatement.append(pWriteBackTable);
    		sInsertStatement.append(" (");
    
    		// add column names to insert
    		int iColumnCount = 0;
    		String sDummyColumn = null;
    		
    		ServerColumnMetaData[] cmdServerColumnMetaData = pServerMetaData.getServerColumnMetaData();
    		int[] iaWriteables = pServerMetaData.getWritableColumnIndices();
    		
    		for (int i = 0; i < iaWriteables.length; i++)
    		{
    			if (pNewDataRow[iaWriteables[i]] != null)
    			{
    				if (iColumnCount > 0)
    				{
    					sInsertStatement.append(", ");
    				}
    				sInsertStatement.append(cmdServerColumnMetaData[iaWriteables[i]].getColumnName().getQuotedName());
    				iColumnCount++;
    			}
    		}
    
    		if (iColumnCount == 0)
    		{
    			// if no storable columns, put in a dummy one
    			for (int i = 0; iColumnCount == 0 && i < iaWriteables.length; i++)
    			{
    				if (!cmdServerColumnMetaData[iaWriteables[i]].isAutoIncrement())
    				{
    					sDummyColumn = cmdServerColumnMetaData[iaWriteables[i]].getColumnName().getQuotedName();
    					sInsertStatement.append(sDummyColumn);
    					iColumnCount++;
    				}
    			}
    		}
    
    		// Add values '?' to insert
    		sInsertStatement.append(") VALUES (");
    		
    		if (iColumnCount > 0)
    		{
    			sInsertStatement.append("?");
    			
    			for (int i = 1; i < iColumnCount; i++)
    			{
    				sInsertStatement.append(",?");
    			}
    		}
    		sInsertStatement.append(")");
    
    		setModified(true);
    		
    		if (record != null)
    		{
    		    if (pNewDataRow != null && pNewDataRow.length > 0)
    		    {
    		    	 record.setParameter(sInsertStatement, pNewDataRow);
    		    }
    		    else
    		    {
    		    	 record.setParameter(sInsertStatement);
    		    }
    		}
    		
    		pNewDataRow = insertDatabaseSpecific(pWriteBackTable, sInsertStatement.toString(), pServerMetaData, pNewDataRow, sDummyColumn);

    		if (isLogEnabled(LogLevel.DEBUG))
    		{
    			debug(sInsertStatement.toString(), "[", pNewDataRow, "]");
    		}
    		
    		//NO PK, and all columns are null -> Exception -> but shouldn't happen if we want import
    		//empty records via API calls
    		if (pServerMetaData.getPrimaryKeyType() != PrimaryKeyType.AllColumns)
    		{
    			// check Empty PK and throw Exception
    			boolean bPKEmpty = true;
    			int[] iPKColsIndices = pServerMetaData.getPrimaryKeyColumnIndices();
    			
    			if (iPKColsIndices != null)
    			{
    				for (int i = 0; i < iPKColsIndices.length && bPKEmpty; i++)
    				{
    					if (pNewDataRow[iPKColsIndices[i]] != null)
    					{
    						bPKEmpty = false;
    					}
    				}
    			}
    			
    			if (bPKEmpty)
    			{
    				throw new DataSourceException("Primary key column empty after insert! " + pWriteBackTable);
    			}
    		}
    		
    		return pNewDataRow;
	    }
	    finally
	    {
	        CommonUtil.close(record);
	    }
	}
	
	/**
	 * Sets the value for the limit for what is considered a "large object".
	 * <p/>
	 * This limit is used for columns which have the
	 * {@code fetchLargObjectsLazy} option set to determine
	 * if the current object should be lazily fetched or not.
	 * <p/>
	 * "Lazy" means that the object is only send to the client if the value is
	 * actually requested. It is still fetched from the datasource and cached on
	 * the server side.
	 * 
	 * @param pLargeObjectLimit the new limit.
	 */
	public void setLargeObjectLimit(long pLargeObjectLimit)
	{
		lLargeObjectLimit = pLargeObjectLimit;
	}
	
	/**
	 * {@inheritDoc}
	 */
	public Object[] update(String pWriteBackTable, ServerMetaData pServerMetaData, Object[] pOld, Object[] pNew) throws DataSourceException
	{
        Record record = ProtocolFactory.openRecord("UPDATE", pWriteBackTable);
        
        try
        {
    		// TODO [RH] Maybe check if the new row is different to the values in the database -> fetch first.
    		if (!isOpen())
    		{
    			throw new DataSourceException("DBAccess is not open!");
    		}
    
    		if (pWriteBackTable == null)
    		{
    			throw new DataSourceException("Missing WriteBackTable!");
    		}
    		
    		if (pServerMetaData.getPrimaryKeyColumnNames() == null || pServerMetaData.getPrimaryKeyColumnNames().length == 0)
    		{
    			throw new DataSourceException("PK Columns empty! - update not possible!");
    		}
    		
    		StringBuilder sUpdateStatement = new StringBuilder("UPDATE ");
    		sUpdateStatement.append(pWriteBackTable);
    		sUpdateStatement.append(" SET ");
    
    		// add column names to update
    		int iColumnCount = 0;
    		ServerColumnMetaData[] cmdServerColumnMetaData = pServerMetaData.getServerColumnMetaData();
    		int[] iaWriteables = pServerMetaData.getWritableColumnIndices();
    		
    		for (int i = 0; i < iaWriteables.length; i++)
    		{
    			IDataType dtDataType = cmdServerColumnMetaData[iaWriteables[i]].getDataType();
    	        if (dtDataType.compareTo(pNew[iaWriteables[i]], pOld[iaWriteables[i]]) != 0)
    	        {
    				if (iColumnCount > 0)
    				{
    					sUpdateStatement.append(", ");
    				}
    				sUpdateStatement.append(cmdServerColumnMetaData[iaWriteables[i]].getColumnName().getQuotedName());
    				sUpdateStatement.append(" = ? ");
    				iColumnCount++;
    	        }
    		}
    		
    		// construct Filter over PK cols 
    		ICondition pPKFilter = Filter.createEqualsFilter(
    				pServerMetaData.getPrimaryKeyColumnNames(), pOld, pServerMetaData.getMetaData().getColumnMetaData());
    
    		int iCount = 0;
    		if (iColumnCount == 0)
    		{
    			// no storable columns; then....
    			
    			try
    			{
    				// if select for update supported from db and not in autocommit mode, then 
    				// lock the record and determine the count of rows which exists to this PK!
    				
    				// the count of rows is important, to decide later if we make an update(iCount==1), insert(iCount==0) 
    				// or throw an error because to many rows (iCount>1) are affected from the update.
    				if (!cConnection.getAutoCommit() && cConnection.getMetaData().supportsSelectForUpdate())
    				{
    					iCount = lockRowInternal(pWriteBackTable, pServerMetaData, pPKFilter);
    				}
    				else
    				{
    					// otherwise only determine the count of rows exists for this PK 
    					StringBuilder sbfSelect = new StringBuilder("SELECT * FROM ");
    					sbfSelect.append(pWriteBackTable);
    					sbfSelect.append(getWhereClause(pServerMetaData, pPKFilter, null, false));
    					
    					iCount = getRowCount(sbfSelect.toString(), pPKFilter, 1); 
    				}
    			}
    			catch (SQLException se)
    			{
    				throw new DataSourceException("Connection access failed!", formatSQLException(se));
    			}
    		}
    		else
    		{
    			// add WHERE Clause
    			sUpdateStatement.append(getWhereClause(pServerMetaData, pPKFilter, null, false));
    
    			setModified(true);
    			
    			iCount = updateDatabaseSpecific(pWriteBackTable, sUpdateStatement.toString(), pServerMetaData, 
    					                        pOld, pNew, pPKFilter);
    			
    			if (isLogEnabled(LogLevel.DEBUG))
    			{
    				debug(sUpdateStatement.toString(), "[", pNew, "]");
    			}
    		}

    		if (record != null)
    		{
    			record.setCount(iCount);
    			
        		if (record != null)
        		{
        		    if (pNew != null && pNew.length > 0)
        		    {
        		    	 record.setParameter(sUpdateStatement, pNew);
        		    }
        		    else
        		    {
        		    	 record.setParameter(sUpdateStatement);
        		    }
        		}	
    		}
    		
    		// the count of rows is important to decide if we make an update(iCount==1), insert(iCount==0) 
    		// or throw an error because to many rows (iCount>1) are affected from the update.
    		if (iCount == 0)
    		{
    			return insert(pWriteBackTable, pServerMetaData, pNew);
    		}
    		else if (iCount != 1)
    		{
    			throw new DataSourceException("Update failed ! - Result row count != 1 ! - " +  sUpdateStatement.toString());
    		}
    		
    		if (iColumnCount == 0)
    		{
    			// no storable columns; then.... return oldRow
    			return pOld;
    		}
    		
    		return pNew;
        }
        finally
        {
            CommonUtil.close(record);
        }
	}
	
	/**
	 * Updates the specified row and returns the count of affected rows. <br>
	 * Database specific implementation should override this method to implement the specific update code.
	 * 
	 * @param pWriteBackTable	the table to use for the update
	 * @param sUpdateStatement	the SQL Statement to use for the update
	 * @param pServerMetaData	the meta data to use.
	 * @param pOld				the old row (values) to use.
	 * @param pNew				the new row (values) to use.
	 * @param pPKFilter			the PrimaryKey equals filter to use.
	 * @return the count of updates rows from a Ansi SQL Database.
	 * @throws DataSourceException
	 *             if an <code>Exception</code> occur during update to the storage
	 */
	public int updateDatabaseSpecific(String pWriteBackTable, String sUpdateStatement, 
			                          ServerMetaData pServerMetaData, Object[] pOld, 
			                          Object[] pNew, ICondition pPKFilter)  throws DataSourceException
	{
		return updateAnsiSQL(pWriteBackTable, sUpdateStatement, pServerMetaData, pOld, pNew, pPKFilter);
	}

	/**
	 * Updates the specified row and return the count of affected rows. <br>
	 * 
	 * @param pWriteBackTable	the table to use for the update
	 * @param sUpdateStatement	the SQL Statement to use for the update
	 * @param pServerMetaData	the meta data to use.
	 * @param pOld				the old row (values) to use.
	 * @param pNew				the new row (values) to use.
	 * @param pPKFilter			the PrimaryKey equals filter to use.
	 * @return the count of updates rows from a Ansi SQL Database.
	 * @throws DataSourceException
	 *             if an <code>Exception</code> occur during update to the storage
	 */
	public int updateAnsiSQL(String pWriteBackTable, String sUpdateStatement, 
                			 ServerMetaData pServerMetaData, Object[] pOld, Object[] pNew, 
                			 ICondition pPKFilter)  throws DataSourceException
	{
		ServerColumnMetaData[] cmdServerColumnMetaData = pServerMetaData.getServerColumnMetaData();
		int[] iaWriteables = pServerMetaData.getWritableColumnIndices();
		
		// update DataRow into database
		PreparedStatement psUpdate = getPreparedStatement(sUpdateStatement, false);
		try
		{
			// set Parameter with storable Column Values
			int iLastParameterIndex = setColumnsToStore(psUpdate, cmdServerColumnMetaData, iaWriteables, pNew, pOld) + 1;
			
			// set WHERE Parameter with Values from PK of the old DataRow
			setFilterParameter(iLastParameterIndex, psUpdate, getParameter(pPKFilter));
			
			return executeUpdate(psUpdate);
		}
		finally
		{
		    CommonUtil.close(psUpdate);
		}
	}
	
	/**
	 * {@inheritDoc}
	 */
	public void delete(String pWriteBackTable, ServerMetaData pServerMetaData, Object[] pDelete) throws DataSourceException
	{
        Record record = ProtocolFactory.openRecord("DELETE", pWriteBackTable);
        
        try
        {
    		if (!isOpen())
    		{
    			throw new DataSourceException("DBAccess is not open!");
    		}
    
    		if (pWriteBackTable == null)
    		{
    			throw new DataSourceException("Missing WriteBackTable!");
    		}
    
    		if (pServerMetaData.getPrimaryKeyColumnNames() == null || pServerMetaData.getPrimaryKeyColumnNames().length == 0)
    		{
    			throw new DataSourceException("PK Columns empty! - delete not possible!");
    		}
    		
    		ICondition pPKFilter = null;
    		
    		ServerColumnMetaData[] pServerColumnMetaData = pServerMetaData.getServerColumnMetaData();
    		String[] pPKColumns = pServerMetaData.getPrimaryKeyColumnNames();
    		
    		if (pServerColumnMetaData != null)
    		{
    			pPKFilter = Filter.createEqualsFilter(pPKColumns, pDelete, pServerMetaData.getMetaData().getColumnMetaData());
    		}
    		else
    		{
    			// if pColumnMetaData is set, we use the pDelete columns as it is as values for the Equals
    			// over the primary key columns
    			pPKFilter = new Equals(pPKColumns[0], pDelete[0]);
    			for (int i = 1; i < pPKColumns.length; i++)
    			{
    				pPKFilter = pPKFilter.and(new Equals(pPKColumns[i], pDelete[i]));
    			}
    		}
    		
    		StringBuilder sDeleteStatement = new StringBuilder("DELETE FROM ");
    		sDeleteStatement.append(pWriteBackTable);
    		
    		String sWHERE = getWhereClause(pServerMetaData, pPKFilter, null, false);
    		sDeleteStatement.append(sWHERE);
    				
    		debug("delete(", sDeleteStatement, ")", pPKColumns, pDelete);
    
    		// delete DataRow in database
    		PreparedStatement psDelete = getPreparedStatement(sDeleteStatement.toString(), false);
    		
    		try
    		{
    			// set Filter Parameter Values
    			setFilterParameter(1, psDelete, getParameter(pPKFilter));
    			
    			setModified(true);
    			
    			int iCount = executeUpdate(psDelete);
    			
    			if (iCount > 1)
    			{
    				throw new DataSourceException("Delete failed ! - Result row count > 1 ! - " + iCount + "," + sDeleteStatement.toString());
    			}
    			
        		if (record != null)
        		{
        		    if (getParameter(pPKFilter) != null && getParameter(pPKFilter).length > 0)
        		    {
        		    	 record.setParameter(sDeleteStatement, getParameter(pPKFilter));
        		    }
        		    else
        		    {
        		    	 record.setParameter(sDeleteStatement);
        		    }
        		}

    		}
    		finally
    		{
    		    CommonUtil.close(psDelete);
    		}
        }
        finally
        {
            CommonUtil.close(record);
        }
	}

	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Overwritten methods
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		StringBuilder sbResult = new StringBuilder();
		
		String sShowPassword;
		if (sPassword != null)
		{
			sShowPassword = ",Password set";
		}
		else
		{
			sShowPassword = ",Password not set";
		}

		boolean bOpen = false;
		try 
		{
			bOpen = isOpen();
		}
		catch (DataSourceException dataSourceException)
		{
			return sbResult.toString() + " :: " + dataSourceException.getMessage();
		}
		
		Properties propCopy = new Properties(properties);
		propCopy.remove("user");
		propCopy.remove("password");
		
		sbResult.append("DBAccess :: Connected=");
		sbResult.append(bOpen);
		sbResult.append(", ConnectionString=");
		sbResult.append(sUrl);
		sbResult.append(", DriverName=");
		sbResult.append(sDriver);
		sbResult.append(", UserName=");
		sbResult.append(sUsername);
		sbResult.append(sShowPassword);
		sbResult.append(",Properties=");
		sbResult.append(propCopy);
		sbResult.append("\n");
		
		sbResult.append("ResultSet Cache:\n");
		
		for (Map.Entry<Select, ResultSet> entry : htFetchResultSetCache.entrySet())
		{
			sbResult.append(entry.getKey());
			sbResult.append("\n");
		}

		sbResult.append(super.toString());
		
		return sbResult.toString();
	}	

	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// User-defined methods
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	/**
	 * Gets the database specific open quote character.
	 * 
	 * @return the open quote character
	 */
	public String getOpenQuoteCharacter()
	{
		return sOpenQuote;
	}
	
	/**
	 * Gets the database specific quote character.
	 * 
	 * @return the close quote character
	 */
	public String getCloseQuoteCharacter()
	{
		return sCloseQuote;
	}
	
	/**
	 * Sets the database specific quote characters.
	 * 
	 * @param pOpen the open quote character
	 * @param pClose the close quote character
	 */
	protected void setQuoteCharacters(String pOpen, String pClose)
	{
		sOpenQuote  = pOpen;
		sCloseQuote = pClose;
	}
	
	/**
	 * It returns true if this name should be automated quoted. 
	 * e.g. in Oracle default all isUppercase(), so if the name has one loweCase character, then AutoQuote is true to quote this name.
	 * 
	 * @param pName the name to quote.
	 * @return true if this name should be automated quoted.
	 */
	public boolean isAutoQuote(String pName)
	{
		CaseSensitiveType type = StringUtil.getCaseSensitiveType(pName);
		
		return type == CaseSensitiveType.UpperCase ? false : true;
	}
	
	/**
	 * Quotes a named DB object with our internal quote character, if it should be quoted in this database.
	 * Thats the case if the name != to the default case sensitivness. e.g. in Oracle != upperCase()
	 * 
	 * @param pName	the name to use. 
	 * @return the quoted name if quoting in this database is necessary or otherwise just the name.
	 */
	public String quote(String pName)
	{
		if (pName == null)
		{
			return null;
		}
		if (isAutoQuote(pName))
		{
			return quoteAllways(pName);		
		}
		return pName;
	}
	
	/**
	 * Quotes a named DB object with the JVx DB QUOTE character.
	 * 
	 * @param pName		the name to use. 
	 * @return the name quoted.
	 */
	public String quoteAllways(String pName)
	{
		StringBuilder sbResult = new StringBuilder(QUOTE); 
		sbResult.append(StringUtil.replace(pName, QUOTE, "\\" + QUOTE));
		sbResult.append(QUOTE);
		return sbResult.toString();
	}

	/**
	 * Removes the JVx DB Quotes of a named DB object.
	 * 
	 * @param pName		the name to use. 
	 * @return the unquoted name.
	 */
	public static String removeQuotes(String pName)
	{
		if (pName == null)
		{
			return null;
		}
		StringBuilder sbResult = new StringBuilder(); 
		char          q        = QUOTE.charAt(0);
		for (int i = 0, iSize = pName.length(); i < iSize; i++)
		{
			char curr = pName.charAt(i);
			if (q == curr)
			{
				// remove escape character
				if (i != 0 && pName.charAt(i - 1) == '\\')
				{
					sbResult.deleteCharAt(sbResult.length() - 1);
					sbResult.append(curr);
				}
			}
			else
			{
				sbResult.append(curr);
			}
		}
		return sbResult.toString();
	}
	
	/**
	 * Removes the DB specific quotes of a named DB object.
	 * 
	 * @param pName		the name to use. 
	 * @return the unquoted name.
	 */
	public String removeDBSpecificQuotes(String pName)
	{
		return StringUtil.removeQuotes(pName, sOpenQuote, sCloseQuote);
	}
	
	/**
	 * It replaces all JVx quotes with the database specific quote.
	 * 
	 * @param pStatement		the statement to use. 
	 * @return the database specific quoted statement.
	 */
	public String translateQuotes(String pStatement)
	{
		if (pStatement == null)
		{
			return null;
		}
		
		StringBuilder sbResult = new StringBuilder(); 
		char          q        = QUOTE.charAt(0);
		boolean       bUseOpen = true;
		for (int i = 0, iSize = pStatement.length(); i < iSize; i++)
		{
			char curr = pStatement.charAt(i);
			if (q == curr)
			{
				// remove escape character
				if (i != 0 && pStatement.charAt(i - 1) == '\\')
				{
					sbResult.deleteCharAt(sbResult.length() - 1);
					sbResult.append(curr);
				}
				else
				{
					if (bUseOpen)
					{
						sbResult.append(sOpenQuote);
						bUseOpen = false;
					}
					else
					{
						sbResult.append(sCloseQuote);
						bUseOpen = true;
					}
				}
			}
			else
			{
				sbResult.append(curr);
			}
		}
		return sbResult.toString();
	}	
	
	/**
	 * It opens the database and stores the <code>Connection</code> object.
	 * 
	 * @throws DataSourceException
	 *             if the database couldn't opened
	 */
	public void open() throws DataSourceException
	{
		//#607
		if (!isOpen())
		{
			ISession sess = SessionContext.getCurrentSession();
			
			if (sess != null)
			{
				sApplicationName = sess.getApplicationName();
			}
			
			if (sApplicationName == null)
			{
				sApplicationName = "";
			}
			
			long lMillis = System.currentTimeMillis();
			
			if (!bExternalConnection)
			{
				if (sUrl == null)
				{
					throw new DataSourceException("Connection String is null!");
				}
				
				try
				{
				    String sPlainUserName = translateQuotes(sUsername);
				    
					Connection con = null;
					
					if (!isJdbc(sUrl))
					{
					    try
					    {
    		                InitialContext ctxt = new InitialContext();
    		                
		                    try
		                    {
		                        Object objInstance = ctxt.lookup(sUrl);
		                        
		                        if (objInstance instanceof Connection)
		                        {
		                            con = (Connection)objInstance;
		                            
		                            bAutoClose = true;
		                            bExternalConnection = true;
		                        }
		                        else if (objInstance instanceof DataSource)
		                        {
		                            if (!StringUtil.isEmpty(sPlainUserName) && !StringUtil.isEmpty(sPassword))
		                            {
		                                con = ((DataSource)objInstance).getConnection(sPlainUserName, sPassword);
		                            }
		                            else
		                            {
		                                con = ((DataSource)objInstance).getConnection();
		                            }
		                            
	                                bAutoClose = true;
	                                bExternalConnection = true;
		                        }
		                        else
		                        {
		                            throw new DataSourceException("Configured JNDI resource '" + sUrl + "' has to be a Connection, but is " + 
		                                                          (objInstance != null ? objInstance.getClass().getName() : "null"));
		                        }
		                    }
		                    finally
		                    {
		                        ctxt.close();
		                    }
					    }
					    catch (Exception ex)
					    {
					        if (ex instanceof DataSourceException)
					        {
					            throw (DataSourceException)ex;
					        }
					        
					        throw new DataSourceException("JNDI URL used, but resource was not found!", ex);
					    }
					}
					else
					{
		                if (sDriver == null)
		                {
		                    throw new DataSourceException("Jdbc Driver is null!");
		                }

		                try
		                {
		                    Class.forName(sDriver);
		                }
		                catch (Exception exception)
		                {
		                    throw new DataSourceException("Jdbc driver not found!", exception);
		                }
					    
	                    Properties propCopy = new Properties(properties);
	                    
	                    if (sUsername != null)
	                    {
	                        propCopy.setProperty("user", sUsername);
	                    }
	                    
	                    if (sPassword != null)
	                    {
	                        propCopy.setProperty("password", sPassword);
	                    }
					    
					    con = DriverManager.getConnection(sUrl, propCopy);
					}
					
					//#515
					if (con.getTransactionIsolation() != Connection.TRANSACTION_READ_COMMITTED)
					{
						con.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
					}
					
					//default setting (not all JDBC drivers use auto-commit as default setting, e.g. PostgreSql)
				    con.setAutoCommit(true);
					
					setConnection(con);
				}
				catch (SQLException sqlException)
				{
					String sShowPassword;
					if (sPassword != null)
					{
						sShowPassword = "Password set";
					}
					else
					{
						sShowPassword = "Password not set";
					}
					
					throw new DataSourceException("Connection failed! - " + sUrl + "; Username=" +
							                      sUsername + "; " + sShowPassword, formatSQLException(sqlException));
				}
			}
			
			try
			{
				iMaxColumnLength = cConnection.getMetaData().getMaxColumnNameLength();
				// #447 - if getMaxColumnNameLength() return 0, we should interprete it as unlimmited 
				if (iMaxColumnLength == 0)
				{
					iMaxColumnLength = Integer.MAX_VALUE;
				}
			}
			catch (SQLException sqlException)
			{
				iMaxColumnLength = 30;
				
				debug(sqlException);
			}
			
			bModified = false;
			
            if (isLogEnabled(LogLevel.DEBUG))
            {
                debug("open(", sUrl, ",", translateQuotes(sUsername), ") in ", Long.valueOf(System.currentTimeMillis() - lMillis), "ms");
            }
		}
		else
		{
			debug("connection is already open!");
		}
	}

	/**
	 * Returns true, if the database is still open.
	 * 
	 * @return true, if the database is still open.
	 * @throws DataSourceException
	 *             if isClosed() on the DB <code>Connection</code> throws an Exception
	 */
	public boolean isOpen() throws DataSourceException
	{
		try
		{
			return cConnection != null && !cConnection.isClosed();
		}
		catch (SQLException sqlException)
		{
			throw new DataSourceException("Open failed!", formatSQLException(sqlException));
		}
	}

	/**
	 * Closes the database <code>Connection</code> and releases all memory.
	 * 
	 * @throws DataSourceException if database couldn't closed.
	 */
	public void close() throws DataSourceException
	{
	    if (isOpen())
	    {
	        commitOrRollbackBeforeClose();

            if (bAutoClose)
            {
                CommonUtil.close(cConnection);
                
                setConnection(null);
            }
	    }
	}

	/**
	 * Calls commit or rollback before closing the connection.
	 */
	protected void commitOrRollbackBeforeClose()
	{
        try
        {
            if (cConnection.getAutoCommit())
            {
                cConnection.commit();
            }
            else
            {
                cConnection.rollback();
            }
        }
        catch (SQLException sqle)
        {
            debug(sqle);
        }
	}
	
	/**
	 * Sets auto-commit state.
	 * 
	 * @param pEnable <code>true</code> to enable, <code>false</code> to disable auto-commit
	 * @throws DataSourceException if setting state failed
	 */
	public void setAutoCommit(boolean pEnable) throws DataSourceException
	{
	    if (!isOpen())
	    {
	        throw new DataSourceException("DBAccess is not open!");
	    }

	    try
	    {
	        cConnection.setAutoCommit(pEnable);
        }
        catch (SQLException sqlException)
        {
            throw new DataSourceException("Setting autocommit state failed!", formatSQLException(sqlException));
        }
	}

    /**
     * Gets whether auto-commit is en-/disabled.
     * 
     * @return <code>true</code> if enabled, <code>false</code> otherwise
     * @throws DataSourceException if getting state failed
     */
	public boolean isAutoCommit() throws DataSourceException
	{
	    if (!isOpen())
	    {
	        throw new DataSourceException("DBAccess is not open!");
	    }

	    try
	    {
	        return cConnection.getAutoCommit();
        }
        catch (SQLException sqlException)
        {
            throw new DataSourceException("Can't check autocommit state!", formatSQLException(sqlException));
        }
	}
	
	/**
	 * Rollback the DB transaction.
	 * 
	 * @throws DataSourceException if the transaction couldn't rollback
	 */
	public void rollback() throws DataSourceException
	{
		if (!isOpen())
		{
			throw new DataSourceException("DBAccess is not open!");
		}
		try
		{
			cConnection.rollback();	
			
            setModified(false);
		}
		catch (SQLException sqlException)
		{
			throw new DataSourceException("Rollback failed!", formatSQLException(sqlException));
		}
	}

	/**
	 * Commits the DB transaction.
	 * 
	 * @throws DataSourceException
	 *             if the transaction couldn't commit
	 */
	public void commit() throws DataSourceException
	{
		if (!isOpen())
		{
			throw new DataSourceException("DBAccess is not open!");
		}
		try
		{
			cConnection.commit();
			
			setModified(false);
		}
		catch (SQLException sqlException)
		{
			throw new DataSourceException("Commit failed!", formatSQLException(sqlException));
		}
	}
	
	/**
	 * Gets the query time out.
	 * 
	 * @return the timeout in miliseconds
	 */
	public int getQueryTimeOut()
	{
		return iQueryTimeOut;
	}
	
	/**
	 * Sets the query time out.
	 * 
	 * @param pQueryTimeOut
	 * 				the timeout in miliseconds
	 */
	public void setQueryTimeOut(int pQueryTimeOut)
	{
		iQueryTimeOut = pQueryTimeOut;
	}
	
	/**
	 * Returns the <code>conncetion</code> to the database.
	 * 
	 * @return the <code>conncetion</code> to the database.
	 */
	public Connection getConnection()
	{
		return cConnection;
	}	
	
	/**
	 * Sets the internal <code>conncetion</code> to the database.
	 * 
	 * @param pConnection the <code>conncetion</code> to the database
	 */
	protected void setConnection(Connection pConnection)
	{
		cConnection = pConnection;
	}
	
	/**
	 * Gets the database driver name as <code>String</code>.
	 * 
	 * @return pDriverName the database driver name
	 */
	public String getDriver()
	{
		return sDriver;
	}

	/**
	 * Sets the database driver name as <code>String</code>.
	 * 
	 * @param pDriver the database driver name
	 */
	public void setDriver(String pDriver)
	{
		sDriver = pDriver;
	}

	/**
	 * Gets the jdbc url <code>String</code> for this database.
	 * 
	 * @return	the jdbc url <code>String</code>.
	 */
	public String getUrl()
	{
		return sUrl;
	}

	/**
	 * Sets the url <code>String</code> for this database.
	 * 
	 * @param pUrl	the jdbc url <code>String</code>.
	 */
	public void setUrl(String pUrl)
	{
		sUrl = pUrl;
	}

	/**
	 * Gets the user name to connect with.
	 * 
	 * @return pUser	the user name
	 */
	public String getUsername()
	{
		return sUsername;
	}

	/**
	 * Sets the user name to connect with.
	 * 
	 * @param pUsername  the user name
	 */
	public void setUsername(String pUsername)
	{
		sUsername = pUsername;
	}

	/**
	 * Sets the password to use for the connection to the database.
	 * 
	 * @return pPassword the password to use for the database
	 */
	public String getPassword()
	{
		return sPassword;
	}

	/**
	 * Sets the password to use for the connection to the database.
	 * 
	 * @param pPassword the password to use for the database
	 */
	public void setPassword(String pPassword)
	{
		sPassword = pPassword;
	}

	/**
	 * Sets a specific database property.
	 * 
	 * @param pName the property name
	 * @param pValue th value
	 */
	public void setDBProperty(String pName, String pValue)
	{
		if (pValue == null)
		{
			properties.remove(pName);
		}
		else
		{
			properties.setProperty(pName, pValue);
		}
	}
	
	/**
	 * Gets the value for a specific database property.
	 * 
	 * @param pName the property name
	 * @return the value or <code>null</code> if the property was not found
	 */
	public String getDBProperty(String pName)
	{
		return properties.getProperty(pName);
	}
	
	/**
	 * Sets DB specific initial parameters for the <code>Connection</code> creation.
	 * 
	 * @param pProperties
	 *            DB specific initial parameters
	 */
	public void setDBProperties(Properties pProperties)
	{
		properties = pProperties;
	}

	/**
	 * Returns the DB specific initial parameters for the <code>Connection</code> creation.
	 * 
	 * @return the DB specific initial parameters for the <code>Connection</code> creation.
	 */
	public Properties getDBProperties()
	{
		return properties;
	}

	/**
	 * Returns the maximum time in miliseconds to use, to try to fetch all rows. reduce open cursors, and increase performance.
	 *
	 * @return the iMaxTime.
	 */
	public int getMaxTime()
	{
		return iMaxTime;
	}

	/**
	 * Sets the maximum time in miliseconds to use, to try to fetch all rows. reduce open cursors, and increase performance.
	 *
	 * @param pMaxTime the iMaxTime to set
	 */
	public void setMaxTime(int pMaxTime)
	{
		iMaxTime = pMaxTime;
	}
	
	/**
	 * Returns the maximum allowed column length.
	 *
	 * @return the iMaxColumnLength.
	 */
	public int getMaxColumnLength()
	{
		return iMaxColumnLength;
	}

	/**
	 * Executes a DB procedure with the specified parameters.
	 * 
	 * @param pProcedureName the procedure (optional with package) name. 
	 * @param pParameters the parameters to use with the correct and corresponding java type.
	 * @throws DataSourceException if the call failed.
	 */
	public void executeProcedure(String pProcedureName, Object...pParameters) throws DataSourceException
	{
		Record record = ProtocolFactory.openRecord("EXECUTE_PROCEDURE");
		
		if (record != null)
		{
		    if (pParameters != null && pParameters.length > 0)
		    {
    		    record.setParameter(pProcedureName, pParameters);
		    }
		    else
		    {
		        record.setParameter(pProcedureName);
		    }
		}
		
		if (!isOpen())
		{
			throw new DataSourceException("DBAccess is not open!");
		}

		StringBuilder sqlStatement = new StringBuilder("{ call ");
		sqlStatement.append(pProcedureName);
		
		if (pParameters != null && pParameters.length > 0)
		{
			sqlStatement.append("(");
			for (int i = 0; i < pParameters.length; i++)
			{
				if (i > 0)
				{
					sqlStatement.append(", ");			
				}
				sqlStatement.append("?");			
			}
			sqlStatement.append(")");
		}
		sqlStatement.append(" }");
		
		CallableStatement call = null;
		try
		{
			debug("executeProcedure -> ", sqlStatement);
			
			AbstractParam apParam;
			
			ParameterType type;

			call = cConnection.prepareCall(translateQuotes(sqlStatement.toString()));
			for (int i = 0; pParameters != null && i < pParameters.length; i++)
			{
				if (pParameters[i] == null)
				{
					call.setNull(i + 1, Types.VARCHAR);
				}
				else
				{
					if (pParameters[i] instanceof AbstractParam)
					{
						apParam = (AbstractParam)pParameters[i];

						type = apParam.getType();
						
						if (type == ParameterType.Out || type == ParameterType.InOut)
						{
							call.registerOutParameter(i + 1, apParam.getSqlType());
						}
						
						if (apParam.getValue() == null)
						{
							call.setNull(i + 1, apParam.getSqlType());
						}
						else
						{
							call.setObject(i + 1, convertValueToDatabaseSpecificObject(apParam.getValue()), apParam.getSqlType());
						}
					}
					else
					{
						call.setObject(i + 1, convertValueToDatabaseSpecificObject(pParameters[i]));
					}
				}
			}
			
			call.execute();
			
			for (int i = 0; pParameters != null && i < pParameters.length; i++)
			{
				if (pParameters[i] instanceof AbstractParam)
				{
					apParam = (AbstractParam)pParameters[i];
					
					type = apParam.getType();
					
					if (type == ParameterType.Out || type == ParameterType.InOut)
					{
						apParam.setValue(call.getObject(i + 1));
					}
				}
			}
		}
		catch (SQLException sqlException)
		{
			throw new DataSourceException("executeProcedure failed! - " + sqlStatement, formatSQLException(sqlException));
		}
		finally 
		{
		    CommonUtil.close(call);
		    
		    CommonUtil.close(record);
		}
	}	
	
	/**
	 * Executes a DB function with the specified parameters and return the result.
	 * 
	 * @param pFunctionName the function (optional with package) name. 
	 * @param pReturnType the return SQL Type (see {@link Types}
	 * @param pParameters the parameters to use with the correct and corresponding java type.
	 * @return the result of the DB function call.
	 * @throws DataSourceException	if the call failed.
	 */
	public Object executeFunction(String pFunctionName, int pReturnType, Object...pParameters) throws DataSourceException
	{
		Record record = ProtocolFactory.openRecord("EXECUTE_FUNCTION");
		
		if (record != null)
		{
		    if (pParameters != null && pParameters.length > 0)
		    {
    		    record.setParameter(pFunctionName, pParameters);
		    }
		    else
		    {
		        record.setParameter(pFunctionName);
		    }
		}
		
		if (!isOpen())
		{
			throw new DataSourceException("DBAccess is not open!");
		}

		StringBuilder sqlStatement = new StringBuilder("{ ? = call ");
		sqlStatement.append(pFunctionName);
		
		if (pParameters != null && pParameters.length > 0)
		{
			sqlStatement.append("(");
			for (int i = 0; i < pParameters.length; i++)
			{
				if (i > 0)
				{
					sqlStatement.append(", ");
				}
				sqlStatement.append("?");
			}
			sqlStatement.append(")");
		}
		sqlStatement.append(" }");
		
		CallableStatement call = null;
		try
		{
			debug("executeFunction -> ", sqlStatement);
			
			call = cConnection.prepareCall(translateQuotes(sqlStatement.toString()));
			call.registerOutParameter(1, pReturnType);
			
			AbstractParam apParam;
			
			ParameterType type;
			
			for (int i = 0; pParameters != null && i < pParameters.length; i++)
			{
				if (pParameters[i] == null)
				{
					call.setNull(i + 2, Types.VARCHAR);
				}
				else
				{
					if (pParameters[i] instanceof AbstractParam)
					{
						apParam = (AbstractParam)pParameters[i];
						
						type = apParam.getType();
						
						if (type == ParameterType.Out || type == ParameterType.InOut)
						{
							call.registerOutParameter(i + 2, apParam.getSqlType());
						}
						
						if (apParam.getValue() == null)
						{
							call.setNull(i + 2, apParam.getSqlType());
						}
						else
						{
							call.setObject(i + 2, convertValueToDatabaseSpecificObject(apParam.getValue()), apParam.getSqlType());
						}
					}
					else
					{
						call.setObject(i + 2, convertValueToDatabaseSpecificObject(pParameters[i]));
					}
				}
			}
			
			if (call.execute())
			{
			    CommonUtil.close(call.getResultSet());
			}
			
			Object oResult = call.getObject(1);
			
			for (int i = 0; pParameters != null && i < pParameters.length; i++)
			{
				if (pParameters[i] instanceof AbstractParam)
				{
					apParam = (AbstractParam)pParameters[i];
					
					type = apParam.getType();
					
					if (type == ParameterType.Out || type == ParameterType.InOut)
					{
						apParam.setValue(call.getObject(i + 2));
					}
				}
			}
			
			return oResult;
		}
		catch (SQLException sqlException)
		{
			throw new DataSourceException("executeFunction failed! - " + sqlStatement, formatSQLException(sqlException));
		}
		finally 
		{
		    CommonUtil.close(call);
		    
		    CommonUtil.close(record);
		}
	}

	/**
	 * Executes a DDL or DML Statement.
	 * 
	 * @param pStatement the statement.
	 * @throws SQLException	if an error occur during execution.
	 */
	public void executeStatement(String pStatement) throws SQLException
	{
		Record record = ProtocolFactory.openRecord("EXECUTE_STATEMENT");
		
		if (record != null)
		{
			record.setParameter(pStatement);
		}
		
		Statement stmt = null;
				
		try
		{
			stmt = getConnection().createStatement();
			
			String sStmt = translateQuotes(pStatement);
			
			debug("executeStatement -> ",  sStmt);
			
			if (stmt.execute(sStmt))
			{
			    CommonUtil.close(stmt.getResultSet());
			}
		}
		finally
		{
		    CommonUtil.close(stmt);
		    
		    CommonUtil.close(record);
		}
	}
	
	/**
	 * Executes a SQL command as prepared statement.
	 * 
	 * @param pStatement the statement with or without parameters
	 * @param pParameters the parameters to use
	 * @return the first parameter from the result set, for every row, or <code>null</code> if the command returned no
	 *         result
	 * @throws SQLException if an error occurs during execution
	 */
	public List<Object> executeSql(String pStatement, Object... pParameters) throws SQLException
	{
		Record record = ProtocolFactory.openRecord("EXECUTE_SQL");
		
		if (record != null)
		{
		    if (pParameters != null && pParameters.length > 0)
		    {
    		    record.setParameter(pStatement, pParameters);
		    }
		    else
		    {
		        record.setParameter(pStatement);
		    }
		}
		
		PreparedStatement psStmt = null;
		
		try
		{
			String sStmt = translateQuotes(pStatement);
			
			psStmt = getConnection().prepareStatement(sStmt);
			
			if (pParameters != null)
			{
				for (int i = 0; i < pParameters.length; i++)
				{
					if (pParameters[i] == null)
					{
						psStmt.setNull(i + 1, Types.VARCHAR);
					}
					else
					{
						psStmt.setObject(i + 1, convertValueToDatabaseSpecificObject(pParameters[i]));
					}
				}
			}
			
			debug("executeSql -> ", pStatement);
			
			if (psStmt.execute())
			{
				ResultSet res = psStmt.getResultSet();
				
				try
				{
    				if (res.next())
    				{
    					List<Object> liResult = new ArrayUtil<Object>();
    
    					do
    					{
    						liResult.add(res.getObject(1));
    					}
    					while (res.next());
    					
   		                if (record != null)
		                {
		                    record.setCount(liResult.size());
		                }
    					
    					return liResult;
    				}
				}
				finally
				{
				    CommonUtil.close(res);
				}
			}
			
			return null;
		}
		finally
		{
		    CommonUtil.close(psStmt);		    

		    CommonUtil.close(record);
		}
	}
	
	/**
	 * Return a <code>PreparedStatement</code> for the given SQL statement.<br>
	 * 
	 * @param pSqlStatement
	 *            the SQL statement to prepare
	 * @param pReturnKey
	 *            if the generated key in insert statements should returned
	 * @return a <code>PreparedStatement</code> for the given SQL statement.
	 * @throws DataSourceException
	 *             if the statement couldn't prepared.
	 */
	public PreparedStatement getPreparedStatement(String pSqlStatement, boolean pReturnKey) throws DataSourceException
	{
		if (!isOpen())
		{
			throw new DataSourceException("DBAccess is not open!");
		}

		PreparedStatement psSqlStatement;
		
		pSqlStatement = translateQuotes(pSqlStatement.toString());
		try
		{
			if (pReturnKey)
			{
				try 
				{
					psSqlStatement = cConnection.prepareStatement(pSqlStatement, Statement.RETURN_GENERATED_KEYS);
				}
				catch (SQLException sqlException)
				{
					psSqlStatement = cConnection.prepareStatement(pSqlStatement);
				}					
			}
			else
			{
				psSqlStatement = cConnection.prepareStatement(pSqlStatement);
			}
		}
		catch (SQLException sqlException)
		{
			throw new DataSourceException("PrepareStatement failed! - " + pSqlStatement, formatSQLException(sqlException));
		}

		return psSqlStatement;
	}	

	/**
	 * Calls <code>executesUpdate()</code> for specified <code>PreparedStatement</code> 
	 * and returns the number of updated rows.
	 * 
	 * @param pSqlStatement
	 *            the <code>PreparedStatement</code> to use
	 * @return number of updated rows.
	 * @throws DataSourceException
	 *             if the statement couldn't updated.
	 */
	public int executeUpdate(PreparedStatement pSqlStatement) throws DataSourceException
	{
		if (!isOpen())
		{
			throw new DataSourceException("DBAccess is not open!");
		}
		try
		{
			return pSqlStatement.executeUpdate();
		}
		catch (SQLException sqlException)
		{
			throw new DataSourceException("Execute update failed!", formatSQLException(sqlException));
		}
	}
	
	/**
	 * Adds the SQL Error Code into the message of the SQL Exception.
	 * 
	 * @param pSqlException		the SQL Exception to use.
	 * @return the SQLException with the modified error message with SQL Error Code.
	 */
	protected SQLException formatSQLException(SQLException pSqlException)
	{
		return formatSQLException(pSqlException, pSqlException.getMessage(), "" + pSqlException.getErrorCode());
	}

	/**
	 * Adds the SQL Error Code into the message of the SQL Exception.
	 * 
	 * @param pSqlException the SQL Exception to use.
	 * @param pMessage the message to use
	 * @param pCode the detected error code
	 * @return the SQLException with the modified error message with SQL Error Code.
	 */
	protected SQLException formatSQLException(SQLException pSqlException, String pMessage, String pCode)
	{
		if (pMessage.indexOf(pCode) < 0)
		{
			String sVendor = getClass().getSimpleName();
			int    index   = sVendor.indexOf("DBAccess");
			
			if (index >= 0)
			{
				sVendor = sVendor.substring(0, index);
			}
			
			SQLException sqleNew = new SQLException(sVendor + "-" + pCode + ": " + pMessage);
			sqleNew.setStackTrace(pSqlException.getStackTrace());
			sqleNew.initCause(pSqlException.getCause());
			
			return sqleNew;
		}
		
		return pSqlException;
	}
	
	/**
	 * It initialize the select for a specified storage unit and return the SELECT statement.<br>
	 * It doesn't add the ORDER BY clause.<br>
	 * 
	 * @param pServerMetaData the MetaDataColumn array to use.
	 * @param pBeforeQueryColumns the string to place in the SELECT statement between the SELECT and the first query column.
	 * @param pQueryColumns the list of query columns to use in the SELECT statement.
	 * @param pFromClause the list of query tables to use in the SELECT statement.
	 * @param pFilter the <code>Filter</code> to use
	 * @param pWhereClause the string to place in the SELECT statement after the last WHERE condition from the
	 * 			           Filter or MasterReference (Master-Detail Condition).
	 * @param pAfterWhereClause the string to place in the SELECT statement after the WHERE clause and before the ORDER BY clause.
	 * @param pSort the sort definition.
     * @param pOrderByClause the order by clause.
     * @return the SELECT statement as String.
     * @throws DataSourceException if it's not possible to build the select statement in fact of missing elements    
	 */	
	public String getSelectStatement(ServerMetaData pServerMetaData, 
                					 String pBeforeQueryColumns, String[] pQueryColumns, 
                					 String pFromClause,
                					 ICondition pFilter, String pWhereClause, String pAfterWhereClause, 
                					 SortDefinition pSort, String pOrderByClause) throws DataSourceException
	{
		if (pFromClause == null)
		{
			throw new DataSourceException("Missing FROM clause!");
		}
		
		// add select column names to select
		StringBuilder sSelectStatement = new StringBuilder("SELECT ");

		if (pBeforeQueryColumns != null)
		{
			sSelectStatement.append(pBeforeQueryColumns);
			sSelectStatement.append(" ");
		}

		if (pQueryColumns != null && pQueryColumns.length > 0 && pQueryColumns[0].length() > 0)
		{
			for (int i = 0; i < pQueryColumns.length; i++)
			{
				if (i > 0)
				{
					sSelectStatement.append(", ");
				}
				sSelectStatement.append(pQueryColumns[i]);
			}
		}
		else
		{
			sSelectStatement.append("*");
		}

		sSelectStatement.append(" FROM ");

		sSelectStatement.append(pFromClause);

		// add Filter
		sSelectStatement.append(getWhereClause(pServerMetaData, pFilter, pWhereClause, true));

		if (pAfterWhereClause != null)
		{
			sSelectStatement.append(" ");
			sSelectStatement.append(pAfterWhereClause);
			sSelectStatement.append(" ");
		}

		// add Sort
		if (pSort != null)
		{
			// use DB sorting algorithm
			sSelectStatement.append(" ORDER BY ");
			
			String[]  saSortDefinitionNames = pSort.getColumns();
			boolean[] baSortDefinitionOrder = pSort.isAscending();
			
			for (int i = 0; i < saSortDefinitionNames.length; i++)
			{
				int index = pServerMetaData.getServerColumnMetaDataIndex(saSortDefinitionNames[i]);
				if (index < 0)
				{
					sSelectStatement.append(saSortDefinitionNames[i]);
				}
				else
				{
					sSelectStatement.append(pServerMetaData.getServerColumnMetaData(index).getColumnName().getQuotedName());
				}
				if (baSortDefinitionOrder[i])
				{
					sSelectStatement.append(" ASC");
				}
				else
				{
					sSelectStatement.append(" DESC");
				}
				if (i + 1 < saSortDefinitionNames.length)
				{
					sSelectStatement.append(", ");
				}
			}
		}
		else if (!StringUtil.isEmpty(pOrderByClause))
		{
			sSelectStatement.append(" ORDER BY ");
			sSelectStatement.append(pOrderByClause);
		}
		
		return sSelectStatement.toString();
	} 

	/**
	 * Returns the WHERE clause for a UPDATE, DELETE or SELECT statement specified with
	 * a <code>Filter</code>.
	 * 
	 * @param pServerMetaData	the <code>MetaData</code> to use
	 * @param pFilter       	the <code>Filter</code> to use
	 * @param pWhereClause       the where clause to use
	 * @param pUsePrefix		<code>true</code> to use the prefixed column (real column name) and <code>false</code> to
	 *                      	ignore prefixes (the simple name of the column) 
	 * @throws DataSourceException if columns not existing
	 * @return the WHERE clause for a UPDATE, DELETE or SELECT statement specified with
	 *         a <code>Filter</code>.
	 */
	protected String getWhereClause(ServerMetaData pServerMetaData, ICondition pFilter, String pWhereClause, boolean pUsePrefix) throws DataSourceException
	{
		StringBuilder result = new StringBuilder();
		
		String sCondion = getSQL(pServerMetaData, pFilter, pUsePrefix);
		
		if (sCondion !=  null && sCondion.length() > 0)
		{
			result.append(" WHERE ");
			result.append(sCondion);
		}
		if (pWhereClause != null && pWhereClause.length() > 0)
		{
			if (sCondion == null || sCondion.length() == 0)
			{
				result.append(" WHERE ");
			}
			else
			{
				result.append(" AND ");
			}
			result.append(" ");
			result.append(pWhereClause);
			result.append(" ");
		}

		return result.toString();
	}
	
	/**
	 * Returns the database specific statement to lock the specified row in the database.
	 *  
	 * @param pWriteBackTable	the table to use.
	 * @param pPKFilter			the PK filter with the values to use.
	 * @param pServerMetaData	the MetaDataColumn array to use.
	 * @return the database specific statement to lock the specified row in the database.
	 * @throws DataSourceException if some parts are missing for the statement
	 */
	protected String getDatabaseSpecificLockStatement(String pWriteBackTable, ServerMetaData pServerMetaData, ICondition pPKFilter) throws DataSourceException
	{
		if (pWriteBackTable == null)
		{
			throw new DataSourceException("Missing WriteBackTable!");
		}
		
		StringBuilder sbfSelectForUpdate = new StringBuilder("SELECT * FROM ");
		sbfSelectForUpdate.append(pWriteBackTable);
		sbfSelectForUpdate.append(getWhereClause(pServerMetaData, pPKFilter, null, false));
		sbfSelectForUpdate.append(" FOR UPDATE");
		return sbfSelectForUpdate.toString();
	}
	
	/**
	 * Returns the newly inserted row from a Database specific insert statement. <br>
	 * Database specific derivations of DBAccess need to implement it database specific. 
	 * 
	 * @param pWriteBackTable	the table to use for the insert
	 * @param pInsertStatement	the SQL Statement to use for the insert
	 * @param pServerMetaData	the meta data to use.
	 * @param pNewDataRow		the new row (Object[]) with the values to insert
	 * @param pDummyColumn		<code>null</code>, if all writeable columns are null, but for a correct INSERT it have
	 *                          to be minimum one column to use in the syntax.
	 * @return the newly inserted row from an Oracle Database.
	 * @throws DataSourceException if an <code>Exception</code> occur during insert to the storage
	 */		
	protected Object[] insertDatabaseSpecific(String pWriteBackTable, String pInsertStatement, ServerMetaData pServerMetaData, 
                                              Object[] pNewDataRow, String pDummyColumn)  throws DataSourceException
    {
		return insertAnsiSQL(pWriteBackTable, pInsertStatement, pServerMetaData, pNewDataRow, pDummyColumn);
    }
	
	/**
	 * Returns if this Database specific supports generated keys. Because of Derby bug!
	 * @return if this Database specific supports generated keys.
	 */
	public boolean supportsGetGeneratedKeys()
	{
		try
		{
			return cConnection.getMetaData().supportsGetGeneratedKeys();
		}
		catch (SQLException sqlException)
		{
			return false;
		}
	}

	/**
	 * Returns the newly inserted row from a Ansi SQL Database. <br>
	 * It uses getGeneratedKeys to get the primary key values back from the database. Its recommend that
	 * the jdbc driver of the database support that clean.
	 * 
	 * @param pWriteBackTable	the table to use for the insert
	 * @param pInsertStatement	the SQL Statement to use for the insert
	 * @param pServerMetaData	the meta data to use.
	 * @param pNewDataRow		the new row (Object[]) with the values to insert
	 * @param pDummyColumn		true, if all writeable columns are null, but for a correct INSERT it have
	 *                          to be minimum one column to use in the syntax.
	 * @return the newly inserted row from a Ansi SQL Database.
	 * @throws DataSourceException
	 *             if an <code>Exception</code> occur during insert to the storage
	 */
	protected Object[] insertAnsiSQL(String pWriteBackTable, String pInsertStatement, ServerMetaData pServerMetaData, 
									Object[] pNewDataRow, String pDummyColumn)  throws DataSourceException
	{
		// insert DataRow to database
		boolean bSupportGeneratedKeys = supportsGetGeneratedKeys();

		PreparedStatement psInsert = getPreparedStatement(pInsertStatement, bSupportGeneratedKeys);
	    ResultSet rsPK = null;

		try
		{		
			ServerColumnMetaData[] cmdServerColumnMetaData = pServerMetaData.getServerColumnMetaData();
			int[] iaWriteables = pServerMetaData.getWritableColumnIndices();
			
			if (pDummyColumn == null)
			{
				setColumnsToStore(psInsert, cmdServerColumnMetaData, iaWriteables, pNewDataRow, null);
			}
			else
			{
				// set null value for it!
				try
				{
					for (int i = 0; i < cmdServerColumnMetaData.length; i++)
					{
						if (cmdServerColumnMetaData[i].getColumnName().getQuotedName().equals(pDummyColumn))
						{
							psInsert.setObject(1, null, cmdServerColumnMetaData[i].getSQLType());
							break;
						}
					}
				}
				catch (SQLException sqlException)
				{
					throw new DataSourceException("Insert failed! - " + pInsertStatement, formatSQLException(sqlException));
				}				
			}
			
			if (executeUpdate(psInsert) == 1)
			{
				if (bSupportGeneratedKeys)
				{
					// Return GeneratedKeys (typical used in PK)
					try 
					{
					    rsPK = psInsert.getGeneratedKeys();
					    if (rsPK.next()) 
					    {
						    String[] pPKColumns = pServerMetaData.getPrimaryKeyColumnNames();
					    	for (int i = 0, anz = rsPK.getMetaData().getColumnCount(); i < anz && pPKColumns != null && i < pPKColumns.length; i++)
					    	{
					    		int columnIndex = ServerMetaData.getServerColumnMetaDataIndex(cmdServerColumnMetaData, pPKColumns[i]);
					    		if (columnIndex >= 0)
					    		{
					    			// #440 - DBAccess.insert return null if no auto increment column in table 
									Object value = rsPK.getObject(i + 1);
									if (value != null)
									{
										pNewDataRow[columnIndex] = value;
									}
					    		}
					    	}
					    }
					}
					catch (SQLException sqlException)
					{
						throw new DataSourceException("The generated keys couldn't read! - " + pInsertStatement, formatSQLException(sqlException));
					}
				}
				return pNewDataRow;
			}
			throw new DataSourceException("Insert failed! - Result row count != 1" + pInsertStatement);
		}
		finally
		{
		    CommonUtil.close(rsPK, psInsert);
		}
	}
	
	/**
	 * Returns the meta data information for the specified query, and configures all columns with defaults.
	 * 
	 * @param pBeforeQueryColumns	the before query columns
	 * @param pQueryColumns			the query columns	
	 * @param pFromClause			the from clause with query tables and join definitions
	 * @param pWhereClause			the last where condition in query
	 * @param pAfterWhereClause		the after where clause in query
 	 * @return the meta data for the specified query, and initials all columns.
	 * @throws DataSourceException 
	 *            if an <code>Exception</code> occur during getting the meta data or 
	 *            if the storage is not opened or 
	 *            if one columns SQL type is not supported
	 */
	protected ServerColumnMetaData[] getColumnMetaDataIntern(String pFromClause, 
										     	String[] pQueryColumns,
										     	String pBeforeQueryColumns, 
										     	String pWhereClause, 
										     	String pAfterWhereClause) throws DataSourceException
	{		
		long lMillis = System.currentTimeMillis();
		
		if (pWhereClause == null)
		{
			pWhereClause = "1=2";
		}		
		else
		{
			pWhereClause += " AND 1=2";
		}

		PreparedStatement psQueryMetaData = null;
		ResultSet rsQueryMetaData = null;
		String sMetaDataQuery = getSelectStatement(null, pBeforeQueryColumns, pQueryColumns, pFromClause, 
                                                   null, pWhereClause, pAfterWhereClause, 
                                                   null, null);
			
		try
		{
			// get Columns
			psQueryMetaData = getPreparedStatement(sMetaDataQuery, false);
			rsQueryMetaData = psQueryMetaData.executeQuery();
			ResultSetMetaData rsMetaData = rsQueryMetaData.getMetaData();
			
			ArrayUtil<ServerColumnMetaData> auCmd = new ArrayUtil<ServerColumnMetaData>();
			ArrayUtil<String> auColumnNames = new ArrayUtil<String>();
			
			String sColName;
			
			// set every ColumnMetaData
			for (int i = 1; i <= rsMetaData.getColumnCount(); i++)
			{
				sColName = getColumnName(rsMetaData, i);
				
				Name nColumnName = new Name(sColName, quote(sColName));
				
				if (auColumnNames.indexOf(nColumnName.getName()) >= 0)
				{
					throw new DataSourceException("Duplicate definition of '" + nColumnName.getName() + 
							"' in DBStorage " + sMetaDataQuery + "!");
				}
				ServerColumnMetaData cd = new ServerColumnMetaData(nColumnName);
								
				//set real DB column name, which is specified from the developer to use for query, filter and sort (only Query side)
				if (pQueryColumns != null)
				{
					String sQueryColumn = pQueryColumns[i - 1].toLowerCase();
					String sName = cd.getName().toLowerCase();
					int iLen = sQueryColumn.length() - sName.length() - 1;
					
					if (sQueryColumn.endsWith(sName) 
					    && iLen > 0
						&& Character.isWhitespace(sQueryColumn.charAt(iLen)))
					{
						sQueryColumn = pQueryColumns[i - 1].substring(0, iLen).trim(); 
						iLen = sQueryColumn.length() - 3;
						
						if (sQueryColumn.endsWith("as") 
						    && iLen > 0
							&& Character.isWhitespace(sQueryColumn.charAt(iLen)))
						{
							sQueryColumn = pQueryColumns[i - 1].substring(0, iLen).trim(); 
						}
					}
					else
					{
						sQueryColumn = pQueryColumns[i - 1];
					}
					cd.setRealQueryColumnName(sQueryColumn);
					debug("Name=", cd.getName(), "==", sQueryColumn);
				}
				else
				{
					cd.setRealQueryColumnName(cd.getColumnName().getRealName());
				}
				
				if (rsMetaData.isNullable(i) == ResultSetMetaData.columnNoNulls)
				{
					cd.setNullable(false);
				}
				else
				{
					cd.setNullable(true);
				}
				// #544 - In databases with default lower case column names, the default labels in the RowDefinition are wrong 
				// setLabel removed!
				cd.setAutoIncrement(rsMetaData.isAutoIncrement(i));
				
				int iColumnType = rsMetaData.getColumnType(i);
				
				cd.setSQLType(iColumnType);
				cd.setSQLTypeName(rsMetaData.getColumnTypeName(i));

				if (!setDatabaseSpecificType(rsMetaData, i, cd))
				{
					switch(iColumnType)
					{
						case NCHAR:
						case NVARCHAR:
						case LONGNVARCHAR:
						case Types.CHAR:
		                case Types.VARCHAR:
		                case Types.LONGVARCHAR:
		                case Types.CLOB:
		                	cd.setDataType(StringDataType.TYPE_IDENTIFIER);
		                	if (rsMetaData.getPrecision(i) > 0)
		                	{
		                		cd.setPrecision(rsMetaData.getPrecision(i));
		                	}
		                	else
		                	{
		                		cd.setPrecision(Integer.MAX_VALUE);
		                	}
		                	break;
	
		                case Types.BIT:
						case Types.BOOLEAN:
		                	cd.setDataType(BooleanDataType.TYPE_IDENTIFIER);
		                	break;
		                	
		                case Types.FLOAT:
		                case Types.REAL:
		                case Types.DOUBLE:
		                	cd.setDataType(BigDecimalDataType.TYPE_IDENTIFIER);
		                	cd.setPrecision(0);
		                	cd.setScale(-1);
		                	cd.setSigned(rsMetaData.isSigned(i)); 
		                	break;
		                	
		                case Types.TINYINT:
		                case Types.SMALLINT:
		                case Types.INTEGER:
		                case Types.BIGINT:
		                case Types.NUMERIC:
		                case Types.DECIMAL:
		                	cd.setDataType(BigDecimalDataType.TYPE_IDENTIFIER);
		                	if (rsMetaData.getPrecision(i) <= 0 // none, use decimal without any precision and scale -> unlimited!
		                			|| rsMetaData.getPrecision(i) > 30) // over 30 , we use decimal without any precision and scale -> unlimited!
		                	{
			                	cd.setPrecision(0);
			                	cd.setScale(-1);
		                	}
		                	else
		                	{
			                	cd.setPrecision(rsMetaData.getPrecision(i));
			                	cd.setScale(rsMetaData.getScale(i));
		                	}
		                	cd.setSigned(rsMetaData.isSigned(i)); 
		                	break;
		                	
		                case Types.DATE:
		                case Types.TIME:
		                case Types.TIMESTAMP:
		                	cd.setDataType(TimestampDataType.TYPE_IDENTIFIER);
		                	break;
		                	
		                case Types.BLOB:
		                case Types.BINARY:
		                case Types.VARBINARY:
		                case Types.LONGVARBINARY:
		                	cd.setDataType(BinaryDataType.TYPE_IDENTIFIER);
		                	if (rsMetaData.getPrecision(i) > 0)
		                	{
		                		cd.setPrecision(rsMetaData.getPrecision(i));
		                	}
		                	else
		                	{
		                		cd.setPrecision(Integer.MAX_VALUE);
		                	}
		                	
		                	break;
		                	
		                default:
			    			throw new DataSourceException(cd.getName() + " :: SQL Type '" + iColumnType + "' is not support!");
					}
				}
				
				auCmd.add(cd);
				auColumnNames.add(cd.getName());
			}
			
            if (isLogEnabled(LogLevel.DEBUG))
            {
                debug("getMetaData(", sMetaDataQuery, ") in ", Long.valueOf(System.currentTimeMillis() - lMillis), "ms");
            }
			
			return auCmd.toArray(new ServerColumnMetaData[auCmd.size()]);
		}
		catch (SQLException sqlException)
		{    		
			throw new DataSourceException("Meta data couldn't load from database! - " + 
										  sMetaDataQuery, formatSQLException(sqlException));
		}
		finally
		{
		    CommonUtil.close(rsQueryMetaData, psQueryMetaData);
		}
	}

	/**
	 * Returns the meta data information for the specified query, and configures all columns with defaults.
	 * 
	 * @param pBeforeQueryColumns	the before query columns
	 * @param pQueryColumns			the query columns	
	 * @param pFromClause			the from clause with query tables and join definitions
	 * @param pWhereClause			the last where condition in query
	 * @param pAfterWhereClause		the after where clause in query
 	 * @return the meta data for the specified query, and initials all columns.
	 * @throws DataSourceException 
	 *            if an <code>Exception</code> occur during getting the meta data or 
	 *            if the storage is not opened or 
	 *            if one columns SQL type is not supported
	 */
	public final ServerColumnMetaData[] getColumnMetaData(String pFromClause, 
										     	String[] pQueryColumns,
										     	String pBeforeQueryColumns, 
										     	String pWhereClause, 
										     	String pAfterWhereClause) throws DataSourceException
	{
		
		if (isMetaDataCacheEnabled())
		{
			String dbAccessIdentifier = getIdentifier();
			String tableIdentifier = createIdentifier(pFromClause, pQueryColumns, pBeforeQueryColumns);
			
			ServerColumnMetaData[] metaData = ghtColumnMetaDataCache.get(dbAccessIdentifier, tableIdentifier);
			if (metaData == null)
			{
				metaData = getColumnMetaDataIntern(pFromClause, pQueryColumns, pBeforeQueryColumns, pWhereClause, pAfterWhereClause);
				
				if (metaData == null)
				{
					metaData = COLUMNMETADATA_NULL;
				}
				
				ghtColumnMetaDataCache.put(dbAccessIdentifier, tableIdentifier, metaData);
			}
			
			if (metaData == COLUMNMETADATA_NULL)
			{
				return null;
			}
			else
			{
				ServerColumnMetaData[] result = new ServerColumnMetaData[metaData.length];
				
				for (int i = 0; i < metaData.length; i++)
				{
					result[i] = metaData[i].clone();
				}
				
				return result;
			}
		}
		else
		{
			return getColumnMetaDataIntern(pFromClause, pQueryColumns, pBeforeQueryColumns, pWhereClause, pAfterWhereClause);
		}
	}
	
	/**
	 * Returns the meta data information for the specified query, and configures all columns with defaults.
	 * 
	 * @param pWriteBackTable		the write back table to use for the isWriteable() state (Optional)
 	 * @return the meta data for the specified query, and initials all columns.
	 * @throws DataSourceException 
	 *            if an <code>Exception</code> occur during getting the meta data or 
	 *            if the storage is not opened or 
	 *            if one columns SQL type is not supported
	 */
	protected TableInfo getTableInfoIntern(String pWriteBackTable) throws DataSourceException
	{
		long lMillis = System.currentTimeMillis();
		
		PreparedStatement psQueryMetaData = null;
		ResultSet rsQueryMetaData = null;
		String sMetaDataQuery = getSelectStatement(null, null, null, pWriteBackTable, 
												   null, "1=2", null, 
                                                   null, null);			
		try
		{
			// get Columns
			psQueryMetaData = getPreparedStatement(sMetaDataQuery, false);
			rsQueryMetaData = psQueryMetaData.executeQuery();
			ResultSetMetaData rsMetaData = rsQueryMetaData.getMetaData();
			
			String sCatalog = rsMetaData.getCatalogName(1);
			String sSchema  = rsMetaData.getSchemaName(1);
			
			// #136 - Mysql PK refetch not working -> extract the given table without schema. 
//			String sTable = rsMetaData.getTableName(1); // Table name is alias, if alias is set

			if (sCatalog != null && sCatalog.trim().length() == 0)
			{
				sCatalog = sCatalog.trim();
				
				if (sCatalog.length() == 0)
				{
					sCatalog = null;
				}
			}
			
			if (sSchema != null)
			{
				sSchema = sSchema.trim();
				
				if (sSchema.length() == 0)
				{
					sSchema = null;
				}
			}
			
			String[] sSchemaTable = splitSchemaTable(pWriteBackTable);
			
			if (sSchema == null)
			{
				sSchema = sSchemaTable[0];
			}
			
			String sTable = sSchemaTable[1];
			
			if (sTable != null)
			{
				if (sTable.endsWith(" m "))
				{
					sTable = sTable.substring(0, sTable.length() - 3);
				}
				sTable = sTable.trim();
			}
			
            if (isLogEnabled(LogLevel.DEBUG))
            {
                debug("getTableInfo(", sMetaDataQuery, ") in ", Long.valueOf(System.currentTimeMillis() - lMillis), "ms");
            }
			
			return new TableInfo(sCatalog, sSchema, sTable);
		}
		catch (SQLException sqlException)
		{    		
			throw new DataSourceException("Meta data couldn't load from database! - " + 
										  sMetaDataQuery, formatSQLException(sqlException));
		}
		finally
		{
		    CommonUtil.close(rsQueryMetaData, psQueryMetaData);
		}
	}

	/**
	 * Returns the meta data information for the specified query, and configures all columns with defaults.
	 * 
	 * @param pWriteBackTable		the write back table to use for the isWriteable() state (Optional)
 	 * @return the meta data for the specified query, and initials all columns.
	 * @throws DataSourceException 
	 *            if an <code>Exception</code> occur during getting the meta data or 
	 *            if the storage is not opened or 
	 *            if one columns SQL type is not supported
	 */
	public final TableInfo getTableInfo(String pWriteBackTable) throws DataSourceException
	{
		if (isMetaDataCacheEnabled())
		{
			String dbAccessIdentifier = getIdentifier();
			String tableIdentifier = createIdentifier(pWriteBackTable);
			
			TableInfo tableInfo = ghtTableInfoCache.get(dbAccessIdentifier, tableIdentifier);
			if (tableInfo == null)
			{
				tableInfo = getTableInfoIntern(pWriteBackTable);
				
				if (tableInfo == null)
				{
					tableInfo = TABLEINFO_NULL;
				}
				
				ghtTableInfoCache.put(dbAccessIdentifier, tableIdentifier, tableInfo);
			}
			
			if (tableInfo == TABLEINFO_NULL)
			{
				return null;
			}
			else
			{
				return tableInfo;
			}
		}
		else
		{
			return getTableInfoIntern(pWriteBackTable);
		}
	}
	
	/**
	 * Sets all <code>Filter</code> parameter values into the <code>PreparedStatement</code>.
	 * 
	 * @param iStartParameterIndex 
	 *            the start index for the parameters to set.
	 * @param pStatement 
	 * 			  the <code>PreparedStatement</code> to initialize
	 * @param pParameter 
	 *            the <code>Filter</code> to get the values
	 * @throws DataSourceException     
	 *            if the values can't set into the <code>PreparedStatement</code>     
	 */
	private void setFilterParameter(int iStartParameterIndex, PreparedStatement pStatement, Object[] pParameter) throws DataSourceException
	{				
		int j = 0;
		for (int i = 0; i < pParameter.length; i++)
		{
			try
			{
				if (pParameter[i] != null)
				{
					pStatement.setObject(iStartParameterIndex + j, convertValueToDatabaseSpecificObject(pParameter[i]));
					
					j++;
				}
			}
			catch (SQLException sqlException)
			{
				throw new DataSourceException("Set value into PreparedStatement failed!",
											  formatSQLException(sqlException));
			}			
		}
	}
	
	/**
	 * Sets the values of all changed columns to store from the value Object[]s into the 
	 * <code>PreparedStatement</code> and returns the last used parameter index.
	 * 
	 * @param pInsert 		  		the <code>PreparedStatement</code> to initialize
	 * @param pServerColumnMetaData	the column meta data to use.
	 * @param iaWriteables			the writable columns as int index array
	 * @param pNew             		the new values Object[]
	 * @param pOld  	        	the old values Object[]
	 * @throws DataSourceException	if the values can't set into the <code>PreparedStatement</code>     
	 * @return the last used parameter index of the <code>PreparedStatement</code>.           
	 */
	protected int setColumnsToStore(PreparedStatement pInsert, ServerColumnMetaData[] pServerColumnMetaData, 
			                        int[] iaWriteables, Object[] pNew, Object[] pOld) throws DataSourceException
	{
		int i = 1;
		for (int j = 0; j < iaWriteables.length; j++)
		{
			int k = iaWriteables[j];
	        if (pOld == null && pNew[k] != null
	        	|| pOld != null 
	        	   && pServerColumnMetaData[k].getDataType().compareTo(pNew[k], pOld[k]) != 0)
	        {
				try
				{
					if (pNew[k] == null)
					{
						pInsert.setNull(i, pServerColumnMetaData[k].getSQLType());
					}
					else
					{
						Object object = convertValueToDatabaseSpecificObject(pNew[k]);
						
						if (object instanceof IFileHandle)
						{
							IFileHandle fileHandle = (IFileHandle)object;
							
							pInsert.setBinaryStream(i, fileHandle.getInputStream(), (int)fileHandle.getLength());
						}
						else
						{
							pInsert.setObject(i, convertValueToDatabaseSpecificObject(pNew[k]));
						}
					}
					i++;
				}
				catch (Exception sqlException)
				{
					if (sqlException instanceof SQLException)
					{
						sqlException = formatSQLException((SQLException)sqlException);
					}
					throw new DataSourceException("Set value into PreparedStatement failed!", sqlException);
				}
			}
		}	
		return --i;
	}

	/**
	 * Gets all default column values of a specific table.
	 *  
	 * @param pCatalog the catalog name
	 * @param pSchema the schema name
	 * @param pTable the table name
	 * @return a {@link Hashtable} with the column name as key and the default value as value. It only contains columns
	 *         with a default value
	 * @throws DataSourceException if the database access throws an exception
	 */
	public final Map<String, Object> getDefaultValues(String pCatalog, String pSchema, String pTable) throws DataSourceException
	{
		if (isMetaDataCacheEnabled())
		{
			String dbAccessIdentifier = getIdentifier();
			String tableIdentifier = createIdentifier(pCatalog, pSchema, pTable);
			
			Map<String, Object> defaultValues = ghtDefaultValuesCache.get(dbAccessIdentifier, tableIdentifier);
			if (defaultValues == null)
			{
				defaultValues = getDefaultValuesIntern(pCatalog, pSchema, pTable);
				
				if (defaultValues == null)
				{
					defaultValues = DEFAULT_VALUES_NULL;
				}
				ghtDefaultValuesCache.put(dbAccessIdentifier, tableIdentifier, defaultValues);
			}
			
			if (defaultValues == DEFAULT_VALUES_NULL)
			{
				return null;
			}
			else
			{
				return defaultValues;
			}
		}
		else
		{
			return getDefaultValuesIntern(pCatalog, pSchema, pTable);
		}
	}
	
	/**
	 * Gets all default column values of a specific table.
	 *  
	 * @param pCatalog the catalog name
	 * @param pSchema the schema name
	 * @param pTable the table name
	 * @return a {@link Hashtable} with the column name as key and the default value as value. It only contains columns
	 *         with a default value
	 * @throws DataSourceException if the database access throws an exception
	 */
	protected Map<String, Object> getDefaultValuesIntern(String pCatalog, String pSchema, String pTable) throws DataSourceException
	{
		Map<String, Object> htDefaults = new Hashtable<String, Object>();

		ResultSet res = null;
		
		try
		{
			res = cConnection.getMetaData().getColumns(pCatalog, pSchema, pTable, null);
			
			Object objValue;
			
			String sValue;
			String sColumnName;
			
			while (res.next())
			{
				sValue = res.getString("COLUMN_DEF");

				if (sValue != null)
				{
					sColumnName = res.getString("COLUMN_NAME");
					
					try
					{
						objValue = translateDefaultValue(sColumnName, res.getInt("DATA_TYPE"), sValue.trim());

						if (objValue != null)
						{
							htDefaults.put(sColumnName, objValue);
						}
					}
					catch (Exception e)
					{
						//no default value
						debug(sValue, e);
					}
				}
			}
			
			return htDefaults;
		}
		catch (SQLException sqlException)
		{
			throw new DataSourceException("Get default values failed!", formatSQLException(sqlException));
		}
		finally
		{
		    CommonUtil.close(res);
		}
	}
	
	/**
	 * Translates a default value from a column to the datatype object.
	 * 
	 * @param pColumnName the column name to translate
	 * @param pDataType the datatype of the column
	 * @param pDefaultValue the original default value from the database
	 * @return the default value with the datatype of the column or <code>null</code> if the default value is not valid
	 * @throws Exception if the type translation causes an error or the datatype is not supported
	 */
	protected Object translateDefaultValue(String pColumnName, int pDataType, String pDefaultValue) throws Exception
	{
		return translateValue(pDataType, pDefaultValue);
	}
	
	/**
	 * Translates an object value to the datatype object.
	 * 
	 * @param pDataType the datatype of the column
	 * @param pValue the value from the database
	 * @return the value with the specified datatype or <code>null</code> if the value is not valid
	 * @throws Exception if the type translation causes an error or the datatype is not supported
	 */
	protected Object translateValue(int pDataType, String pValue) throws Exception
	{
		if (pValue == null || pValue.equalsIgnoreCase("null"))
		{
			return null;
		}
		
		switch(pDataType)
		{
			case NCHAR:
			case NVARCHAR:
			case LONGNVARCHAR:
			case Types.CHAR:
            case Types.VARCHAR:
            case Types.LONGVARCHAR:
            case Types.CLOB:
            	return pValue;

            case Types.BIT:
			case Types.BOOLEAN:
				return Boolean.valueOf(pValue);
            	
            case Types.FLOAT:
            case Types.REAL:
            case Types.DOUBLE:
            case Types.TINYINT:
            case Types.SMALLINT:
            case Types.INTEGER:
            case Types.BIGINT:
            case Types.NUMERIC:
            case Types.DECIMAL:

            	return new BigDecimal(pValue);
            	
            case Types.DATE:
            case Types.TIME:
            case Types.TIMESTAMP:
            	
            	if (pValue.startsWith("0000-00-00"))
            	{
            		return null;
            	}
            	
            	return new Timestamp(((Date)dateUtil.parse(pValue)).getTime());
            	
            case Types.BLOB:
            case Types.BINARY:
            case Types.VARBINARY:
            case Types.LONGVARBINARY:
            	return null;
            	
            default:
    			throw new DataSourceException("SQL Type '" + pDataType + "' is not support!");
		}
	}
	
	/**
	 * Gets the allowed values from a specific table. The allowed values are defined through check constraints
	 * or other table related restrictions.
	 * 
	 * @param pCatalog the catalog name
	 * @param pSchema the schema name
	 * @param pTable the table to check
	 * @return a {@link Hashtable} with a column name as key and the allowed values as array of {@link Object}s or 
	 *         <code>null</code> if there are no allowed values
	 * @throws DataSourceException if the database access throws an exception          
	 */
	protected Map<String, Object[]> getAllowedValuesIntern(String pCatalog, String pSchema, String pTable) throws DataSourceException
	{
		return null;
	}
	
	/**
	 * Gets the allowed values from a specific table. The allowed values are defined through check constraints
	 * or other table related restrictions.
	 * 
	 * @param pCatalog the catalog name
	 * @param pSchema the schema name
	 * @param pTable the table to check
	 * @return a {@link Hashtable} with a column name as key and the allowed values as array of {@link Object}s or 
	 *         <code>null</code> if there are no allowed values
	 * @throws DataSourceException if the database access throws an exception          
	 */
	public final Map<String, Object[]> getAllowedValues(String pCatalog, String pSchema, String pTable) throws DataSourceException
	{
		if (isMetaDataCacheEnabled())
		{
			String dbAccessIdentifier = getIdentifier();
			String tableIdentifier = createIdentifier(pCatalog, pSchema, pTable);
			
			Map<String, Object[]> allowedValues = ghtAllowedValuesCache.get(dbAccessIdentifier, tableIdentifier);
			if (allowedValues == null)
			{
				allowedValues = getAllowedValuesIntern(pCatalog, pSchema, pTable);
				
				if (allowedValues == null)
				{
					allowedValues = ALLOWED_VALUES_NULL;
				}
				ghtAllowedValuesCache.put(dbAccessIdentifier, tableIdentifier, allowedValues);
			}
			
			if (allowedValues == ALLOWED_VALUES_NULL)
			{
				return null;
			}
			else
			{
				return allowedValues;
			}
		}
		else
		{
			return getAllowedValuesIntern(pCatalog, pSchema, pTable);
		}
	}
	
	/**
	 * Gets the default allowed values for a given column from a given table. This method will be called if no other 
	 * default values for the given column are available.
	 * 
	 * @param pCatalog the catalog name
	 * @param pSchema the schema name
	 * @param pTable the table to check
	 * @param pMetaData the column meta data
	 * @return the default allowed values or <code>null</code> if there are no default values
	 */
	public Object[] getDefaultAllowedValues(String pCatalog, String pSchema, String pTable, ServerColumnMetaData pMetaData)
	{
		if (pMetaData.getDataType().getTypeIdentifier() == BooleanDataType.TYPE_IDENTIFIER)
		{
			return new Boolean[] {Boolean.TRUE, Boolean.FALSE};
		}
		
		return null;
	}
	
	/**
	 * Returns the database specific statement to lock the specified row in the database.
	 *  
	 * @param pSelectStatement	the select statement to execute.
	 * @param pPKFilter			the PK filter with the values to use.
	 * @param pMaxRows          the maximum number of allowed rows. A negative number means no limit. 
	 * @return the number of affected rows
	 * @throws DataSourceException if some parts are missing for the statement
	 */
	private int getRowCount(String pSelectStatement, ICondition pPKFilter, int pMaxRows) throws DataSourceException
	{
		long lMillis = System.currentTimeMillis();
		
		// update DataRow into database
		PreparedStatement psSelect = getPreparedStatement(pSelectStatement.toString(), false);
		ResultSet res = null;

		try
		{
			// set WHERE Parameter with Values from PK of the new DataRow
			setFilterParameter(1, psSelect, getParameter(pPKFilter));
	
			res = psSelect.executeQuery();
				
            if (isLogEnabled(LogLevel.DEBUG))
            {
                debug("select (", pSelectStatement, ",...) in ", Long.valueOf(System.currentTimeMillis() - lMillis), "ms");
            }
            
			int iCount = 0;
			
			while (res.next())
			{
				iCount++;
				
				if (pMaxRows >= 0 && iCount > pMaxRows)
				{
					throw new DataSourceException("Too many rows found! " + pSelectStatement);
				}
			}
			
			// if iCount == 0, do nothing!!!
			
			return iCount;
		}
		catch (SQLException se)
		{
			throw new DataSourceException("Execute statement failed! " + pSelectStatement, formatSQLException(se));
		}
		finally
		{
		    CommonUtil.close(res, psSelect);
		}
	}
	
	/**
	 * Returns the ANSI SQL String for this <code>ICondition</code>.
	 * 
	 * @param pServerMetaData		the MetaDataColumn array to use.
	 * @param pCondition			the Condition to use.
	 * @param pUseRealColumnName	<code>true</code> to use the prefixed column (real column name) and <code>false</code> to
	 *                      		ignore prefixes (the simple name of the column)
	 * @throws DataSourceException if columns not existing
	 * @return the ANSI SQL String for this <code>ICondition</code>.
	 */
	protected String getSQL(ServerMetaData pServerMetaData, ICondition pCondition, boolean pUseRealColumnName) throws DataSourceException
	{
		StringBuilder result = new StringBuilder();
		
		if (pCondition instanceof CompareCondition)
		{
			CompareCondition cCompare = (CompareCondition)pCondition;
			Object           oValue   = cCompare.getValue();
			
			if (!cCompare.isIgnoreNull() || oValue != null)
			{
				String sColumnName = null;
				if (pServerMetaData != null)
				{
					try
					{
						if (pUseRealColumnName)
						{
							sColumnName = pServerMetaData.getServerColumnMetaData(cCompare.getColumnName()).getRealQueryColumnName();
						}
						else
						{
							sColumnName = pServerMetaData.getServerColumnMetaData(cCompare.getColumnName()).getColumnName().getQuotedName();
						}
					}
					catch (ModelException modelException)
					{
						// Column doesn't exit in MetaData, then use the column name of the Condition itself.
					}
				}
				if (sColumnName == null)
				{
					sColumnName = cCompare.getColumnName();
				}
				
				if ((cCompare instanceof LikeReverse || cCompare instanceof LikeReverseIgnoreCase)
					&& cCompare.getValue() != null)
				{
					if (cCompare instanceof LikeReverse)
					{
						result.append(createWhereParam(pServerMetaData, cCompare));
					}
					else if (cCompare instanceof LikeReverseIgnoreCase)
					{
						result.append("UPPER(");
						result.append(createWhereParam(pServerMetaData, cCompare));
						result.append(")");
					}						
				}
				else if (cCompare instanceof LikeIgnoreCase)
				{
					result.append("UPPER(");
					result.append(createWhereColumn(pServerMetaData, cCompare, sColumnName));
					result.append(")");
				}						
				else 
				{
					result.append(createWhereColumn(pServerMetaData, cCompare, sColumnName));
				}						
				
				result.append(' ');
				
				if (cCompare.getValue() == null)
				{
					result.append("IS NULL");
				}
				else
				{
					if (cCompare instanceof Equals)
					{
						result.append("= ");
					}
					else if (cCompare instanceof LikeIgnoreCase || cCompare instanceof LikeReverseIgnoreCase)
					{
						result.append("LIKE UPPER(");
					}
					else if (cCompare instanceof Like
							|| cCompare instanceof LikeReverse)
					{
						result.append("LIKE ");
					}
					else if (cCompare instanceof Greater)
					{
						result.append("> ");
					}
					else if (cCompare instanceof GreaterEquals)
					{
						result.append(">= ");
					}
					else if (cCompare instanceof Less)
					{
						result.append("< ");
					}
					else if (cCompare instanceof LessEquals)
					{
						result.append("<= ");
					}
					else
					{
						result.append(' ');
					}

					if (cCompare instanceof LikeReverse || cCompare instanceof LikeReverseIgnoreCase)
					{
						result.append(createReplace(createReplace(createWhereColumn(pServerMetaData, cCompare, sColumnName), "*", "%"), "?", "_"));
					}
					else
					{
						result.append(createWhereParam(pServerMetaData, cCompare));
					}
					
					if (cCompare instanceof LikeIgnoreCase || cCompare instanceof LikeReverseIgnoreCase)
					{
						result.append(")");
					}
				}
			}
		}
		else if (pCondition instanceof OperatorCondition)
		{
			OperatorCondition cOperator = (OperatorCondition) pCondition;
			
			ICondition[] caConditions = cOperator.getConditions();
			for (int i = 0; i < caConditions.length; i++)
			{
				String sTempSQL = getSQL(pServerMetaData, caConditions[i], pUseRealColumnName);
				
				if (sTempSQL != null && sTempSQL.length() > 0)
				{
					if (i > 0 && result.length() > 0)
					{
						if (cOperator instanceof And)
						{
							result.append(" AND ");
						}
						else if (cOperator instanceof Or)
						{
							result.append(" OR ");
						}
					}
					if (caConditions[i] instanceof OperatorCondition)
					{
						result.append("(");
						result.append(sTempSQL);
						result.append(")");
					}
					else
					{
						result.append(sTempSQL);
					}
				}
			}
		}
		else if (pCondition instanceof Not)
		{
			ICondition cCond = ((Not) pCondition).getCondition();
			String sTempSQL = getSQL(pServerMetaData, cCond, pUseRealColumnName);
			
			result.append("NOT ");
			if (cCond instanceof OperatorCondition)
			{
				result.append("(");
				result.append(sTempSQL);
				result.append(")");
			}
			else
			{
				result.append(sTempSQL);
			}
		}
		
		return result.toString();
	}

	/**
	 * Create an DB specific replace command, which replacs in the pSource all pOld to pNew.
	 * This implementation use the ANSI SQL REPLACE command.
	 *  
	 * @param pSource	the source to replace.
	 * @param pOld		the old value.
	 * @param pNew		the new value.
	 * 
	 * @return	the SQL command to to this.
	 */
	protected String createReplace(String pSource, String pOld, String pNew) 
	{
		StringBuilder sb = new StringBuilder("REPLACE(");
		sb.append(pSource);
		sb.append(",\'");
		sb.append(pOld);
		sb.append("\',\'");
		sb.append(pNew);
		sb.append("\')");
		return sb.toString();
	}
	
	/**
	 * Creates the where parameter. That is normally a single question mark, but it depends on
	 * the database if conversions are needed.
	 * 
	 * @param pServerMetaData 	the server metadata
	 * @param pCompare 			the compare condition
	 * @return the parameter representation for where clause
	 */
	protected String createWhereParam(ServerMetaData pServerMetaData, CompareCondition pCompare)
	{
		return "?";
	}

	/**
	 * Creates the where column. That is normally just the column name, but it depends on
	 * the database if conversions are needed.
	 * 
	 * @param pServerMetaData 	the server metadata
	 * @param pCompare 			the compare condition
	 * @param pColumnName		the column name to use
	 * @return the column name representation for where clause
	 */
	protected String createWhereColumn(ServerMetaData pServerMetaData, CompareCondition pCompare, String pColumnName)
	{
		return pColumnName;
	}
	
	
	/**
	 * Check if the Type of the column and the value to compare is equal.
	 *  
	 * @param pServerColumnMetaData		the server column meta data for the column to compare. 
	 * @param pCompare					the compare condition to use.
	 * @return false if the type isn't equal.
	 */
	public boolean isTypeEqual(ServerColumnMetaData pServerColumnMetaData, CompareCondition pCompare)
	{
		if (pCompare instanceof Equals)
		{
			// check if type is !=
			Object    oValue   = pCompare.getValue();
			IDataType dataType = pServerColumnMetaData.getDataType();
			if (oValue instanceof String && !(dataType instanceof StringDataType)
					|| oValue instanceof Timestamp && !(dataType instanceof TimestampDataType)
					|| oValue instanceof BigDecimal && !(dataType instanceof BigDecimalDataType)
					|| oValue instanceof Boolean && !(dataType instanceof BooleanDataType))
			{
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Returns the parameters used for this <code>ICondition</code>.
	 * 
	 * @param cCondition		the Condition to use.
	 * @return the parameters used for this <code>ICondition</code>.
	 */
	protected Object[] getParameter(ICondition cCondition)
	{
		Object[] oaParameter = null;
		
		if (cCondition instanceof CompareCondition)
		{
			CompareCondition cCompare = (CompareCondition)cCondition;
			Object           oValue   = cCompare.getValue();
	
			if (oValue != null)
			{
				if ((cCompare instanceof Like || cCompare instanceof LikeIgnoreCase)
					&& oValue instanceof String)
				{
					oaParameter = new Object[] { ((String)oValue).replace('*', '%').replace('?', '_') };
				}						
				else 
				{
					oaParameter = new Object[] { oValue };
				}
			}
			else
			{
				oaParameter = new Object[0];
			}
		}
		else if (cCondition instanceof OperatorCondition)
		{
			OperatorCondition cOperator = (OperatorCondition)cCondition;
			
			ICondition[] caConditions = cOperator.getConditions();
			for (int i = 0; i < caConditions.length; i++)
			{
				Object[] params = getParameter(caConditions[i]);
				if (oaParameter == null)
				{
					oaParameter = new Object[0];
				}
				oaParameter = ArrayUtil.addAll(oaParameter, params);
			}
		}
		else if (cCondition instanceof Not)
		{
			oaParameter = getParameter(((Not)cCondition).getCondition());
		}
		return oaParameter; 
	}
	
	/**
	 * Separates the schema and table from the given from clause. The separation is only 
	 * possible if the from clause is simple, e.g. it does not contain any quote characters
	 * and does not contain separators (',').
	 * 
	 * @param pFromClause the from clause
	 * @return [0]...schema, [1]...table
	 */
	protected String[] splitSchemaTable(String pFromClause)
	{
		boolean bComplex = false;
		
		//check if the from clause was special (means more than a view or table)
		if (pFromClause.indexOf(',') >= 0)
		{
			bComplex = true;
		}
		
		if (pFromClause.indexOf(sOpenQuote) >= 0)
		{
			bComplex = true;
		}
		
		int iFirstSpacePos = pFromClause.indexOf(' ');
		
		if (iFirstSpacePos > 0)
		{
			int iNextSpacePos = pFromClause.indexOf(' ', iFirstSpacePos + 1);
			
			if (iNextSpacePos > iFirstSpacePos)
			{
				bComplex = true;
			}
		}
		
		String[] sResult = new String[2];
		
		if (!bComplex)
		{
			//[schema.]table[ alias]

			if (iFirstSpacePos < 0)
			{
				iFirstSpacePos = pFromClause.length();
			}

			int iDotPos = pFromClause.indexOf('.');
			
			if (iDotPos > 0)
			{
				sResult[0] = pFromClause.substring(0, iDotPos);
				sResult[1] = pFromClause.substring(iDotPos + 1, iFirstSpacePos);
			}
			else
			{
				sResult[1] = pFromClause.substring(0, iFirstSpacePos);
			}
		}
		else
		{
			sResult[1] = pFromClause;
		}
		
		return sResult;
	}
	
	/**
	 * Sets the user-defined default schema.
	 * 
	 * @param pSchema the schema name
	 * @see #getDefaultSchema()
	 */
	public void setDefaultSchema(String pSchema)
	{
		sDefaultSchema = pSchema;
	}
	
	/**
	 * Gets the default schema name, if it was set manually.
	 * 
	 * @return the user-defined default schema name
	 * @see #setDefaultSchema(String)
	 */
	public String getDefaultSchema()
	{
		return sDefaultSchema;
	}
	
	/**
	 * Enables the database specific implementation to handle/convert special objects. Some databases have
	 * datatypes that are not defined in the standard. This datatypes have specific classes in the JDBC drivers.
	 * With this method it is possible to convert the values of specific JDBC driver classes into usable objects.
	 * We can not send any JDBC object to the client!
	 * 
	 * @param pColumnMetaData the column metadata
	 * @param pObject the read object
	 * @return the value to use
	 * @throws SQLException if it fails.
	 */
	protected Object convertDatabaseSpecificObjectToValue(ServerColumnMetaData pColumnMetaData, Object pObject) throws SQLException
	{
		return pObject;
	}
	
	/**
	 * Converts an object to a standard value for the specific database. Not all values are supported from
	 * the underlying database, e.g. java.sql.Timestamp is preferred instead of java.util.Date.
	 *  
	 * @param pValue any value
	 * @return the database specific value
	 */
	protected Object convertValueToDatabaseSpecificObject(Object pValue)
	{
		if (pValue instanceof Date && !(pValue instanceof Timestamp))
		{
			return new Timestamp(((Date)pValue).getTime());
		}
		else
		{
			return pValue;
		}
	}
	
	/**
	 * Gets the identifier for this DBAccess.
	 * @return the identifier for this DBAccess.
	 */
	protected String getIdentifier()
	{
		if (sIdentifier == null)
		{
			sIdentifier = createIdentifier(sUrl, sUsername);
		}

		kvlApplicationGroups.put(sApplicationName, sIdentifier, true);
		
		return sIdentifier;
	}
	
	/**
	 * Clears the meta data cache.
	 */
	public static void clearMetaData()
	{
		AbstractCachedStorage.clearMetaData();
		
		kvlApplicationGroups.clear();
		ghtFKsCache.clear();
		ghtPKCache.clear();
		ghtUKsCache.clear();
		ghtAllowedValuesCache.clear();
		ghtColumnMetaDataCache.clear();
		ghtTableInfoCache.clear();
	}
	
	/**
	 * Clears the meta data cache for the given application.
	 * 
	 * @param pApplicationName the application name
	 */
	public static void clearMetaData(String pApplicationName)
	{
		if (pApplicationName == null)
		{
			pApplicationName = "";
		}
		AbstractCachedStorage.clearMetaData(pApplicationName);
		
		List<String> liIdentifier = kvlApplicationGroups.remove(pApplicationName);
		
		if (liIdentifier != null)
		{
			for (String sIdentifier : liIdentifier)
			{
				ghtFKsCache.remove(sIdentifier);
				ghtPKCache.remove(sIdentifier);
				ghtUKsCache.remove(sIdentifier);
				ghtAllowedValuesCache.remove(sIdentifier);
				ghtColumnMetaDataCache.remove(sIdentifier);
				ghtTableInfoCache.remove(sIdentifier);
			}
		}
	}
	

	/**
	 * Creates an identifier string from the given parameter.
	 * @param pIdentifier the identifier
	 * @return the identifier string
	 */
	public static String createIdentifier(Object... pIdentifier)
	{
		if (pIdentifier == null || pIdentifier.length == 0)
		{
			return "/";
		}
		else
		{
			StringBuilder identString = new StringBuilder(512);
			
			for (int i = 0; i < pIdentifier.length; i++)
			{
				identString.append('/');
				
				Object identifier = pIdentifier[i];
				if (identifier != null)
				{
					if (identifier instanceof Object[])
					{
						Object[] oaIdentifiers = (Object[])identifier;
						
						for (int j = 0; j < oaIdentifiers.length; j++)
	                    {
							if (j > 0)
							{
								identString.append(";");
							}
	                       
							identifier = oaIdentifiers[j];
							if (identifier != null)
							{
								identString.append(identifier);
							}
	                    }
	                }
					else
					{
						identString.append(identifier);
					}
				}
			}
			
			return identString.toString();
		}
	}
	
	/**
	 * Enables the database specific implementation to change the metadata before the default settings are made.
	 * 
	 * @param pMetaData the metadata from the resultset
	 * @param pColumnIndex the column index in the resultset metadata
	 * @param pColumnMetaData the newly created and pre-configured column metadata
	 * @return <code>true</code> if column metadata are changed and the default settings should not be applied, 
	 *         <code>false</code> to apply the standard settings
	 * @throws SQLException if metadata access fails
	 */
	protected boolean setDatabaseSpecificType(ResultSetMetaData pMetaData, int pColumnIndex, ServerColumnMetaData pColumnMetaData) throws SQLException
	{
		return false;
	}

	/**
	 * Sets the metadata cache option for this instance. If a session cache option is set, the
	 * instance cache option overrules the session setting.
	 * 
	 * @param pOption the metadata cache option 
	 * @see #isMetaDataCacheEnabled()
	 */
	public void setMetaDataCacheOption(MetaDataCacheOption pOption)
	{
		if (pOption == null)
		{
			mdcCacheOption = MetaDataCacheOption.Default;
		}
		else
		{
			mdcCacheOption = pOption;
		}
	}
	
	/**
	 * Gets the metadata cache option for this instance.
	 * 
	 * @return the metadata cache option
	 * @see #setMetaDataCacheOption(MetaDataCacheOption)
	 */
	public MetaDataCacheOption getMetaDataCacheOption()
	{
		return mdcCacheOption;
	}


	/**
	 * Gets whether the meta data cache should be used.
	 * 
	 * @return whether the meta data cache should be used.
	 */
	protected boolean isMetaDataCacheEnabled()
	{
		//switch from Cache-ON to Cache-OFF -> clear cache
		if (lastGlobalMetaDataCache && !DBStorage.isGlobalMetaDataCacheEnabled())
		{
			clearMetaData();
		}
		lastGlobalMetaDataCache = DBStorage.isGlobalMetaDataCacheEnabled();

		MetaDataCacheOption option;
		
		//instance option overrules session option!
		
		if (mdcCacheOption != MetaDataCacheOption.Default)
		{
			option = mdcCacheOption;
		}
		else
		{
			//get the cache option from the session
			ISession sess = SessionContext.getCurrentSession();
			
			if (sess != null)
			{
				Object oOption = (String)sess.getProperty(IConnectionConstants.METADATA_CACHEOPTION);
				
				if (oOption == null)
				{
					option = MetaDataCacheOption.Default;
				}
				else
				{
					option = MetaDataCacheOption.resolve((String)oOption);
				}
			}
			else
			{
				option = MetaDataCacheOption.Default;
			}
		}
		
		return option == MetaDataCacheOption.On || (DBStorage.isGlobalMetaDataCacheEnabled() && option == MetaDataCacheOption.Default);		
	}

	/**
	 * Sets modified state of the connection. The connection should be set modified if insert/update or delete was executed.
	 * If the database connection is in auto-commit mode, it's not possible to set the modified flag.
	 * 
	 * @param pModified <code>true</code> to set the connection modified, <code>false</code> to set it not modified
	 * @throws DataSourceException if auto-commit detection fails
	 */
	protected void setModified(boolean pModified) throws DataSourceException
	{
	    try
	    {
	        //autocommit -> not modified
    	    if (pModified && cConnection.getAutoCommit())
    	    {
    	        return;
    	    }
    	    
    	    bModified = pModified;
	    }
	    catch (SQLException sqle)
	    {
	        throw new DataSourceException("Can't set DBAccess modified!", formatSQLException(sqle));
	    }
	}
	
	/**
	 * Gets whether the database access is modified.
	 * 
	 * @return <code>true</code> if modified, <code>false</code> otherwise
	 */
	public boolean isModified()
	{
        return bModified;
	}
	
	/**
	 * Gets whether the given log level is enabled.
	 * 
	 * @param pLevel the level to check
	 * @return <code>true</code> if the log level is enabled, <code>false</code> otherwise
	 */
	protected static boolean isLogEnabled(LogLevel pLevel)
	{
	    if (logger == null)
	    {
	        return LoggerFactory.getInstance(DBAccess.class).isEnabled(pLevel);
	    }
	    
	    return logger.isEnabled(pLevel);
	}
	
    /**
     * Logs debug information.
     * 
     * @param pInfo the debug information
     */
    protected static void debug(Object... pInfo)
    {
        if (logger == null)
        {
            logger = LoggerFactory.getInstance(DBAccess.class);
        }
        
        logger.debug(pInfo);
    }

    /**
     * Logs information.
     * 
     * @param pInfo the information
     */
    protected static void info(Object... pInfo)
    {
        if (logger == null)
        {
            logger = LoggerFactory.getInstance(DBAccess.class);
        }
        
        logger.info(pInfo);
    }
    
    /**
     * Logs error information.
     * 
     * @param pInfo the error information
     */
    protected static void error(Object... pInfo)
    {
        if (logger == null)
        {
            logger = LoggerFactory.getInstance(DBAccess.class);
        }

        logger.error(pInfo);
    }   
	
    /**
     * Gets whether the given URL is a JDBC resource.
     * 
     * @param pUrl the URL
     * @return <code>true</code> if given URL is a jdbc resource
     */
    public static boolean isJdbc(String pUrl)
    {
        return pUrl == null || pUrl.toLowerCase().startsWith("jdbc:");        
    }
    
    /**
     * Gets the column name from the given resultset metadata.
     * 
     * @param pMetaData the metadata
     * @param pColumn the column index
     * @return the column name
     * @throws SQLException if accessing metadata failed
     */
    protected String getColumnName(ResultSetMetaData pMetaData, int pColumn) throws SQLException
    {
    	return pMetaData.getColumnName(pColumn);
    }
    
	//****************************************************************
	// Subclass definition
	//****************************************************************
	
    /**
     * The {@link BlobFileHandle} is a simple {@link IFileHandle} implementation
     * that stores a {@link Blob} and allows to retrieve it again. 
     * 
     * @author Robert Zenz
     */
	private static final class BlobFileHandle implements IFileHandle, 
	                                                     IValidatable
	{
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		// Class members
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		
		/** The {@link Blob}. */
		private Blob blob;
		
		/** The name of the column from which the blob originated. */
		private String columnName;
		
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		// Initialization
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		
		/**
		 * Creates a new instance of {@link BlobFileHandle}.
		 * 
		 * @param pColumnName the column name from which the blob originated.
		 * @param pBlob the blob.
		 */
		public BlobFileHandle(String pColumnName, Blob pBlob)
		{
			blob = pBlob;
		}
		
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		// Interface implementation
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		
		/**
		 * {@inheritDoc}
		 */
		public String getFileName()
		{
			return columnName;
		}

		/**
		 * {@inheritDoc}
		 */
		public InputStream getInputStream() throws IOException
		{
			try
			{
				return blob.getBinaryStream();
			}
			catch (SQLException e)
			{
				throw new IOException(e.getMessage());
			}
		}

		/**
		 * {@inheritDoc}
		 */
		public long getLength() throws IOException
		{
			try
			{
				return blob.length();
			}
			catch (SQLException e)
			{
				throw new IOException(e.getMessage());
			}
		}

		/**
		 * {@inheritDoc}
		 */
		public boolean isValid()
		{
			try
			{
				return blob.length() >= 0;
			}
			catch (SQLException e)
			{
				// Ignore the exception.
				return false;
			}
		}
	
	}	// BlobFileHandle
	
	/**
	 * It stores all relevant information of the cached ResultSet for the fetch(...).
	 *  
	 * @author Roland H�rmann
	 */
	private static final class Select
	{
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		// Class members
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

		/** The select statement. */
		private String 		sSelectStatement;
		
		/** The used filter. */
		private Object[]    oaParameter;
		
		/** The last fetched row. */
		private int 		iLastRow;
		
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		// Initialization
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

		/**
		 * Construct a Select cache object.
		 * 
		 * @param pSelectStatement	The select statement.
		 * @param pParameter			The used filter.
		 * @param pLastRow			The last fetched row.
		 */
		Select(String pSelectStatement, Object[] pParameter, int pLastRow)
		{
			sSelectStatement = pSelectStatement;
			oaParameter = pParameter;
			iLastRow = pLastRow;
		}
		
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		// Overwritten methods
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

		/**
		 * {@inheritDoc}
		 */
		@Override
		public int hashCode()
		{
			return sSelectStatement.hashCode() + iLastRow * 13 + Arrays.hashCode(oaParameter);
		}
		
		/**
		 * {@inheritDoc}
		 */
		@Override
		public boolean equals(Object o)
		{
			if (o instanceof Select)
			{
				Select obj = (Select)o;
				
				if (sSelectStatement.equals(obj.sSelectStatement)
					&& iLastRow == obj.iLastRow)
				{
					return Arrays.equals(oaParameter, obj.oaParameter);
				}
				return false;
			}
			return super.equals(o);
		}
		
		/**
		 * {@inheritDoc}
		 */
		@Override
		public String toString()
		{
			StringBuilder sbResult = new StringBuilder();
			
			sbResult.append("Select :: ");
			sbResult.append(sSelectStatement);
			sbResult.append(", Parameter=");
			sbResult.append(StringUtil.toString(oaParameter));
			sbResult.append(", LastRow=");
			sbResult.append(iLastRow);
			sbResult.append("\n");
			
			return sbResult.toString();
		}
		
	}	// Select

} 	// DBAccess
